var PLAYER_SCALE = 0.55;
console.log("game.js loaded");

// =============================
// CAMERA ZOOM (close-up follow)
// =============================
// "Closer to the camera" feel: we zoom the whole world layer.
// HUD is HTML so it stays crisp.
const ARC_CAMERA_ZOOM = 2.35; // ultra close-up camera // tighter close-up camera
// === ARC wallet/link/claim wiring ===
const ARC_API = "http://localhost:3001";
const API = ARC_API; // legacy alias used below
const userId = localStorage.getItem("arc_user_id") || ("user_" + Math.random().toString(16).slice(2));
localStorage.setItem("arc_user_id", userId);

let walletAddress = localStorage.getItem("arc_wallet") || null;


// Immediate wiring of main menu buttons (super-robust).
// This runs as soon as the script is parsed, independent of other setup.
(function immediateWireMainMenu() {
  function wire() {
    try {
      var playBtn = document.querySelector('.menu-btn-pixel.menu-btn-left, [data-action="play"]');
      var settingsBtn = document.querySelector('.menu-btn-pixel.menu-btn-right, [data-action="settings"]');

      if (playBtn && !playBtn.__immediateWired) {
        playBtn.__immediateWired = true;
        console.log('[IMMEDIATE] Wiring PLAY button');
        playBtn.addEventListener('click', function () {
          console.log('[IMMEDIATE] PLAY clicked');
          if (window.__onMainMenuPlay) {
            window.__onMainMenuPlay();
          }
        });
      }
      // Also allow clicking the TV area to trigger PLAY
      var tvWrapper = document.querySelector('.menu-tv-wrapper');
      if (tvWrapper && !tvWrapper.__immediateWiredPlay) {
        tvWrapper.__immediateWiredPlay = true;
        tvWrapper.addEventListener('click', function (evt) {
          // If the actual PLAY button was clicked, let its own handler run
          if (evt.target && evt.target.closest && evt.target.closest('.menu-btn-pixel')) {
            return;
          }
          console.log('[IMMEDIATE] TV wrapper clicked');
          if (window.__onMainMenuPlay) {
            window.__onMainMenuPlay();
          }
        });
      }

      if (settingsBtn && !settingsBtn.__immediateWired) {
        settingsBtn.__immediateWired = true;
        console.log('[IMMEDIATE] Wiring SETTINGS button');
        playBtn && settingsBtn.addEventListener('click', function () {
          console.log('[IMMEDIATE] SETTINGS clicked');
          if (window.__onMainMenuSettings) {
            window.__onMainMenuSettings();
          }
        });
      }
    } catch (e) {
      console.error('[IMMEDIATE] Error wiring main menu', e);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', wire);
  } else {
    wire();
  }
})();


// ===== PAUSE MENU + SETTINGS WIRING (make the authored UI actually work) =====
(function wirePauseAndSettings(){
  const SETTINGS_KEY = 'arc_settings_v2';

  function loadSettings(){
    const defaults = {
      master: 1,
      sfx: 1,
      music: 0.65,
      mouseSens: 1.0,
      gfx: 'high',
      weather: true,
      shake: true,
    };
    try {
      const raw = localStorage.getItem(SETTINGS_KEY);
      if (!raw) return defaults;
      const obj = JSON.parse(raw);
      return Object.assign({}, defaults, (obj && typeof obj === 'object') ? obj : {});
    } catch(e) {
      return defaults;
    }
  }

  function saveSettings(s){
    try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); } catch(e) {}
  }

  const state = loadSettings();

  // Apply to globals consumed by gameplay.
  window.arcMasterVolume = Number(state.master);
  window.arcSfxVolume = Number(state.sfx);
  window.arcMusicVolume = Number(state.music);
  window.arcMouseSensitivity = Number(state.mouseSens);
  window.arcWeatherEnabled = !!state.weather;
  window.arcShakeEnabled = !!state.shake;

  // Keep audio buses in sync if they exist.
  try { if (typeof __applyAudioSettings === 'function') __applyAudioSettings(); } catch(e) {}

  window.addEventListener('load', () => {
    const pauseOverlay = document.getElementById('pause-overlay');
    const settingsPanel = document.getElementById('settings-panel');

    // Robust UI open/close helpers so we never strand the player in a half-UI state
    // (symptom: ESC closes settings but you can only move, can't aim/shoot).
    function anyModalVisible() {
      const ids = [
        'settings-panel',
        'pause-overlay',
        'leaderboard-overlay',
        'shop-overlay',
        'void-overlay',
        'zone-summary-overlay'
      ];
      for (const id of ids) {
        const el = document.getElementById(id);
        if (!el) continue;
        const d = (el.style && el.style.display) ? el.style.display : '';
        if (d === 'flex' || d === 'block') return true;
      }
      return false;
    }

    function setUiOpen(v) {
      try {
        if (v) document.body.classList.add('ui-open');
        else document.body.classList.remove('ui-open');
      } catch (_) {}
      // Safety: never leave mouseDown stuck when toggling UI.
      try { if (window.__setMouseDown) window.__setMouseDown(false); } catch (_) {}
    }

    function openSettingsPanel() {
      if (settingsPanel) settingsPanel.style.display = 'flex';
      // If we are in a live run, pause so gameplay can't keep eating input.
      if (typeof window.setPaused === 'function') {
        try { window.setPaused(true); } catch (_) {}
      }
      if (pauseOverlay) pauseOverlay.style.display = 'none';

      // IMPORTANT: this project historically had two pause overlays
      // (the HTML one + a dynamically created one with id "arcPauseOverlay").
      // When settings opens, that dynamic overlay can sit on top and eat all clicks,
      // making settings feel completely dead. Always hide it while in settings.
      try {
        const legacyPause = document.getElementById('arcPauseOverlay');
        if (legacyPause) legacyPause.style.display = 'none';
      } catch (_) {}

      setUiOpen(true);
      // Focus the first interactive control so keyboard immediately works.
      try {
        const first = settingsPanel && settingsPanel.querySelector('input,select,button');
        if (first) first.focus({ preventScroll: true });
      } catch (_) {}
    }

    function closeSettingsPanel({ resume = true } = {}) {
      if (settingsPanel) settingsPanel.style.display = 'none';
      // Only show pause overlay if we are still paused.
      if (pauseOverlay && window.isPaused) pauseOverlay.style.display = 'flex';
      if (resume && typeof window.setPaused === 'function') {
        try { window.setPaused(false); } catch (_) {}
      }

      // If the legacy pause overlay exists, keep it hidden unless we are actually paused.
      try {
        const legacyPause = document.getElementById('arcPauseOverlay');
        if (legacyPause) legacyPause.style.display = (window.isPaused ? 'flex' : 'none');
      } catch (_) {}

      // Only keep ui-open if another modal is still visible (pause, shop, etc.)
      setUiOpen(anyModalVisible());
    }

    // Expose for main menu wiring (so settings always opens correctly)
    window.__openSettingsPanel = openSettingsPanel;
    window.__closeSettingsPanel = closeSettingsPanel;

    // Buttons (pause + settings). NOTE: settings panel lives outside pause overlay,
    // so we bind globally to prevent the "Back to run" / close button from being dead.
    document.querySelectorAll('[data-pause-action]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const act = btn.getAttribute('data-pause-action');
        if (act === 'resume') {
          setUiOpen(false);
          if (typeof window.setPaused === 'function') window.setPaused(false);
        } else if (act === 'restart') {
          try { restartGame(); } catch(e) {}
          setUiOpen(false);
          if (typeof window.setPaused === 'function') window.setPaused(false);
        } else if (act === 'settings') {
          openSettingsPanel();
        } else if (act === 'save-settings') {
          // Explicit save button (some players prefer "apply" instead of live sliders)
          try { commit && commit(); } catch(e) {}
          closeSettingsPanel({ resume: true });
        } else if (act === 'close-settings') {
          // "Back to run" should actually get you back into the run (and persist changes).
          // We commit the current slider values, close settings, and resume immediately.
          try { commit && commit(); } catch(e) {}
          closeSettingsPanel({ resume: true });
        } else if (act === 'quit') {
          // Quit = go back to FARM HUB (never strand the player on the title card).
          try {
            // Make absolutely sure we are not paused and not in a modal state.
            try { if (typeof window.setPaused === 'function') window.setPaused(false); } catch (_) {}
            try { window.isPaused = false; } catch (_) {}
            try { setUiOpen(false); } catch (_) {}

            // Clear stuck input (prevents "can move but can't shoot/aim" + other weirdness).
            try { if (window.__setMouseDown) window.__setMouseDown(false); } catch (_) {}
            try {
              // Best-effort clear key states if they exist.
              if (window.__arcKeys && typeof window.__arcKeys === 'object') {
                Object.keys(window.__arcKeys).forEach(k => window.__arcKeys[k] = false);
              }
            } catch (_) {}

            // Hide overlays
            if (pauseOverlay) pauseOverlay.style.display = 'none';
            if (settingsPanel) settingsPanel.style.display = 'none';
            try {
              const legacyPause = document.getElementById('arcPauseOverlay');
              if (legacyPause) legacyPause.style.display = 'none';
            } catch (_) {}

            // Hide the main-menu container (we return to hub, not title)
            const mm = document.getElementById('main-menu');
            if (mm) mm.style.display = 'none';

            // Stop run-only sounds then enter hub
            try { stopAllSounds && stopAllSounds(); } catch (_) {}

            if (typeof enterFarmHub === 'function') enterFarmHub();
            gameState = 'farmHub';

            // If a blur/freeze class exists, remove it.
            try { document.body.classList.remove('ui-open'); } catch (_) {}
          } catch(e) {
            console.error('[QUIT] Failed to return to hub', e);
          }
        }
        });
    });


    // Settings controls
    const masterEl = document.getElementById('setting-master-volume');
    const sfxEl = document.getElementById('setting-sfx-volume');
    const sensEl = document.getElementById('setting-mouse-sensitivity');
    const gfxEl = document.getElementById('setting-graphics-quality');
    const weatherEl = document.getElementById('setting-weather');
    const shakeEl = document.getElementById('setting-shake');

    // Dev/QoL: jump to wave controls (used for quick testing)
    const devJumpInput = document.getElementById('dev-jump-wave-input');
    const devJumpBtn = document.getElementById('dev-jump-wave-btn');

    if (masterEl) masterEl.value = String(state.master);
    if (sfxEl) sfxEl.value = String(state.sfx);
    if (sensEl) sensEl.value = String(state.mouseSens);
    if (gfxEl) gfxEl.value = String(state.gfx);
    if (weatherEl) weatherEl.checked = !!state.weather;
    if (shakeEl) shakeEl.checked = !!state.shake;

    function commit(){
      // Pull from controls
      if (masterEl) state.master = Number(masterEl.value);
      if (sfxEl) state.sfx = Number(sfxEl.value);
      if (sensEl) state.mouseSens = Number(sensEl.value);
      if (gfxEl) state.gfx = String(gfxEl.value || 'high');
      if (weatherEl) state.weather = !!weatherEl.checked;
      if (shakeEl) state.shake = !!shakeEl.checked;

      // Apply
      window.arcMasterVolume = Number(state.master);
      window.arcSfxVolume = Number(state.sfx);
      window.arcMouseSensitivity = Number(state.mouseSens);
      window.arcWeatherEnabled = !!state.weather;
      window.arcShakeEnabled = !!state.shake;
      try { if (typeof __applyAudioSettings === 'function') __applyAudioSettings(); } catch(e) {}

      // Graphics quality: lightweight toggle (image smoothing / FX)
      try {
        const q = String(state.gfx);
        if (q === 'low') document.body.classList.add('fx-off');
        else document.body.classList.remove('fx-off');
      } catch(e) {}

      saveSettings(state);
    }

    [masterEl, sfxEl, sensEl, gfxEl, weatherEl, shakeEl].forEach(el => {
      if (!el) return;
      el.addEventListener('input', commit);
      el.addEventListener('change', commit);
    });

    // Wire Jump-to-wave button + Enter key.
    // NOTE: This intentionally does not affect leaderboards.
    function doDevJump(){
      try {
        const w = devJumpInput ? devJumpInput.value : 1;
        if (typeof window.__devJumpToWave === 'function') window.__devJumpToWave(w);
        // Close settings + resume instantly so testing is fast.
        const sp = document.getElementById('settings-panel');
        if (sp) sp.style.display = 'none';
        try { document.body.classList.remove('ui-open'); } catch(e) {}
        if (typeof window.setPaused === 'function') window.setPaused(false);
      } catch(e) {}
    }
    if (devJumpBtn) devJumpBtn.addEventListener('click', doDevJump);
    if (devJumpInput) {
      devJumpInput.addEventListener('keydown', (e)=>{
        if (e.key === 'Enter') { e.preventDefault(); doDevJump(); }
      });
    }

    // First commit ensures audio buses reflect saved values immediately.
    commit();
  });
})();

window.addEventListener('load', () => {

let arcWallet = null;
let arcProvider = null;
const arcConnectBtn = document.getElementById('wallet-connect-btn');
const arcAddressEl = document.getElementById('wallet-address');
let gameState = "menu";

// When entering combat (especially Wave 1), multiple code paths can momentarily
// leave the player/camera at stale coordinates (often near 0,0). That makes it
// LOOK like you spawn in the top-left and enemies "go crazy". We hard-force a
// correct combat spawn for a few frames after a run starts.
let __forceCombatSpawnFrames = 0;

// Expose gameState to other scripts (pause/settings) without desync.
// Any code that writes window.gameState will update this local variable too.
try {
  Object.defineProperty(window, "gameState", {
    get() { return gameState; },
    set(v) { gameState = v; },
    configurable: true
  });
} catch {}

    async function connectWallet() {
  if (!window.solana || !window.solana.isPhantom) {
    alert("Phantom wallet not detected! Install https://phantom.app");
    return;
  }

  try {
    arcProvider = window.solana;

    await arcProvider.connect(); // ← MUST be inside try
    arcWallet = arcProvider;

    const addr =
      arcWallet.publicKey.toBase58().slice(0, 4) +
      "..." +
      arcWallet.publicKey.toBase58().slice(-4);

    arcConnectBtn.textContent = "WALLET CONNECTED";
    arcConnectBtn.style.background = "#22c55e";
    arcAddressEl.textContent = addr;
    arcAddressEl.style.opacity = 1;

    // ✅ SHOW ARC HUD
    document.getElementById("arc-hud").classList.remove("hidden");
    updateArcHUD();

  } catch (e) {
    console.error(e);
  }
}
   if (arcConnectBtn) {
  arcConnectBtn.addEventListener('click', connectWallet);

}


    async function claimSOL(arcAmount) {
      if (!arcWallet) return alert("Connect wallet first!");
      const msg =
        "Claiming rewards for " +
        arcAmount.toLocaleString() +
        " ARC!\nThis will be real SOL on mainnet.";
      alert(msg);
    }

    // helper: update points UI
    function updatePointsDisplay() {
      try {
        const pointsLabel = document.getElementById("points-label");
        if (pointsLabel) pointsLabel.textContent = "ARC: " + points.toLocaleString();
        updateAchievements();
        updateUpgradePanel();
      } catch (e) { console.error(e); }
    }

// ===== BOSS HUD (top-center bar) =====
function updateBossHUD() {
  if (!bossbar || !bossbarFill) return;
  const boss = enemies.find(e => e && e.isBoss);
  if (!boss) {
    bossbar.style.display = "none";
    return;
  }
  bossbar.style.display = "block";
  const ratio = Math.max(0, Math.min(1, boss.hp / boss.maxHp));
  bossbarFill.style.transform = "scaleX(" + ratio + ")";
  if (bossbarHp) bossbarHp.textContent = Math.round(ratio * 100) + "%";
  if (bossbarName) {
    const kind = (boss && boss.bossKind) ? String(boss.bossKind) : 'phantom';
    let label = 'PHANTOM VALIDATOR';
    if (kind === 'sandboss') label = 'SANDBOSS';
    if (kind === 'minotaur') label = 'MINOTAUR';
    if (kind === 'evilWizard') label = 'EVIL WIZARD';
    if (kind === 'skeletonBoss') label = 'SKELETON KING';
    if (kind === 'golem1') label = 'GOLEM';
    bossbarName.textContent = label + ' • W' + (wave || 1);
  }
}


    function tryClaimAchievement(arcNeeded, rewardSOL) {
  if (points >= arcNeeded && arcWallet) {
    const msg =
      "Claim " +
      rewardSOL +
      " SOL for " +
      arcNeeded.toLocaleString() +
      " ARC?";

    if (confirm(msg)) {
      claimSOL(points);
      points = 0;
      updatePointsDisplay();
    }
  }
}
    // ==========================
    // LEADERBOARD (LOCAL STORAGE)
    // ==========================
    let leaderboard = [];

    function loadLeaderboard() {
      try {
        const raw = localStorage.getItem("arcLeaderboard");
        leaderboard = raw ? JSON.parse(raw) : [];
      } catch (e) {
        console.error("Failed to load leaderboard", e);
        leaderboard = [];
      }
    }

    function saveLeaderboard() {
      try {
        localStorage.setItem("arcLeaderboard", JSON.stringify(leaderboard));
      } catch (e) {
        console.error("Failed to save leaderboard", e);
      }
    }

    function getCurrentWalletLabel() {
      try {
        if (!arcWallet || !arcWallet.publicKey) return "Guest";
        const full = arcWallet.publicKey.toBase58();
        return full.slice(0, 4) + ".." + full.slice(-4);
      } catch (e) {
        return "Guest";
      }
    }

    function addScoreToLeaderboard({ wallet, points, kills, level }) {
      leaderboard.push({
        wallet,
        points,
        kills,
        level,
        ts: Date.now()
      });

      // Sort by ARC desc
      leaderboard.sort((a, b) => b.points - a.points);
      leaderboard = leaderboard.slice(0, 10);
      saveLeaderboard();
      renderLeaderboard();
    }

    function renderLeaderboard() {
      const listEl = document.getElementById("leaderboard-list");
      const sideEl = document.getElementById("leaderboard-sidebar-list");
      if (!listEl && !sideEl) return;

      if (listEl) listEl.innerHTML = "";
      if (sideEl) sideEl.innerHTML = "";

      if (!leaderboard.length) {
        const liA = document.createElement("li");
        liA.textContent = "No runs yet. Be the first legend.";
        if (listEl) listEl.appendChild(liA.cloneNode(true));
        if (sideEl) sideEl.appendChild(liA);
        return;
      }

      // Overlay can show deeper history, but the Farm Hub left rail should stay clean.
      // - Overlay: up to 10
      // - Hub left rail: top 5
      const overlayRows = leaderboard.slice(0, 10);
      const hubRows = leaderboard.slice(0, 5);

      function makeRow(entry, idx){
        const li = document.createElement('li');
        li.className = 'lb-row';
        const rank = document.createElement('span');
        rank.className = 'lb-rank';
        rank.textContent = "#" + (idx + 1);

        const name = document.createElement('span');
        name.className = 'lb-name';
        name.textContent = String(entry.wallet || 'Guest');

        const arc = document.createElement('span');
        arc.className = 'lb-arc';
        arc.textContent = (Number(entry.points) || 0).toLocaleString() + ' ARC';

        const meta = document.createElement('span');
        meta.className = 'lb-meta';
        meta.textContent = "Lvl " + (entry.level ?? '?') + " · " + (entry.kills ?? 0) + " kills";

        const left = document.createElement('div');
        left.className = 'lb-left';
        left.appendChild(rank);
        left.appendChild(name);

        const right = document.createElement('div');
        right.className = 'lb-right';
        right.appendChild(arc);
        right.appendChild(meta);

        li.appendChild(left);
        li.appendChild(right);
        return li;
      }

      if (listEl) {
        overlayRows.forEach((entry, idx) => listEl.appendChild(makeRow(entry, idx)));
      }
      if (sideEl) {
        hubRows.forEach((entry, idx) => sideEl.appendChild(makeRow(entry, idx)));
      }
    }

// =============================================================

        // ==============================================================
    // INTRO DIALOG ELEMENTS + SCRIPT
    // ==============================================================

    const dialogContainer   = document.getElementById('dialog-container');
    const dialogTextEl      = document.getElementById('dialog-text');
    const dialogContinueEl  = document.getElementById('dialog-continue');
    const introBackdrop     = document.getElementById('intro-backdrop');

   const introScript = [
  "Yo. You actually jacked in. Didn’t think the grid would let you through.",
  "This used to be a quiet little yield-farm. Now the whole shard’s corrupted — glitches, beasts, bad code everywhere.",
  "Every wave that creeps in chews a little more out of our blockspace. If we don’t push them back, this place goes dark.",
  "Here’s the deal: you fight, you survive, you keep the rot off these fields.",
  "I track every run. You stack ARC — later that ARC gets streamed into real SOL when the protocol goes live.",
  "So this isn’t some cozy farm sim. This is a live-fire stress test on the Solana network.",
  "Lock in, stay moving, and don’t let the lights go out."
];


    let introIndex = 0;
    let typing = false;
    let introReady = false;   // prevents early clicks
    // Track whether the intro cutscene has been completed.  Once true we skip
    // running the intro on subsequent runs and restarts.
    let introCompleted = false;
    // === INTRO DIRECTOR: centralized flow for the intro cutscene ===
    function beginIntroSequence() {
      // If the intro was already completed once, just go straight to character select.
      if (introCompleted) {
        if (typeof startCharacterSelect === "function") {
          startCharacterSelect();
        }
        return;
      }

      // Reset intro state
      gameState = "intro";
      introIndex = 0;
      typing = false;
      introReady = false;

      // Show backdrop and farmer
      if (introBackdrop) {
        introBackdrop.classList.remove("intro-hidden");
      }
      if (cutsceneFarmer) {
        cutsceneFarmer.classList.remove("cutscene-hidden");
        // Snappier entrance than the old 1.8s walk
        cutsceneFarmer.style.animation = "farmer-walk-in 0.9s ease-out forwards";
      }

      // Calm farm mood + intro ambience
      if (typeof setMusicMood === "function") {
        setMusicMood("village");
      }
      if (typeof startIntroAmbient === "function") {
        startIntroAmbient();
      }

      // After a short beat, bring in the dialog and start the first line
      setTimeout(function () {
        if (dialogContainer) {
          dialogContainer.classList.remove("dialog-hidden");
        }
        introReady = true;

        if (typeof showNextIntroLine === "function") {
          showNextIntroLine();
        }
      }, 400);
    }

    function endIntroToCharacterSelect() {
  // Hide all intro visuals
  try { if (dialogContainer) dialogContainer.classList.add("dialog-hidden"); } catch(_) {}
  try { if (introBackdrop) introBackdrop.classList.add("intro-hidden"); } catch(_) {}
  try { if (cutsceneFarmer) cutsceneFarmer.classList.add("cutscene-hidden"); } catch(_) {}

  // Stop the intro ambient if it's playing
  if (typeof stopIntroAmbient === "function") {
    try { stopIntroAmbient(); } catch (e) { console.warn("Failed to stop intro ambient", e); }
  }

    // After intro, begin the run flow (which will open customization first).
  if (typeof startCharacterSelect === "function") {
    startCharacterSelect("newRun");
    return;
  }

  // Fallbacks (should rarely happen)
  if (typeof showPostIntroOverlay === "function") {
    showPostIntroOverlay();
  } else if (typeof startCharacterSelect === "function") {
    startCharacterSelect();
  }
}


        // ============================================
    // POST-INTRO HUB UI (PLAY / SETTINGS / CREDITS)
    // ============================================
    let postIntroOverlay = null;

    function buildPostIntroOverlay() {
      if (postIntroOverlay) return;

      const overlay = document.createElement("div");
      overlay.id = "post-intro-overlay";
      Object.assign(overlay.style, {
        position: "fixed",
        inset: "0",
        zIndex: "40",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background:
          "radial-gradient(circle at top, rgba(15,23,42,0.96), rgba(2,6,23,0.98))",
        fontFamily: "'Press Start 2P', system-ui, sans-serif",
        color: "#e5e7eb",
        pointerEvents: "none",
        opacity: "0",
        transition: "opacity 0.25s ease-out"
      });

      // Wrapper around the card so we can have a glow behind it
      const cardWrap = document.createElement("div");
      Object.assign(cardWrap.style, {
        position: "relative",
        borderRadius: "32px"
      });

      // Soft Solana gradient glow behind the card
      const glow = document.createElement("div");
      Object.assign(glow.style, {
        position: "absolute",
        inset: "-3px",
        borderRadius: "inherit",
        background:
          "linear-gradient(135deg, rgba(34,197,94,0.7), rgba(45,212,191,0.6), rgba(147,51,234,0.7))",
        opacity: "0.45",
        filter: "blur(10px)",
        zIndex: "0",
        pointerEvents: "none"
      });
      cardWrap.appendChild(glow);

      // Inner card
      const inner = document.createElement("div");
      Object.assign(inner.style, {
        display: "flex",
        gap: "40px",
        padding: "32px 40px",
        borderRadius: "28px",
        background:
          "linear-gradient(135deg, rgba(15,23,42,0.98), rgba(2,6,23,0.97))",
        border: "1px solid rgba(56,189,248,0.35)",
        boxShadow:
          "0 28px 70px rgba(0,0,0,0.55), inset 0 0 22px rgba(56,189,248,0.07)",
        width: "680px",
        boxSizing: "border-box",
        alignItems: "flex-start"
      });

      // ---------- LEFT: ARC / meta panel ----------
      const left = document.createElement("div");
      Object.assign(left.style, {
        flex: "1",
        display: "flex",
        flexDirection: "column",
        gap: "14px",
        minWidth: "260px"
      });

      const title = document.createElement("div");
      title.textContent = "ARC TERMINAL";
      Object.assign(title.style, {
        fontSize: "13px",
        letterSpacing: "0.16em",
        color: "#22d3ee",
        marginBottom: "6px",
        textShadow: "0 0 14px rgba(34,197,94,0.7)"
      });
      left.appendChild(title);

      const subtitle = document.createElement("div");
      subtitle.textContent = "Session overview before you jack in.";
      Object.assign(subtitle.style, {
        fontSize: "9px",
        color: "#9ca3af",
        lineHeight: "1.5",
        marginBottom: "10px"
      });
      left.appendChild(subtitle);

      function makeStatLine(id, label, accentColor) {
        const wrap = document.createElement("div");
        wrap.id = id;
        Object.assign(wrap.style, {
          fontSize: "10px",
          lineHeight: "1.4"
        });
        wrap.innerHTML =
          '<div style="font-size:9px;letter-spacing:0.12em;opacity:0.75;">' +
          label +
          "</div>" +
          '<div style="font-size:14px;margin-top:2px;color:' +
          accentColor +
          ';font-variant-numeric:tabular-nums;">0</div>';
        return wrap;
      }

      const arcLine = makeStatLine(
        "post-intro-arc-line",
        "TOTAL ARC",
        "#22d3ee"
      );
      const killsLine = makeStatLine(
        "post-intro-kills-line",
        "TOTAL KILLS",
        "#c4b5fd"
      );
      const walletLine = makeStatLine(
        "post-intro-wallet-line",
        "WALLET",
        "#4ade80"
      );

      left.appendChild(arcLine);
      left.appendChild(killsLine);
      left.appendChild(walletLine);

      // ---------- RIGHT: options + mascots ----------
      const right = document.createElement("div");
      Object.assign(right.style, {
        flex: "1",
        display: "flex",
        flexDirection: "column",
        gap: "18px",
        minWidth: "260px",
        alignItems: "stretch"
      });

      const menuTitle = document.createElement("div");
      menuTitle.textContent = "OPTIONS";
      Object.assign(menuTitle.style, {
        fontSize: "11px",
        letterSpacing: "0.18em",
        marginBottom: "4px",
        color: "#9ca3af"
      });
      right.appendChild(menuTitle);

      function makeMenuButton(label) {
        const btn = document.createElement("button");
        btn.textContent = label;
        Object.assign(btn.style, {
          padding: "11px 22px",
          borderRadius: "999px",
          border: "1px solid rgba(15,23,42,0.9)",
          background:
            "linear-gradient(135deg, rgba(15,23,42,0.95), rgba(30,64,175,0.95))",
          opacity: "0.9",
          color: "#e5e7eb",
          fontSize: "11px",
          letterSpacing: "0.16em",
          textTransform: "uppercase",
          cursor: "pointer",
          textAlign: "center",
          boxShadow: "0 18px 45px rgba(15,23,42,0.95)",
          transition:
            "transform 0.14s ease-out, box-shadow 0.14s ease-out, background 0.18s ease-out, border-color 0.18s ease-out, filter 0.18s ease-out",
          position: "relative",
          overflow: "hidden",
          width: "100%"
        });

        btn.addEventListener("mouseenter", () => {
          btn.style.transform = "translateY(-2px)";
          btn.style.boxShadow = "0 24px 60px rgba(15,23,42,0.95)";
          btn.style.background =
            "linear-gradient(135deg, rgba(56,189,248,0.95), rgba(37,99,235,0.95))";
          btn.style.borderColor = "rgba(56,189,248,0.9)";
        });

        btn.addEventListener("mouseleave", () => {
          btn.style.transform = "translateY(0)";
          btn.style.boxShadow = "0 18px 45px rgba(15,23,42,0.95)";
          btn.style.background =
            "linear-gradient(135deg, rgba(15,23,42,0.95), rgba(30,64,175,0.95))";
          btn.style.borderColor = "rgba(15,23,42,0.9)";
        });

        btn.addEventListener("mousedown", () => {
          btn.style.transform = "translateY(1px) scale(0.99)";
        });

        btn.addEventListener("mouseup", () => {
          btn.style.transform = "translateY(-2px)";
        });

        return btn;
      }

      function makeMascotWrappedButton(label, cfg) {
        const btn = makeMenuButton(label);

        const wrapper = document.createElement("div");
        Object.assign(wrapper.style, {
          position: "relative",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          marginBottom: "2px"
        });

        const img = new Image();
        img.src = cfg.src;
        img.alt = "";
        Object.assign(img.style, {
          position: "absolute",
          left: cfg.side === "left" ? "-42px" : "auto",
          right: cfg.side === "right" ? "-42px" : "auto",
          top: "50%",
          transform: "translateY(-50%)",
          width: "40px",
          height: "40px",
          imageRendering: "pixelated",
          pointerEvents: "none",
          filter: "drop-shadow(0 8px 16px rgba(0,0,0,0.8))",
          transition: "transform 0.18s ease-out"
        });

        // Hover wobble for the mascot
        btn.addEventListener("mouseenter", () => {
          img.style.transform = "translateY(-56%) scale(1.06)";
        });
        btn.addEventListener("mouseleave", () => {
          img.style.transform = "translateY(-50%) scale(1)";
        });

        wrapper.appendChild(btn);
        wrapper.appendChild(img);

        return { wrapper, btn };
      }

      // Attach mascots to the three main actions
      const playPair = makeMascotWrappedButton("START RUN", {
        src: "Pink_Monster.png",
        side: "left"
      });
      const settingsPair = makeMascotWrappedButton("SETTINGS", {
        src: "Owlet_Monster.png",
        side: "left"
      });
      const creditsPair = makeMascotWrappedButton("CREDITS", {
        src: "Dude_Monster.png",
        side: "left"
      });

      const playBtn = playPair.btn;
      const settingsBtn = settingsPair.btn;
      const creditsBtn = creditsPair.btn;

      // Button behavior
      playBtn.addEventListener("click", () => {
        hidePostIntroOverlay();
        // After dying / restarting, skip the loadout bar and drop straight into FarmHub
        try {
          const hasSavedLoadout = !!(localStorage.getItem("arc_selected_character") && localStorage.getItem("arc_selected_weapon"));
          if (hasSavedLoadout && typeof window.__quickReturnToFarmHub === "function") {
            window.__quickReturnToFarmHub();
            return;
          }
        } catch(_) {}
        if (typeof startCharacterSelect === "function") {
          startCharacterSelect();
        }
      });

      settingsBtn.addEventListener("click", () => {
        if (window.__onMainMenuSettings) {
          window.__onMainMenuSettings();
        } else {
          alert("Settings coming soon.");
        }
      });

      creditsBtn.addEventListener("click", () => {
        alert("Credits: You + Solana World ARC degen squad.");
      });

      right.appendChild(playPair.wrapper);
      right.appendChild(settingsPair.wrapper);
      right.appendChild(creditsPair.wrapper);

      // Put it all together
      inner.appendChild(left);
      inner.appendChild(right);
      cardWrap.appendChild(inner);
      overlay.appendChild(cardWrap);
      document.body.appendChild(overlay);
      postIntroOverlay = overlay;
    }


               function updatePostIntroStats() {
      const arcLine = document.getElementById("post-intro-arc-line");
      const killsLine = document.getElementById("post-intro-kills-line");
      const walletLine = document.getElementById("post-intro-wallet-line");

      // Use lifetime totals, not per-run stats
      const arcSource = typeof totalArc === "number" ? totalArc : 0;
      const killsSource = typeof totalKills === "number" ? totalKills : 0;

      if (arcLine) {
        const val = arcSource.toLocaleString();
        arcLine.innerHTML =
          '<div style="font-size:9px;letter-spacing:0.12em;opacity:0.75;">TOTAL ARC</div>' +
          '<div style="font-size:14px;margin-top:2px;color:#22d3ee;font-variant-numeric:tabular-nums;">' +
          val +
          "</div>";
      }

      if (killsLine) {
        const val = killsSource.toLocaleString();
        killsLine.innerHTML =
          '<div style="font-size:9px;letter-spacing:0.12em;opacity:0.75;">TOTAL KILLS</div>' +
          '<div style="font-size:14px;margin-top:2px;color:#c4b5fd;font-variant-numeric:tabular-nums;">' +
          val +
          "</div>";
      }

      if (arcLine) {
        const val = (arcSource || 0).toLocaleString();
        arcLine.innerHTML =
          '<div style="font-size:9px;letter-spacing:0.12em;opacity:0.75;">TOTAL ARC</div>' +
          '<div style="font-size:14px;margin-top:2px;color:#22d3ee;font-variant-numeric:tabular-nums;">' +
          val +
          "</div>";
      }

      if (killsLine) {
        const val = (killsSource || 0).toLocaleString();
        killsLine.innerHTML =
          '<div style="font-size:9px;letter-spacing:0.12em;opacity:0.75;">TOTAL KILLS</div>' +
          '<div style="font-size:14px;margin-top:2px;color:#c4b5fd;font-variant-numeric:tabular-nums;">' +
          val +
          "</div>";
      }

      // keep your existing walletLine code below this unchanged


      if (walletLine) {
        let label;
        try {
          label =
            typeof getCurrentWalletLabel === "function"
              ? getCurrentWalletLabel()
              : "Guest";
        } catch (e) {
          label = "Guest";
        }
        walletLine.innerHTML =
          '<div style="font-size:9px;letter-spacing:0.12em;opacity:0.75;">WALLET</div>' +
          '<div style="font-size:11px;margin-top:2px;color:#4ade80;">' +
          label +
          "</div>";
      }
    }

    // Attach the 3 character sprites to the right-side menu buttons
    function addPostIntroMascots() {
      if (!postIntroOverlay) return;

      // avoid duplicate mascots if overlay is reopened
      if (postIntroOverlay.__arcMascotsAdded) return;
      postIntroOverlay.__arcMascotsAdded = true;

      const buttons = postIntroOverlay.querySelectorAll("button");
      if (!buttons.length) return;

      const mascotConfigs = [
        { src: "Pink_Monster.png", buttonIndex: 0 }, // START RUN
        { src: "Owlet_Monster.png", buttonIndex: 1 }, // SETTINGS
        { src: "Dude_Monster.png", buttonIndex: 2 },  // CREDITS
      ];

      mascotConfigs.forEach((cfg) => {
        const btn = buttons[cfg.buttonIndex];
        if (!btn) return;

        // Make sure the button can host absolutely-positioned children
        btn.style.position = "relative";

        const img = document.createElement("img");
        img.src = cfg.src;
        img.alt = "";
        Object.assign(img.style, {
          position: "absolute",
          left: "-42px",            // pull sprite to the left of the pill
          top: "50%",
          width: "40px",
          height: "40px",
          transform: "translateY(-50%)",
          imageRendering: "pixelated",
          pointerEvents: "none",
          filter: "drop-shadow(0 8px 16px rgba(0,0,0,0.75))",
          transition: "transform 0.18s ease-out",
        });

        btn.appendChild(img);

        // subtle hover bob
        btn.addEventListener("mouseenter", () => {
          img.style.transform = "translateY(-56%) scale(1.06)";
        });
        btn.addEventListener("mouseleave", () => {
          img.style.transform = "translateY(-50%) scale(1)";
        });
      });
    }

    function showPostIntroOverlay() {
      if (!postIntroOverlay) buildPostIntroOverlay();
      updatePostIntroStats();
      addPostIntroMascots();
      postIntroOverlay.style.opacity = "1";
      postIntroOverlay.style.pointerEvents = "auto";
      gameState = "postIntroMenu";
    }


    function hidePostIntroOverlay() {
      if (!postIntroOverlay) return;
      postIntroOverlay.style.opacity = "0";
      postIntroOverlay.style.pointerEvents = "none";
    }

    const cutsceneFarmer    = document.getElementById("cutscene-farmer");
    const cutsceneFarmerImg = document.getElementById("cutscene-farmer-img");
    // ===============================
    // SIMPLE CHARACTER SELECT OVERLAY
    // ===============================

   const CHARACTER_CONFIGS = [
  {
    id: "pink",
    name: "PINK MONSTER",
    description: "Fast little chaos demon. Default skin.",
    previewSrc: "Pink_Monster.png",
    idleSrc: "Pink_Monster.png",
    walkSrc: "Pink_Monster_Walk_6.png",
    stats: { speed: 5, damage: 3, defense: 2 }, // 0–5 scale, purely visual
    trailColor: "236, 72, 153" // pink
  },
  {
    id: "owlet",
    name: "OWLET",
    description: "Little hooded mage. Slightly tankier, a bit slower.",
    previewSrc: "Owlet_Monster.png",
    idleSrc: "Owlet_Monster_Idle_4.png",
    walkSrc: "Owlet_Monster_Walk_6.png",
    stats: { speed: 3, damage: 4, defense: 4 },
    trailColor: "129, 140, 248" // indigo / mage-y
  },
  {
    id: "base",
    name: "DUDE",
    description: "Chill explorer. Balanced stats.",
    previewSrc: "Dude_Monster.png",
    idleSrc: "Dude_Monster_Idle_4.png",
    walkSrc: "Dude_Monster_Walk_6.png",
    stats: { speed: 4, damage: 4, defense: 3 },
    trailColor: "56, 189, 248" // cyan
  }
];
let selectedCharacterId = (() => {
  try { return localStorage.getItem("arcSelectedChar") || "base"; } catch { return "pink"; }
})();

// loadoutContext controls what happens after selection:
// - "newRun": character -> weapon -> jack-in -> farmhub intro
// - "hubWeapon": weapon-only picker, then return to farmHub
// - "hubSprite": sprite-only picker, then return to farmHub
let loadoutContext = "newRun";

function saveSelectedLoadout() {
  try {
    if (typeof selectedWeaponId !== "undefined" && selectedWeaponId) localStorage.setItem("arcSelectedWeapon", selectedWeaponId);
    if (selectedCharacterId) localStorage.setItem("arcSelectedChar", selectedCharacterId);
  } catch {}
}


// Quick return to FarmHub without showing character/weapon selection UI
window.__quickReturnToFarmHub = function() {
  try {
    // Apply persisted loadout so player spawns with last chosen sprite + weapon
    try { loadSelectedLoadout(); } catch(_) {}
    try {
      if (typeof player === "object" && player) {
        if (!player.weapon && typeof getWeaponTemplateById === "function") {
          const wid = localStorage.getItem("arc_selected_weapon");
          if (wid) player.weapon = getWeaponTemplateById(wid);
        }
      }
    } catch(_) {}
    // Prefer the real FarmHub entry flow so wave=0 + NPCs + camera all reset correctly.
    if (typeof enterFarmHub === 'function') {
      enterFarmHub();
    } else {
      // Fallback: at least set the state + reset combat gating.
      gameState = "farmHub";
      try { wave = 0; } catch(_) {}
      try { resetCombatArraysForHub(); } catch(_) {}
      try { centerCameraOnPlayer(true); } catch(_) {}
      try { ensureHubNpcDom(); } catch(_) {}
      try { showHubNpcDom(); } catch(_) {}
    }

    // Ensure FarmHub UI is visible (some overlays hide it)
    try {
      if (typeof showFarmHub === "function") showFarmHub();
    } catch(_) {}
    try {
      const hub = document.getElementById("farmhub-ui");
      if (hub) hub.style.display = "block";
    } catch(_) {}
  } catch (e) {
    console.error("quickReturnToFarmHub failed", e);
    // Fallback: at least don't block the player
    try { gameState = "farmHub"; } catch(_) {}
  }
};

function loadSelectedLoadout() {
  try {
    const w = localStorage.getItem("arcSelectedWeapon");
    if (w) {
      if (typeof selectedWeaponId === "undefined") window.__pendingSelectedWeapon = w;
      else selectedWeaponId = w;
    }
    // Support both the new key (arcSelectedChar) and older builds that
    // stored the id under arc_selected_character.
    const c = localStorage.getItem("arcSelectedChar") || localStorage.getItem("arc_selected_character");
    if (c) selectedCharacterId = c;

    // If the stored id is invalid, fall back to PINK.
    try {
      const ok = (typeof CHARACTER_CONFIGS !== 'undefined' && Array.isArray(CHARACTER_CONFIGS))
        ? !!CHARACTER_CONFIGS.find(x => x && x.id === selectedCharacterId)
        : true;
      if (!ok) selectedCharacterId = 'pink';
    } catch(_) {}
  } catch {}
}

let weaponSelectOverlay = null;
    let charSelectOverlay = null;

    function applyCharacterConfig(cfg) {
  // reuse same Image objects, just swap src
  playerIdleImg.src = cfg.idleSrc;
  playerWalkImg.src = cfg.walkSrc;

  selectedCharacterId = cfg.id || selectedCharacterId;
  saveSelectedLoadout();

  // update trail color based on selected character
  if (cfg.trailColor) {
    playerTrailColor = cfg.trailColor;
  }
}
// =============================================================
function buildCharacterSelectOverlay() {
      if (charSelectOverlay) return;

      charSelectOverlay = document.createElement("div");
      charSelectOverlay.id = "character-select-overlay";
      Object.assign(charSelectOverlay.style, {
        position: "fixed",
        inset: "0",
        display: "none",
        alignItems: "center",
        justifyContent: "center",
        background:
          "radial-gradient(circle at center, rgba(15,23,42,0.94), rgba(15,23,42,0.98))",
        zIndex: "250",
        pointerEvents: "auto"
      });

      const inner = document.createElement("div");
        Object.assign(inner.style, {
    padding: "24px 28px",
    borderRadius: "22px",
    border: "1px solid rgba(148,163,184,0.8)",
    background:
      "radial-gradient(circle at 0 0, rgba(56,189,248,0.25), transparent 60%)," +
      "radial-gradient(circle at 100% 100%, rgba(250,204,21,0.25), transparent 60%)," +
      "rgba(15,23,42,0.98)",
    boxShadow: "0 28px 80px rgba(0,0,0,0.95)",
    minWidth: "420px",
    maxWidth: "720px",
    textAlign: "center",
    fontFamily: "'Press Start 2P', system-ui, sans-serif",
    color: "#e5e7eb"
  });


      const title = document.createElement("div");
      title.textContent = "CHOOSE YOUR CHARACTER";
      Object.assign(title.style, {
        fontSize: "14px",
        letterSpacing: "0.14em",
        marginBottom: "12px",
        color: "#facc15",
        textShadow: "0 0 10px rgba(250,204,21,0.9)"
      });

      const subtitle = document.createElement("div");
      subtitle.textContent = "Click to select. More heroes coming soon.";
      Object.assign(subtitle.style, {
        fontSize: "10px",
        marginBottom: "16px",
        color: "#9ca3af"
      });

      const row = document.createElement("div");
      Object.assign(row.style, {
        display: "flex",
        justifyContent: "center",
        gap: "12px",
        padding: "12px 14px",
        borderRadius: "16px",
        background:
          "linear-gradient(120deg, rgba(56,189,248,0.16), rgba(168,85,247,0.20), rgba(34,197,94,0.16))",
        boxShadow: "0 0 30px rgba(56,189,248,0.24)",
        position: "relative",
        overflow: "hidden",
        flexWrap: "wrap"
      });

      CHARACTER_CONFIGS.forEach((cfg, idx) => {
  const card = document.createElement("button");
  card.type = "button";
  card.classList.add("char-select-card");
  Object.assign(card.style, {
    cursor: "pointer",
    borderRadius: "16px",
    padding: "11px 11px 9px 11px",
    border: "1px solid rgba(148,163,184,0.85)",
    background:
      "radial-gradient(circle at 0 0, rgba(56,189,248,0.22), transparent 55%)," +
      "radial-gradient(circle at 100% 100%, rgba(168,85,247,0.25), transparent 55%)," +
      "linear-gradient(145deg, rgba(15,23,42,0.98), rgba(15,23,42,0.92))",
    color: "#e5e7eb",
    minWidth: "120px",
    maxWidth: "150px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: "6px",
    fontFamily: "'Press Start 2P', system-ui, sans-serif",
    fontSize: "9px",
    position: "relative",
    overflow: "hidden",
    transition: "transform 0.16s ease-out, box-shadow 0.16s ease-out"
  });

  card.addEventListener("mouseenter", () => {
    card.style.transform = "translateY(-4px) scale(1.03)";
    card.style.boxShadow = "0 18px 40px rgba(15,23,42,0.95), 0 0 18px rgba(129,140,248,0.9)";
  });
  card.addEventListener("mouseleave", () => {
    card.style.transform = "translateY(0) scale(1)";
    card.style.boxShadow = "none";
  });


        const imgWrapper = document.createElement("div");
Object.assign(imgWrapper.style, {
  marginTop: "6px",
  marginBottom: "8px",
  width: "56px",
  height: "56px",
  borderRadius: "999px",
  background:
    "radial-gradient(circle at 30% 20%, rgba(56,189,248,0.35), transparent 55%)," +
    "radial-gradient(circle at 70% 80%, rgba(168,85,247,0.35), transparent 55%)," +
    "rgba(15,23,42,1)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  boxShadow: "0 0 18px rgba(56,189,248,0.4)"
});


const img = document.createElement("img");
// IMPORTANT: heroes use previewSrc / idleSrc, NOT spriteSrc
img.src = cfg.previewSrc || cfg.idleSrc;
img.classList.add("char-select-sprite");
Object.assign(img.style, {
  imageRendering: "pixelated",
  width: "48px",
  height: "48px",
  objectFit: "contain",
  display: "block"
});

imgWrapper.appendChild(img);
card.appendChild(imgWrapper);



        const nameEl = document.createElement("div");
        nameEl.textContent = cfg.name;
        Object.assign(nameEl.style, {
          fontSize: "9px",
          marginTop: "2px",
          color: "#fbbf24"
        });

        const descEl = document.createElement("div");
descEl.textContent = cfg.description;
Object.assign(descEl.style, {
  fontSize: "8px",
  lineHeight: "1.4",
  color: "#9ca3af"
});

// === tiny stat bars ===
const stats = cfg.stats || { speed: 3, damage: 3, defense: 3 };

function makeStatRow(label, value) {
  const row = document.createElement("div");
  row.classList.add("char-stat-row");

  const labelEl = document.createElement("span");
  labelEl.textContent = label;
  Object.assign(labelEl.style, {
    fontSize: "7px",
    letterSpacing: "0.1em",
    color: "#e5e7eb",
    opacity: "0.85"
  });

  const bar = document.createElement("div");
  bar.classList.add("char-stat-bar");
  Object.assign(bar.style, {
    flex: "1",
    height: "6px",
    borderRadius: "999px",
    background: "rgba(15,23,42,0.95)",
    overflow: "hidden",
    boxShadow: "inset 0 0 0 1px rgba(15,23,42,0.9)"
  });

  const fill = document.createElement("div");
  fill.classList.add("char-stat-fill");
  const clamped = Math.max(0, Math.min(5, value));
  const pct = (clamped / 5) * 100;
  Object.assign(fill.style, {
    height: "100%",
    width: pct + "%",
    background: "linear-gradient(90deg,#22c55e,#a5b4fc,#facc15)",
    boxShadow: "0 0 6px rgba(129,140,248,0.9)"
  });

  bar.appendChild(fill);
  row.appendChild(labelEl);
  row.appendChild(bar);
  return row;
}

const statsContainer = document.createElement("div");
Object.assign(statsContainer.style, {
  width: "100%",
  marginTop: "8px",
  display: "flex",
  flexDirection: "column",
  gap: "4px"
});
statsContainer.appendChild(makeStatRow("SPEED",  stats.speed));
statsContainer.appendChild(makeStatRow("DAMAGE", stats.damage));
statsContainer.appendChild(makeStatRow("DEFENSE",stats.defense));

const keyHint = document.createElement("div");
keyHint.textContent = `[${idx + 1}]`;
Object.assign(keyHint.style, {
  fontSize: "8px",
  marginTop: "6px",
  opacity: "0.7"
});

card.appendChild(imgWrapper);
card.appendChild(nameEl);
card.appendChild(descEl);
card.appendChild(statsContainer);
card.appendChild(keyHint);


        card.addEventListener("click", () => {
          finishCharacterSelect(cfg);
        });

        row.appendChild(card);
      });

      const hint = document.createElement("div");
     hint.textContent = "Press 1 / 2 / 3 to pick quickly.";
      Object.assign(hint.style, {
        marginTop: "12px",
        fontSize: "9px",
        color: "#9ca3af"
      });

      inner.appendChild(title);
      inner.appendChild(subtitle);
      inner.appendChild(row);
      inner.appendChild(hint);

      charSelectOverlay.appendChild(inner);
      document.body.appendChild(charSelectOverlay);
    }

    function _startCharacterSelectImpl(context = "newRun") {
      loadoutContext = context || "newRun";
      buildCharacterSelectOverlay();
      if (charSelectOverlay) {
        charSelectOverlay.style.display = "flex";
      }
      gameState = "characterSelect";
    }

        // Quick-start a run without sprite/weapon pickers (user will add back later).
    function __arcQuickStartRunDefaults() {
      try {
        // Apply a default character config (uses last selected if available)
        const cid = (typeof selectedCharacterId === "string" ? selectedCharacterId : "base");
        const cfg = (CHARACTER_CONFIGS || []).find(c => c && c.id === cid) || (CHARACTER_CONFIGS && CHARACTER_CONFIGS[0]);
        if (cfg) applyCharacterConfig(cfg);
      } catch(e) {}

      try {
        // Default weapon + sprite
        const wcfg = (typeof WEAPON_SELECT_CONFIGS !== "undefined" && WEAPON_SELECT_CONFIGS && WEAPON_SELECT_CONFIGS[0]) ? WEAPON_SELECT_CONFIGS[0]
                     : { weaponId: "ak47", spriteSrc: "ak.png" };
        selectedWeaponId = wcfg.weaponId || "ak47";
        player.weapon = getWeaponTemplateById(selectedWeaponId);
        gunSpriteImg.src = wcfg.spriteSrc || "ak.png";
        try { saveSelectedLoadout(); } catch(_) {}
        try { const gameTitle = document.getElementById("game-title"); if (gameTitle) gameTitle.style.display = "none"; } catch(_) {}
        try { recomputeStats(); } catch(_) {}
        points = 0; kills = 0;
        gameState = "jackin";
        startJackInSequence(() => {
          startItsRainingArc();
          enterFarmHub();
        });
      } catch(e) {
        console.warn("QuickStart failed", e);
      }
    }

    // Wrapper: open customization, then quick-start the run (no sprite/weapon overlays).
    function startCharacterSelect(context = "newRun") {
      // Customization removed: always quick-start a run with defaults.
      __arcQuickStartRunDefaults();
    }



        function finishCharacterSelect(cfg) {
      applyCharacterConfig(cfg);

      if (charSelectOverlay) {
        charSelectOverlay.style.display = "none";
      }

      // If we opened this from the FarmHub sprite altar, just return to FarmHub.
      if (loadoutContext === "hubSprite") {
        gameState = "farmHub";
        toastCenter("SPRITE UPDATED");
        return;
      }

      // Otherwise continue to weapon selection
      startWeaponSelect();
    }


    function selectCharacterByIndex(idx) {
      const cfg = CHARACTER_CONFIGS[idx];
      if (!cfg) return;
      finishCharacterSelect(cfg);
    }
// === WEAPON SELECT OVERLAY ===
function buildWeaponSelectOverlay() {
  if (weaponSelectOverlay) return;

  weaponSelectOverlay = document.createElement("div");
  weaponSelectOverlay.id = "weapon-select-overlay";
  Object.assign(weaponSelectOverlay.style, {
    position: "fixed",
    inset: "0",
    display: "none",
    alignItems: "center",
    justifyContent: "center",
    background:
      "radial-gradient(circle at center, rgba(15,23,42,0.94), rgba(15,23,42,0.98))",
    zIndex: "260",
    pointerEvents: "auto"
  });

  const inner = document.createElement("div");
  Object.assign(inner.style, {
    padding: "18px 22px",
    borderRadius: "18px",
    border: "1px solid rgba(148,163,184,0.7)",
    background:
      "radial-gradient(circle at 0 0, rgba(56,189,248,0.25), transparent 60%)," +
      "radial-gradient(circle at 100% 100%, rgba(250,204,21,0.25), transparent 60%)," +
      "rgba(15,23,42,0.98)",
    boxShadow: "0 24px 70px rgba(0,0,0,0.9)",
    minWidth: "320px",
    maxWidth: "520px",
    textAlign: "center",
    fontFamily: "'Press Start 2P', system-ui, sans-serif",
    color: "#e5e7eb"
  });

  const title = document.createElement("div");
  title.textContent = "CHOOSE YOUR WEAPON";
  Object.assign(title.style, {
  fontSize: "13px",
  letterSpacing: "0.16em",
  color: "#22d3ee",
  marginBottom: "4px",
  textShadow: "0 0 10px rgba(34,197,94,0.4)",
});


  const subtitle = document.createElement("div");
  subtitle.textContent = "Click to arm up.";
  Object.assign(subtitle.style, {
    fontSize: "10px",
    marginBottom: "16px",
    color: "#9ca3af"
  });

  const row = document.createElement("div");
  Object.assign(row.style, {
    display: "flex",
    justifyContent: "center",
    gap: "20px",
    flexWrap: "wrap"
  });

  WEAPON_SELECT_CONFIGS.forEach((cfg, idx) => {
    const card = document.createElement("button");
    card.type = "button";
            Object.assign(card.style, {
      cursor: "pointer",
      position: "relative",
      borderRadius: "18px",
      padding: "16px 14px 12px 14px",
      border: "1px solid rgba(148,163,184,0.8)",
      background:
        "radial-gradient(circle at 0 0, rgba(56,189,248,0.22), rgba(15,23,42,0.98))",
      color: "#e5e7eb",
      minWidth: "160px",
      maxWidth: "200px",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: "8px",
      fontFamily: "inherit"
    });

    // Highlight AK-47 as the recommended weapon
    if (cfg.id === "ak") {
      const badge = document.createElement("div");
      badge.textContent = "RECOMMENDED";
      Object.assign(badge.style, {
        position: "absolute",
        top: "-16px",
        left: "50%",
        transform: "translateX(-50%)",
        padding: "3px 10px",
        borderRadius: "999px",
        fontSize: "8px",
        letterSpacing: "0.16em",
        textTransform: "uppercase",
        background:
          "linear-gradient(135deg, rgba(250,204,21,0.96), rgba(234,179,8,0.96))",
        color: "#111827",
        boxShadow: "0 4px 14px rgba(0,0,0,0.7)",
        pointerEvents: "none"
      });
      card.appendChild(badge);
    }

    card.addEventListener("click", () => finishWeaponSelect(cfg));

    const imgWrapper = document.createElement("div");
Object.assign(imgWrapper.style, {
  width: "56px",
  height: "56px",
  borderRadius: "999px",
  background: "radial-gradient(circle, rgba(15,23,42,1), rgba(15,23,42,0.4))",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  overflow: "hidden"
});

const img = document.createElement("img");
// IMPORTANT: weapons use spriteSrc
img.src = cfg.spriteSrc;
Object.assign(img.style, {
  imageRendering: "pixelated",
  maxHeight: "40px",
  maxWidth: "80px",
  width: "auto",
  height: "auto",
  display: "block"
});

imgWrapper.appendChild(img);
card.appendChild(imgWrapper);


    const nameEl = document.createElement("div");
    nameEl.textContent = cfg.name;
    Object.assign(nameEl.style, {
      fontSize: "11px",
      marginTop: "4px",
      color: "#fbbf24"
    });

    const descEl = document.createElement("div");
    descEl.textContent = cfg.description;
      Object.assign(descEl.style, {
      fontSize: "9px",
      lineHeight: "1.4",
      color: "#9ca3af"
    });

    const keyHint = document.createElement("div");
    keyHint.textContent = `[${idx + 1}]`;
    Object.assign(keyHint.style, {
      fontSize: "9px",
      marginTop: "6px",
      color: "#6b7280"
    });

    card.appendChild(imgWrapper);
    card.appendChild(nameEl);
    card.appendChild(descEl);
    card.appendChild(keyHint);
    row.appendChild(card);
  });

  inner.appendChild(title);
  inner.appendChild(subtitle);
  inner.appendChild(row);
  weaponSelectOverlay.appendChild(inner);
  document.body.appendChild(weaponSelectOverlay);
}

function startWeaponSelectWithContext(context = "newRun") {
  loadoutContext = context || "newRun";
  startWeaponSelect();
}

function startWeaponSelect() {
  buildWeaponSelectOverlay();
  if (weaponSelectOverlay) {
    weaponSelectOverlay.style.display = "flex";
  }
  gameState = "weaponSelect";
}

function finishWeaponSelect(cfg) {
  selectedWeaponId = cfg.weaponId;
  player.weapon = getWeaponTemplateById(cfg.weaponId);
  gunSpriteImg.src = cfg.spriteSrc;

  // persist choices
  saveSelectedLoadout();

  if (weaponSelectOverlay) {
    weaponSelectOverlay.style.display = "none";
  }

  const gameTitle = document.getElementById("game-title");
  if (gameTitle) gameTitle.style.display = "none";

  recomputeStats();

  // If we opened this from the FarmHub, just return to FarmHub.
  if (typeof loadoutContext === "string" && loadoutContext.startsWith("hub")) {
    gameState = "farmHub";
    toastCenter("LOADOUT UPDATED");
    return;
  }

  // New run: reset per-run counters so ARC / kills start from 0
  points = 0;
  kills = 0;

  gameState = "jackin";
  startJackInSequence(() => {
    // JACK-IN hype stays. We enter the FARM HUB next; the run begins when you press F at the Realm Door.
    startItsRainingArc();
    enterFarmHub();
  });
}



    function showNextIntroLine() {
  // Only react when intro is actually active AND allowed to advance
  if (gameState !== "intro" || !introReady) return;

  console.debug(
    "showNextIntroLine called, introIndex=",
    introIndex,
    "typing=",
    typing,
    "gameState=",
    gameState
  );

    // If we've shown all lines, hand off to the intro director to finish
if (introIndex >= introScript.length) {
    endIntroToCharacterSelect();
    return;
}



  // Type out the next line
  typing = true;
  dialogTextEl.textContent = "";
  dialogContinueEl.classList.remove("blink");

  let i = 0;
  const line = introScript[introIndex++];

  const interval = setInterval(() => {
    if (i < line.length) {
      dialogTextEl.textContent += line[i++];
      playTypeSound();
    } else {
      clearInterval(interval);
      typing = false;
      dialogContinueEl.classList.add("blink");
    }
  }, 30);
}

// =====================
// INTRO INPUT: SPACE / CLICK TO ADVANCE
// =====================

// Space key advances dialog – only when intro is actually ready
document.addEventListener("keydown", (e) => {
  // First, ignore anything that is not space
  const isSpace =
    e.code === "Space" || e.key === " " || e.key === "Spacebar";
  if (!isSpace) return;

  // Only react while in intro AND after introReady is set
  if (gameState !== "intro" || !introReady) return;

  // Ignore while dialog is hidden
  const dialogVisible = !dialogContainer.classList.contains("dialog-hidden");
  if (!dialogVisible) return;

  // Stop space from scrolling / typing random stuff
  e.preventDefault();

  if (!typing) {
    dialogContinueEl.classList.remove("blink");
    showNextIntroLine();
  }
});

    // Allow pressing E to skip the entire intro cutscene.  When E is pressed
// while the intro is active and ready, hide the dialog/backdrop/farmer,
// mark the intro as completed and jump straight to character select.
document.addEventListener("keydown", (e) => {
  const k = e.key.toLowerCase();

  // Purple portal at FarmHub center starts the run (yellow door portal removed)
  if (gameState === "farmHub" && k === "e") {
    const cx = FARMHUB_PORTAL_X;
    const cy = FARMHUB_PORTAL_Y;
    const dPortal = Math.hypot(player.x - cx, player.y - cy);
    if (dPortal < 90) {
      startRunFromHub();
      return;
    }
  }

  if (k !== 'e') return;
  if (gameState !== 'intro' || !introReady) return;
  // Prevent default behaviour (e.g. typing)
  e.preventDefault();
  // hand off to the intro director for a clean skip
  endIntroToCharacterSelect();
});


// Allow clicking the dialog bubble to advance (touch-friendly)
dialogContainer.addEventListener("click", (ev) => {
  if (gameState !== "intro" || !introReady) return;
  if (!typing) {
    dialogContinueEl.classList.remove("blink");
    showNextIntroLine();
  }
});

// Ensure overlay button always advances (more reliable than container click)
const dialogAdvanceBtn = document.getElementById("dialog-advance");
if (dialogAdvanceBtn) {
  dialogAdvanceBtn.addEventListener("click", (ev) => {
    ev.stopPropagation();
    if (gameState !== "intro" || !introReady) return;
    if (!typing) {
      dialogContinueEl.classList.remove("blink");
      showNextIntroLine();
    }
  });
}
// Number keys select characters while in character select
document.addEventListener("keydown", (e) => {
  if (gameState !== "characterSelect") return;

  if (e.key === "1") {
    e.preventDefault();
    selectCharacterByIndex(0); // Pink
  } else if (e.key === "2") {
    e.preventDefault();
    selectCharacterByIndex(1); // Owlet
  } else if (e.key === "3") {
    e.preventDefault();
    selectCharacterByIndex(2); // Dude
  }
});




    // Robustly wire menu buttons and log clicks

// --- Input safety: do not trigger global hotkeys while typing in text fields (preset names, etc.)
// This prevents letters like H/G from firing gameplay/UI shortcuts while you're naming presets.
document.addEventListener('keydown', (e) => {
  try {
    const ae = document.activeElement;
    if (!ae) return;
    const tag = (ae.tagName || '').toLowerCase();
    const isEditable = (tag === 'input' || tag === 'textarea' || tag === 'select' || ae.isContentEditable);
    if (!isEditable) return;
    const k = (e.key || '');
    if (k === 'Escape') return;
    e.stopPropagation();
  } catch (_) {}
}, true);


// --- Input safety: do not trigger global hotkeys while typing in text fields (preset names, search, etc.)
document.addEventListener("keydown", (e) => {
  try {
    const ae = document.activeElement;
    if (!ae) return;
    const tag = (ae.tagName || "").toLowerCase();
    const isEditable = (tag === "input" || tag === "textarea" || tag === "select" || ae.isContentEditable);
    if (!isEditable) return;
    // Let ESC keep working to close panels, and allow Tab navigation.
    const k = (e.key || "");
    if (k === "Escape" || k === "Tab") return;
    // Stop hotkey listeners on document/window from firing while the user is typing.
    e.stopImmediatePropagation();
  } catch (_) {}
}, true);



// Global handlers so the main-menu buttons also work via inline onclick

window.__onMainMenuPlay = function() {
  try {
    window.__ARC_GAME_STARTED = true;
    console.log('PLAY button handler called (zoom + intro)');
    // Kick audio immediately on first click so music/SFX aren't delayed
    if (typeof initAudio === 'function') {
      initAudio();
    }

    // Small UI beep for instant feedback on click
    if (typeof playUIBeep === 'function') {
      try {
        playUIBeep(700);
      } catch (e) {
        console.warn('UI beep failed', e);
      }
    }

    const mm = document.getElementById('main-menu');
    const tvWrapper = document.querySelector('.menu-tv-wrapper');

    // Add zoom class to main menu for CSS animation
    if (mm) {
      mm.classList.add('zoom-into-tv');
    }
    if (tvWrapper) {
      tvWrapper.style.willChange = 'transform, opacity';
    }

        // After the zoom animation finishes, hand off to the centralized intro director
    const ZOOM_DURATION = 400; // ms, keep in sync with CSS

    setTimeout(function () {
      // Hide main menu completely
      if (mm) {
        mm.style.display = "none";
        mm.style.pointerEvents = "none";
        mm.classList.remove("zoom-into-tv");
      }

      // Let the intro director decide whether to show the cutscene or skip to character select
      if (typeof beginIntroSequence === "function") {
        beginIntroSequence();
      } else if (typeof startCharacterSelect === "function") {
        // Fallback: if for some reason the intro director isn't available, go straight to select
        startCharacterSelect();
      }
    }, ZOOM_DURATION);

  } catch (e) {
    console.error('Error in __onMainMenuPlay (zoom intro)', e);
  }
};;
window.__onMainMenuSettings = function() {
  try {
    // Open settings reliably from anywhere (main menu, hub, paused run)
    if (typeof window.__openSettingsPanel === 'function') {
      window.__openSettingsPanel();
    } else {
      const pauseBtn = document.querySelector('[data-pause-action="settings"], #settings-btn');
      if (pauseBtn) pauseBtn.click();
    }
  } catch (e) {
    console.error('Error in __onMainMenuSettings', e);
  }
};

// Attach main menu button logic after the DOM has fully loaded
window.addEventListener('load', () => {
  const menuButtons = document.querySelectorAll('[data-action]');
  if (menuButtons.length === 0) {
    console.warn('No menu buttons found for main menu');
    return;
  }

  menuButtons.forEach(btn => {
    btn.addEventListener('click', (ev) => {
      const action = btn.getAttribute('data-action');
      console.log('menu button clicked:', action);

      if (action === 'play') {
        if (window.__onMainMenuPlay) {
          window.__onMainMenuPlay();
        }
        return;
      }
    });
  });

  });



// (removed) SOL claim buttons / on-chain mock UI



    // global audio context (used by intro SFX + music)
    // audioCtx declared above near dialog SFX

function playTypeSound() {
  if (!audioCtx) {
    try {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    } catch {
      return;
    }
  }

  if (audioCtx.state === "suspended") {
    audioCtx.resume();
  }

  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();

  osc.type = "triangle";

  const baseFreqs = [140, 155, 170, 185, 200];
  const base = baseFreqs[Math.floor(Math.random() * baseFreqs.length)];
  const jitter = (Math.random() - 0.5) * 20;
  osc.frequency.value = base + jitter;

  const now = audioCtx.currentTime;
  gain.gain.setValueAtTime(0, now);
  gain.gain.linearRampToValueAtTime(0.08, now + 0.01);
  gain.gain.linearRampToValueAtTime(0.0, now + 0.09);

  osc.connect(gain);
  gain.connect(audioCtx.destination);

  osc.start(now);
  osc.stop(now + 0.1);
}

let introAmbient = null;
let introGain = null;

function startIntroAmbient() {
  if (!audioCtx) {
    try {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    } catch {
      return;
    }
  }

  introAmbient = audioCtx.createOscillator();
  introGain = audioCtx.createGain();

  introAmbient.type = "sine";
  introAmbient.frequency.value = 50;
  introGain.gain.value = 0.0001;

  introAmbient.connect(introGain);
  introGain.connect(audioCtx.destination);

  const now = audioCtx.currentTime;
  introAmbient.start(now);
  introGain.gain.linearRampToValueAtTime(0.03, now + 2.0);
}

function stopIntroAmbient() {
  if (!introGain || !introAmbient) return;

  const now = audioCtx.currentTime;
  introGain.gain.cancelScheduledValues(now);
  introGain.gain.setValueAtTime(introGain.gain.value, now);
  introGain.gain.linearRampToValueAtTime(0.0001, now + 1.5);

  setTimeout(() => {
    try { introAmbient.stop(); } catch {}
    introAmbient = null;
    introGain = null;
  }, 1600);
}



// ===== BASIC SETUP =====
    const canvas = document.getElementById("game");
    let ctx = null;
    try {
      ctx = canvas.getContext("2d", { alpha: false, desynchronized: true });
      if (ctx) ctx.imageSmoothingEnabled = false;
    } catch (err) {
      console.error('Failed to get 2D context for canvas:', err);
    }

	    // Viewport size in *world units* after applying camera zoom.
	    // Kept at module-scope so any render helper can safely reference it.
	    // Updated each frame in draw().
	    let __vw = 0;
	    let __vh = 0;

    function resizeCanvas() {
      const w = Math.max(1, Math.floor(window.innerWidth));
      const h = Math.max(1, Math.floor(window.innerHeight));
      // Keep the logical coordinate system in CSS pixels (avoid breaking game math),
      // but ensure the canvas is not being blurred by CSS scaling.
      canvas.width = w;
      canvas.height = h;
      canvas.style.width = w + "px";
      canvas.style.height = h + "px";
      canvas.style.imageRendering = "pixelated";
      if (ctx) {
        ctx.imageSmoothingEnabled = false;
        // Safari/WebKit
        try { ctx.webkitImageSmoothingEnabled = false; } catch(e) {}
      }
      // keep biome overlays crisp on resize
      try { if (mapMode === 'snow') seedSnowFX(); } catch(e) {}
      try { if (mapMode === 'desert') seedSandFX(); } catch(e) {}
    }
    window.addEventListener("resize", resizeCanvas);
    resizeCanvas();
// ===== WORLD / ARENA (MAP BOUNDS) =====
// We resize the "world" to match the active map art so there are no side-bands.
// FarmHub can use a larger sandbox; combat waves use the exact PNG size.
let WORLD_WIDTH = 2600;
let WORLD_HEIGHT = 2000;

// Play lane is kept for legacy logic, but in wave maps we set it to full width.
let PLAY_LANE_WIDTH = 1400;
let PLAY_MIN_X = (WORLD_WIDTH - PLAY_LANE_WIDTH) / 2;
let PLAY_MAX_X = PLAY_MIN_X + PLAY_LANE_WIDTH;

// Active combat map bounds (Wave 1–5)
const LEVEL0_MAP_W = 1952;
const LEVEL0_MAP_H = 2000;

function setWorldBounds(w, h, laneW) {
  WORLD_WIDTH = Math.max(1, Math.floor(w || WORLD_WIDTH));
  WORLD_HEIGHT = Math.max(1, Math.floor(h || WORLD_HEIGHT));
  PLAY_LANE_WIDTH = Math.max(1, Math.floor(laneW || WORLD_WIDTH));
  PLAY_MIN_X = (WORLD_WIDTH - PLAY_LANE_WIDTH) / 2;
  PLAY_MAX_X = PLAY_MIN_X + PLAY_LANE_WIDTH;
}

// ===== FIELD TILES SETUP =====
const TILE_SIZE = 32;
const fieldTiles = [];
for (let i = 1; i <= 64; i++) {
  const img = new Image();
  const num = String(i).padStart(2, '0');
  img.src = `assets/1%20Tiles/FieldsTile_${num}.png`;
  fieldTiles.push(img);
}
// ----- MIDDLE-LANE TILESET (Tileset.png) -----
// This is a 256x256 sheet = 16x16 tiles of 16x16 pixels.
const TILESET_IMG = new Image();
TILESET_IMG.src = "Tileset.png";

// New grass tileset for the main fighting lane
const GRASS_IMG = new Image();
GRASS_IMG.src = "grass.png";
// Wave 1–5 lane background (full map PNG)
const LEVEL0_IMG = new Image();
LEVEL0_IMG.src = "level_0.png";


const FARMHUB_MAP_W = 1952;
const FARMHUB_MAP_H = 2000;
const FARMHUB_PORTAL_X = (FARMHUB_MAP_W / 2) - 220; // moved left
const FARMHUB_PORTAL_Y = (FARMHUB_MAP_H / 2) - 140; // moved slightly up
const FARMHUB_IMG = new Image();
FARMHUB_IMG.src = "farmhub.png";
const FARMHUB_PORTAL_GIF = new Image();
FARMHUB_PORTAL_GIF.src = "portal.gif";
const FARMHUB_PORTAL_SHEET = new Image();
FARMHUB_PORTAL_SHEET.src = "portal_sheet.png";
const FARMHUB_PORTAL_FRAMES = 9;
const FARMHUB_PORTAL_FPS = 12.5; // ~80ms/frame

// ===== FARM HUB SIGNAGE + SHOP NPCs =====
// NOTE: These are WORLD coordinates on the Farm Hub map.
// You can fine-tune the x/y values if you shift buildings later.
const HUB_SIGNS = [
  // BLACKSMITH (left workshop) — moved slightly down for better alignment
  { text: "BLACKSMITH", x: 520, y: 420 },

  // SHOP (inside the long house — center on the floor)
  { text: "SHOP", x: 1180, y: 520 },

  // UPGRADES (stall below the long house — nudged right + up)
  { text: "UPGRADES", x: 1185, y: 660 },
];

const HUB_NPCS = [
  // BLACKSMITH — inside workshop (slightly left)
  { key: 'blacksmith', x: 470, y: 500, img: new Image() },
  // SHOP — inside long house (moved down)
  { key: 'shop', x: 1180, y: 545, img: new Image() },
  // UPGRADES — on grass to the left of the stall (left + up)
  { key: 'upgrades', x: 900, y: 700, img: new Image() },
];

HUB_NPCS.forEach(n => {
  n.img.src = `assets/npcs/${n.key}.gif`;
});

// Wave 6–11 lane background (full map PNG)
const LEVEL2_IMG = new Image();
LEVEL2_IMG.src = "level_2.png";

// Wave 11–21 lane background (full map PNG)
const LEVEL3_IMG = new Image();
LEVEL3_IMG.src = "level_3.png";

// Wave 16–20 lane background (full map PNG)
const LEVEL5_IMG = new Image();
LEVEL5_IMG.src = "level_5.png";

// Wave 21–25 lane background (full map PNG)
const LEVEL6_IMG = new Image();
LEVEL6_IMG.src = "level_6.png";

// Late-run arena PNG (requested for waves 26–31)
const LEVEL8_IMG = new Image();
LEVEL8_IMG.src = "level_8.png";

// Wave zones (used for map transitions + gating the VOID transition portal)
function getWaveZone(w){
  const ww = Number(w) || 1;
  // After wave 31, the world breaks: enter the VOID.
  if (ww >= 32) return 'void';
  // Use the Level_8 PNG arena for waves 26–31.
  if (ww >= 26 && ww <= 31) return 'level8';
  // Custom map for mid-run
  if (ww >= 21 && ww <= 25) return 'level6';
  if (ww >= 16 && ww <= 20) return 'level5';
  if (ww >= 11) return 'level3';
  if (ww >= 6)  return 'level2';
  return 'level0';
}


// ----- FARM BRIDGE TILESET (bridge-over-water) -----
const FARM_BRIDGE_A = new Image(); FARM_BRIDGE_A.src = "assets/tiles/farm/bridgeA.png";
const FARM_BRIDGE_B = new Image(); FARM_BRIDGE_B.src = "assets/tiles/farm/bridgeB.png";
const FARM_BRIDGE_C = new Image(); FARM_BRIDGE_C.src = "assets/tiles/farm/bridgeC.png";
const FARM_BRIDGE_D = new Image(); FARM_BRIDGE_D.src = "assets/tiles/farm/bridgeD.png";
const FARM_CROPS = new Image();    FARM_CROPS.src    = "assets/tiles/farm/crops.png";


// ----- MAP MODE (farm -> desert ruins) -----
let mapMode = "farm"; // "farm" (default) or "desert"

// ===== VOID MAP (after wave 29) =====
let voidStars = [];
let voidShootingStars = [];

// ===== BIOME PARTICLES (screen-space overlays) =====
let snowFlakes = [];
let sandDust = [];

function seedSnowFX(){
  snowFlakes = [];
  // A little denser so the snow biome feels alive.
  const count = 240;
  for (let i=0;i<count;i++){
    snowFlakes.push({
      x: Math.random()*canvas.width,
      y: Math.random()*canvas.height,
      r: 0.8 + Math.random()*1.8,
      vy: 0.25 + Math.random()*0.7,
      vx: -0.15 + Math.random()*0.3,
      wob: Math.random()*Math.PI*2,
      a: 0.18 + Math.random()*0.32
    });
  }
}

function seedSandFX(){
  sandDust = [];
  // More streaks so the desert feels windy.
  const count = 190;
  for (let i=0;i<count;i++){
    sandDust.push({
      x: Math.random()*canvas.width,
      y: Math.random()*canvas.height,
      w: 26 + Math.random()*72,
      h: 1 + Math.random()*2.2,
      vx: 1.0 + Math.random()*2.4,
      vy: -0.12 + Math.random()*0.24,
      wob: Math.random()*Math.PI*2,
      a: 0.07 + Math.random()*0.16
    });
  }
}

function drawSnowOverlay(){
  if (mapMode !== 'snow' || !snowFlakes || !snowFlakes.length) return;
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  for (const f of snowFlakes) {
    ctx.globalAlpha = f.a;
    ctx.beginPath();
    ctx.arc(f.x, f.y, f.r, 0, Math.PI * 2);
    ctx.fillStyle = "#e5e7eb";
    ctx.fill();
  }
  // faint cold vignette
  ctx.globalAlpha = 0.18;
  const cx = canvas.width/2, cy = canvas.height/2;
  const g = ctx.createRadialGradient(cx, cy, Math.min(canvas.width, canvas.height)*0.15, cx, cy, Math.max(canvas.width, canvas.height)*0.72);
  g.addColorStop(0, "rgba(0,0,0,0)");
  g.addColorStop(1, "rgba(56,189,248,0.16)");
  ctx.fillStyle = g;
  ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.restore();
}

function drawSandOverlay(){
  if ((mapMode !== 'desert' && mapMode !== 'desertPNG') || !sandDust || !sandDust.length) return;
  ctx.save();
  ctx.globalAlpha = 0.14;
  ctx.globalCompositeOperation = "lighter";
  for (const d of sandDust) {
    ctx.globalAlpha = d.a;
    // draw a slanted wind streak
    ctx.save();
    const ang = -0.08 + Math.sin((d.wob || 0) + performance.now()/1200) * 0.06;
    ctx.translate(d.x, d.y);
    ctx.rotate(ang);
    ctx.fillStyle = "rgba(253,230,138,0.72)";
    ctx.fillRect(0, 0, d.w, d.h);
    ctx.restore();
  }
  // faint heat vignette
  ctx.globalAlpha = 0.10;
  const cx = canvas.width/2, cy = canvas.height/2;
  const g = ctx.createRadialGradient(cx, cy, Math.min(canvas.width, canvas.height)*0.22, cx, cy, Math.max(canvas.width, canvas.height)*0.8);
  g.addColorStop(0, "rgba(0,0,0,0)");
  g.addColorStop(1, "rgba(251,146,60,0.18)");
  ctx.fillStyle = g;
  ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.restore();
}

function seedVoidSky() {
  voidStars = [];
  voidShootingStars = [];
  const starCount = 480;
  for (let i = 0; i < starCount; i++) {
    voidStars.push({
      x: Math.random() * WORLD_WIDTH,
      y: Math.random() * WORLD_HEIGHT,
      r: 0.8 + Math.random() * 1.8,
      tw: Math.random() * Math.PI * 2,
      a: 0.35 + Math.random() * 0.55
    });
  }
}

// ===== DESERT RUINS TILEMAP (used after Wave 5) =====
// We intentionally DO NOT use a big PNG map anymore.
// We render a coherent map from the desert tileset sheets in /DesertTiles.
const DESERT_SAND_IMG = new Image();
DESERT_SAND_IMG.src = "DesertTiles/sand.png";

const DESERT_SANDSTONE_IMG = new Image();
DESERT_SANDSTONE_IMG.src = "DesertTiles/sandstone.png";

const DESERT_COBBLED_IMG = new Image();
DESERT_COBBLED_IMG.src = "DesertTiles/cobbled_sandstone.png";

// simple decor sprites (individual PNGs)
const DESERT_DECOR_SRCS = [
  "DesertTiles/decor_cactus1.png",
  "DesertTiles/decor_cactus2.png",
  "DesertTiles/decor_cactus3.png",
  "DesertTiles/decor_dead_bush1.png",
  "DesertTiles/decor_dead_bush2.png",
  "DesertTiles/decor_stone_large1.png",
  "DesertTiles/decor_stone_large2.png",
  "DesertTiles/decor_stone_medium1.png",
  "DesertTiles/decor_stone_medium2.png"
];

const desertDecorImgs = DESERT_DECOR_SRCS.map(src => {
  const img = new Image();
  img.src = src;
  return img;
});

// Desert tile sheet: 16px tiles.
const DESERT_TILE_SIZE = 16;

// A hand-authored âcoherent enoughâ ruins layout.
// 0 = sand, 1 = sandstone path, 2 = cobbled stone
const DESERT_COLS = 81;  // 81 * 32 = 2592 (fits WORLD_WIDTH 2600)
const DESERT_ROWS = 62;  // 62 * 32 = 1984 (fits WORLD_HEIGHT 2000)
let desertGround = null;

// Build the desert layout once.
function buildDesertGround() {
  const cols = DESERT_COLS;
  const rows = DESERT_ROWS;

  // 0 = sand, 1 = sandstone path, 2 = cobbled plaza
  const g = Array.from({ length: rows }, () => Array(cols).fill(0));

  // Full sand base (no void, no stripe tiles).
  const midC = Math.floor(cols / 2);
  const midR = Math.floor(rows / 2);

  // Central cobbled plaza / hub.
  const plazaW = Math.floor(cols * 0.42);
  const plazaH = Math.floor(rows * 0.32);
  const px0 = midC - Math.floor(plazaW / 2);
  const px1 = midC + Math.floor(plazaW / 2);
  const py0 = midR - Math.floor(plazaH / 2);
  const py1 = midR + Math.floor(plazaH / 2);

  for (let r = py0; r <= py1; r++) {
    if (r < 0 || r >= rows) continue;
    for (let c = px0; c <= px1; c++) {
      if (c < 0 || c >= cols) continue;
      g[r][c] = 2;
    }
  }

  // Sandstone ring around the plaza.
  for (let r = py0 - 2; r <= py1 + 2; r++) {
    if (r < 0 || r >= rows) continue;
    for (let c = px0 - 2; c <= px1 + 2; c++) {
      if (c < 0 || c >= cols) continue;
      if (g[r][c] === 0) g[r][c] = 1;
    }
  }

  // Main cross paths (sandstone).
  const pathHalf = 3;
  for (let r = 0; r < rows; r++) {
    for (let c = midC - pathHalf; c <= midC + pathHalf; c++) {
      if (c < 0 || c >= cols) continue;
      if (g[r][c] === 0) g[r][c] = 1;
    }
  }
  for (let c = 0; c < cols; c++) {
    for (let r = midR - pathHalf; r <= midR + pathHalf; r++) {
      if (r < 0 || r >= rows) continue;
      if (g[r][c] === 0) g[r][c] = 1;
    }
  }

  // Helper: fill rectangle.
  function rect(x0, y0, x1, y1, t) {
    for (let r = y0; r <= y1; r++) {
      if (r < 0 || r >= rows) continue;
      for (let c = x0; c <= x1; c++) {
        if (c < 0 || c >= cols) continue;
        g[r][c] = t;
      }
    }
  }

  // Four corner âroomsâ like a real authored map.
  const roomW = Math.floor(cols * 0.18);
  const roomH = Math.floor(rows * 0.14);

  // NW
  rect(4, 4, 4 + roomW, 4 + roomH, 1);
  rect(6 + Math.floor(roomW / 2) - 3, 6 + Math.floor(roomH / 2) - 2,
       6 + Math.floor(roomW / 2) + 3, 6 + Math.floor(roomH / 2) + 2, 2);

  // NE
  rect(cols - roomW - 6, 4, cols - 6, 4 + roomH, 1);
  rect(cols - 6 - Math.floor(roomW / 2) - 3, 6 + Math.floor(roomH / 2) - 2,
       cols - 6 - Math.floor(roomW / 2) + 3, 6 + Math.floor(roomH / 2) + 2, 2);

  // SW
  rect(4, rows - roomH - 6, 4 + roomW, rows - 6, 1);
  rect(6 + Math.floor(roomW / 2) - 3, rows - 6 - Math.floor(roomH / 2) - 2,
       6 + Math.floor(roomW / 2) + 3, rows - 6 - Math.floor(roomH / 2) + 2, 2);

  // SE
  rect(cols - roomW - 6, rows - roomH - 6, cols - 6, rows - 6, 1);
  rect(cols - 6 - Math.floor(roomW / 2) - 3, rows - 6 - Math.floor(roomH / 2) - 2,
       cols - 6 - Math.floor(roomW / 2) + 3, rows - 6 - Math.floor(roomH / 2) + 2, 2);

  // Connect rooms into the cross paths (sandstone corridors).
  rect(4 + Math.floor(roomW / 2) - 2, 4 + roomH, 4 + Math.floor(roomW / 2) + 2, midR - pathHalf, 1); // NW down
  rect(cols - 6 - Math.floor(roomW / 2) - 2, 4 + roomH, cols - 6 - Math.floor(roomW / 2) + 2, midR - pathHalf, 1); // NE down
  rect(4 + roomW, 4 + Math.floor(roomH / 2) - 2, midC - pathHalf, 4 + Math.floor(roomH / 2) + 2, 1); // NW right
  rect(midC + pathHalf, 4 + Math.floor(roomH / 2) - 2, cols - 6 - roomW, 4 + Math.floor(roomH / 2) + 2, 1); // NE left

  rect(4 + Math.floor(roomW / 2) - 2, midR + pathHalf, 4 + Math.floor(roomW / 2) + 2, rows - roomH - 6, 1); // SW up
  rect(cols - 6 - Math.floor(roomW / 2) - 2, midR + pathHalf, cols - 6 - Math.floor(roomW / 2) + 2, rows - roomH - 6, 1); // SE up
  rect(4 + roomW, rows - 6 - Math.floor(roomH / 2) - 2, midC - pathHalf, rows - 6 - Math.floor(roomH / 2) + 2, 1); // SW right
  rect(midC + pathHalf, rows - 6 - Math.floor(roomH / 2) - 2, cols - 6 - roomW, rows - 6 - Math.floor(roomH / 2) + 2, 1); // SE left

  desertGround = g;
}

function drawDesertWorldTile(sheet, tileCol, tileRow, worldX, worldY) {
  if (!sheet || !sheet.complete || sheet.naturalWidth === 0) return;
  const sx = tileCol * DESERT_TILE_SIZE;
  const sy = tileRow * DESERT_TILE_SIZE;
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(sheet, sx, sy, DESERT_TILE_SIZE, DESERT_TILE_SIZE, worldX, worldY, TILE_SIZE, TILE_SIZE);
}

function setMapMode(mode) {
  mapMode = mode;

  if (mapMode === "void") {
    // Clear biome-specific props and seed a starfield.
    decorations.length = 0;
    seedVoidSky();
    return;
  }


  if (mapMode === "snow") {
    // Snow biome: clear desert props, keep the arena art, and seed a gentle snowfall overlay.
    try { decorations.length = 0; } catch(e) {}
    try { seedSnowFX(); } catch(e) {}
    return;
  }

  if (mapMode === "desertPNG") {
    // Desert village PNG biome (level_2.png): keep the map art, but add desert vibe FX.
    // Do NOT build the desert tileset ground or random props here.
    try { seedSandFX(); } catch(e) {}
    return;
  }

  if (mapMode === "desert") {
    if (!desertGround) buildDesertGround();

    try { seedSandFX(); } catch(e) {}

    // wipe old farm look (grass tufts, treasure, etc.)
    decorations.length = 0;

    // seed desert decor across the full arena (visual only)
    const decorCount = 140;
    for (let i = 0; i < decorCount; i++) {
      const img = desertDecorImgs[Math.floor(Math.random() * desertDecorImgs.length)];
      const x = 60 + Math.random() * (WORLD_WIDTH - 120);
      const y = 60 + Math.random() * (WORLD_HEIGHT - 120);
      decorations.push({ type: "desertDecor", img, x, y });
    }
  }
}

const GRASS_TILE_SIZE = 16;
const GRASS_COLS = 25;
const GRASS_ROWS = 14;

// Uniform darkâgreen floor tile (col,row in the grass.png grid)
const GRASS_FLOOR_COL = 21;
const GRASS_FLOOR_ROW = 7;

// Decorative grass / bushes / rocks from the bottom strip
const GRASS_DECOR_TILES = [
  { col: 18, row: 12 }, { col: 19, row: 12 }, { col: 20, row: 12 },
  { col: 21, row: 12 }, { col: 22, row: 12 }, { col: 23, row: 12 }, { col: 24, row: 12 },
  { col: 18, row: 13 }, { col: 19, row: 13 }, { col: 20, row: 13 },
  { col: 21, row: 13 }, { col: 22, row: 13 }, { col: 23, row: 13 }, { col: 24, row: 13 }
];

// ----- DARK CASTLE TILES FOR RIFT REALM -----
const riftTiles = [];
for (let i = 1; i <= 25; i++) {
  const img = new Image();
  img.src = `DarkCastleTiles/DarkCastle_${i}_16x16.png`;
  riftTiles.push(img);
}


// Tileset meta
const TILESET_TILE_SIZE = 16;   // source tile size in the PNG
const TILESET_COLS = 16;        // 256 / 16

// Which tile from Tileset.png to use for the playable lane.
// (col,row) in the 16x16 grid. Change these if you want a different tile.
const MIDDLE_TILE_COL = 0;      // <-- tweak later if you want
const MIDDLE_TILE_ROW = 9;      // some of the grey path blocks
const worldCols = Math.ceil(WORLD_WIDTH / TILE_SIZE);
const worldRows = Math.ceil(WORLD_HEIGHT / TILE_SIZE);
const groundMap = [];
for (let row = 0; row < worldRows; row++) {
  groundMap[row] = [];
  for (let col = 0; col < worldCols; col++) {
    groundMap[row][col] = Math.floor(Math.random() * fieldTiles.length);
  }
}

// Recreate the tilemap with new random tiles.  This is used when restarting
// a run to keep the battlefield feeling fresh.  It re-populates the
// existing groundMap array with random indices pointing into fieldTiles.
function generateTilemap() {
  for (let r = 0; r < worldRows; r++) {
    for (let c = 0; c < worldCols; c++) {
      groundMap[r][c] = Math.floor(Math.random() * fieldTiles.length);
    }
  }
}

// ===== DECORATIONS =====
const decorImages = [];

// Build the list of decoration image paths (trees)
const baseDecorPaths = []; // still empty = only trees + treasure
const treeNames = [
  "Autumn_tree1.png",
  "Autumn_tree2.png",
  "Autumn_tree3.png",
  "Broken_tree1.png",
  "Broken_tree2.png",
  "Broken_tree3.png",
  "Broken_tree4.png",
  "Broken_tree5.png",
  "Broken_tree6.png",
  "Broken_tree7.png",
  "Burned_tree1.png",
  "Burned_tree2.png",
  "Burned_tree3.png",
  "Christmas_tree1.png",
  "Christmas_tree2.png",
  "Christmas_tree3.png",
  "Flower_tree1.png",
  "Flower_tree2.png",
  "Flower_tree3.png",
  "Fruit_tree1.png",
  "Fruit_tree2.png",
  "Fruit_tree3.png",
  "Moss_tree1.png",
  "Moss_tree2.png",
  "Moss_tree3.png",
  "Palm_tree1_1.png",
  "Palm_tree1_2.png",
  "Palm_tree1_3.png",
  "Palm_tree2_.png",
  "Palm_tree2_1.png",
  "Palm_tree2_2.png",
  "Snow_christmass_tree1.png",
  "Snow_christmass_tree2.png",
  "Snow_christmass_tree3.png",
  "Snow_tree1.png",
  "Snow_tree2.png",
  "Snow_tree3.png",
  "Tree1.png",
  "Tree2.png",
  "Tree3.png"
];

// The user’s tree PNGs live directly in assets/Trees_texture_shadow_dark
const possibleTreeFolders = [
  "assets/Trees_texture_shadow_dark"
];

const decorPaths = [];
baseDecorPaths.forEach(p => decorPaths.push(p));
treeNames.forEach(name => {
  possibleTreeFolders.forEach(folder => {
    decorPaths.push(`${folder}/${name}`);
  });
});

// turn each decor path into an Image()
decorPaths.forEach(path => {
  const img = new Image();
  img.src = path;
  decorImages.push(img);
});

// ----- NEW: treasure tiles we use as static decorations -----
// These are (column,row) in the 16x16 grid of Treasure.png
// Feel free to tweak / add more coords.
const treasureDecorTiles = [
  { col: 0, row: 0 },  // coin piles
  { col: 1, row: 0 },
  { col: 2, row: 0 },
  { col: 3, row: 0 },
  { col: 4, row: 2 },  // gold bars / blocks
  { col: 5, row: 2 },
  { col: 6, row: 2 },
  { col: 0, row: 4 },  // trophies / cups
  { col: 1, row: 4 },
  { col: 2, row: 4 },
  { col: 3, row: 4 },
  { col: 7, row: 5 },  // fancy weapons / gems
  { col: 8, row: 5 },
  { col: 9, row: 5 },
  { col: 10, row: 5 },
  { col: 0, row: 8 },  // carpets / rugs
  { col: 1, row: 8 },
  { col: 2, row: 8 },
  { col: 3, row: 8 },
  { col: 4, row: 12 }, // statues / big objects
  { col: 5, row: 12 },
  { col: 6, row: 12 },
  { col: 7, row: 12 }
];

const decorations = [];

/**
 * Decorations:
 * - Tree decorations: { img, x, y }
 * - Treasure decorations: { type:"treasure", tileCol, tileRow, size, x, y }
 * - Grass decorations: { type:"grassDecor", tileCol, tileRow, size, x, y }
 */
function initDecorations() {
  // ALL MAP DECORATIONS DISABLED
  decorations.length = 0;
  return;
}


function drawDecorations() {
  return; // decorations disabled

  decorations.forEach(obj => {
    const sx = obj.x - camera.x;
    const sy = obj.y - camera.y;

    // quick off-screen cull
    if (sx < -64 || sy < -64 || sx > canvas.width + 64 || sy > canvas.height + 64) {
      return;
    }

    // TREASURE DECORATION (from Treasure.png)
    if (obj.type === "treasure") {
      if (!powerupSheetImg || !powerupSheetImg.complete || powerupSheetImg.naturalWidth === 0) return;

      const srcX = obj.tileCol * POWERUP_TILE_SIZE;
      const srcY = obj.tileRow * POWERUP_TILE_SIZE;
      const size = obj.size || 32;

      ctx.save();
      ctx.imageSmoothingEnabled = false;

      // little shadow under treasure
      ctx.fillStyle = "rgba(15,23,42,0.85)";
      ctx.beginPath();
      ctx.ellipse(sx, sy + size * 0.3, size * 0.5, size * 0.22, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.drawImage(
        powerupSheetImg,
        srcX, srcY,
        POWERUP_TILE_SIZE, POWERUP_TILE_SIZE,
        sx - size / 2,
        sy - size / 2,
        size, size
      );

      ctx.restore();
      enemy.__didDrawSprite = true;
      return;
    }

    // GRASS DECORATION from grass.png (visual only, no collision)
    if (obj.type === "grassDecor") {
      if (!GRASS_IMG || !GRASS_IMG.complete || GRASS_IMG.naturalWidth === 0) return;

      const size = obj.size || 28;
      const srcX = obj.tileCol * GRASS_TILE_SIZE;
      const srcY = obj.tileRow * GRASS_TILE_SIZE;

      ctx.save();
      ctx.imageSmoothingEnabled = false;

      // small soft shadow under tufts
      ctx.fillStyle = "rgba(15,23,42,0.9)";
      ctx.beginPath();
      ctx.ellipse(sx, sy + size * 0.3, size * 0.5, size * 0.22, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.drawImage(
        GRASS_IMG,
        srcX, srcY,
        GRASS_TILE_SIZE, GRASS_TILE_SIZE,
        sx - size / 2,
        sy - size / 2,
        size, size
      );

      ctx.restore();
      enemy.__didDrawSprite = true;
      return;
    }

    // TREE DECORATION (existing behavior)
    if (!obj.img || !obj.img.complete || obj.img.naturalWidth === 0) return;
    ctx.drawImage(obj.img, sx, sy);
  });
}

// ===== FARM AREA SETUP =====
// We'll load a preârendered pixel farm scene and position it in the middle of the world.
// The farm is fenced off and should be nonâwalkable.
const farmImg = new Image();
// Disable loading a farm overlay; leave src empty to prevent 404 errors.
farmImg.src = "";
// Define the farm's size and position.  We place the farm off to the side rather than in the centre
// so the player can move freely in the main field.  Adjust FARM_SIZE and offsets as desired.
// The farm should sit in the centre of the world and be relatively compact.  Players
// start near the farm and protect it against incoming monsters.  Keep it small
// so it looks cute and doesn't dominate the play area.
const FARM_SIZE = 500; // world units (adjust if your image needs scaling)
// Place the farm at the centre of the map
const farmWidth = FARM_SIZE;
const farmHeight = FARM_SIZE;
const farmX = WORLD_WIDTH / 2 - FARM_SIZE / 2;
const farmY = WORLD_HEIGHT / 2 - FARM_SIZE / 2;


// A glowing Solana totem statue near the farm.
// This uses simple pixel-style rectangles and gradients so it matches the rest of the art.
const SOLANA_TOTEM_X = WORLD_WIDTH / 2;
const SOLANA_TOTEM_Y = farmY - 120; // just above the farm

function drawSolanaTotem() {
  const sx = SOLANA_TOTEM_X - camera.x;
  const sy = SOLANA_TOTEM_Y - camera.y;

  // Only draw if on screen
  if (sx < -80 || sy < -80 || sx > canvas.width + 80 || sy > canvas.height + 80) return;

  ctx.save();
  ctx.imageSmoothingEnabled = false;

  // subtle floating motion
  const floatOffset = Math.sin(animTime * 0.015) * 4;

  // halo glow
  const haloRadius = 46;
  const grad = ctx.createRadialGradient(
    sx, sy + floatOffset, 0,
    sx, sy + floatOffset, haloRadius
  );
  grad.addColorStop(0, "rgba(56,189,248,0.9)");
  grad.addColorStop(0.4, "rgba(129,140,248,0.7)");
  grad.addColorStop(1, "rgba(15,23,42,0.0)");
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(sx, sy + floatOffset, haloRadius, 0, Math.PI * 2);
  ctx.fill();

  // stone pedestal
  const baseW = 40;
  const baseH = 18;
  ctx.fillStyle = "#020617";
  ctx.fillRect(sx - baseW / 2, sy + 26 + floatOffset, baseW, baseH);
  ctx.fillStyle = "#111827";
  ctx.fillRect(sx - baseW / 2 + 3, sy + 26 + floatOffset + 3, baseW - 6, baseH - 6);

  // Solana logo-like bars (pixelated, slanted)
  const barW = 54;
  const barH = 8;

  function drawBar(yOffset, tilt) {
    ctx.save();
    ctx.translate(sx - barW / 2, sy + yOffset + floatOffset);
    ctx.transform(1, 0, tilt, 1, 0, 0);

    const barGrad = ctx.createLinearGradient(0, 0, barW, 0);
    barGrad.addColorStop(0, "#22c55e");
    barGrad.addColorStop(0.5, "#22d3ee");
    barGrad.addColorStop(1, "#a855f7");
    ctx.fillStyle = barGrad;
    ctx.fillRect(0, 0, barW, barH);

    // crisp outline
    ctx.strokeStyle = "rgba(15,23,42,0.9)";
    ctx.lineWidth = 2;
    ctx.strokeRect(0, 0, barW, barH);

    ctx.restore();
  }

  drawBar(-14, 0.25);
  drawBar(0, 0.25);
  drawBar(14, 0.25);

  ctx.restore();
}



// FarmHub animals (CraftPix pack). Decorative only; they ONLY exist in farmHub.
const farmAnimals = [];
let __farmAnimalsInited = false;
const FARM_ANIM_FRAME = 32;
const FARM_ANIMAL_AREA = { x0: 520, y0: 360, x1: 1430, y1: 1120 }; // middle area only

function __farmAnimalPickSheet() {
  // Weighted toward small cute ones. (Sheep sheet is a "group" frame, so we skip it.)
  const r = Math.random();
  if (r < 0.26) return FARM_ANIM_CHICK;
  if (r < 0.46) return FARM_ANIM_PIGLET;
  if (r < 0.68) return FARM_ANIM_LAMB;
  if (r < 0.84) return FARM_ANIM_ROOST;
  return FARM_ANIM_TURKEY;
}

function initFarmAnimals() {
  farmAnimals.length = 0;
  __farmAnimalsInited = true;

  // Hub world bounds (image-based)
  const area = FARM_ANIMAL_AREA;
  const hubX0 = area.x0;
  const hubY0 = area.y0;
  const hubW = (area.x1 - area.x0);
  const hubH = (area.y1 - area.y0);

  // Keep it light: decorative only
  const MAX_ANIMALS = 12;

  // Strong separation so we never see clumps
  const MIN_DIST = 86;
  const MIN_DIST_SAME = 140;

  // Per-species caps (prevents 4 of the same)
  const caps = {
    chick: 1,
    rooster: 1,
    turkey: 1,
    lamb: 2,
    piglet: 2,
    sheep: 0 // disabled
  };
  const counts = Object.create(null);

  const pick = () => {
    // Weighted picks (no sheep)
    const r = Math.random();
    if (r < 0.30) return { key: "lamb", sheet: FARM_ANIM_LAMB };
    if (r < 0.55) return { key: "piglet", sheet: FARM_ANIM_PIG };
    if (r < 0.72) return { key: "rooster", sheet: FARM_ANIM_ROOST };
    if (r < 0.86) return { key: "turkey", sheet: FARM_ANIM_TURKEY };
    return { key: "chick", sheet: FARM_ANIM_CHICK };
  };

  let created = 0;
  let tries = 0;
  while (created < MAX_ANIMALS && tries < 900) {
    tries++;

    const sel = pick();
    const cap = (sel && sel.key && caps[sel.key] != null) ? caps[sel.key] : 2;
    const cur = counts[sel.key] || 0;
    if (cur >= cap) continue;

    // Keep animals in the central "hub" lawn (prevents wandering into forest/edges and popping)
    const area = FARM_ANIMAL_AREA;
    const x = area.x0 + Math.random() * (area.x1 - area.x0);
    const y = area.y0 + Math.random() * (area.y1 - area.y0);

    // Separation checks
    let ok = true;
    for (const o of farmAnimals) {
      const dx = x - o.x;
      const dy = y - o.y;
      const d2 = dx * dx + dy * dy;

      const min = (o.kind === sel.key) ? MIN_DIST_SAME : MIN_DIST;
      if (d2 < min * min) { ok = false; break; }
    }
    if (!ok) continue;

    const dir = 2 + Math.floor(Math.random() * 4); // 2..5 within bounds
    farmAnimals.push({
      kind: sel.key,
      sheet: sel.sheet,
      x, y,
      vx: 0, vy: 0,
      dir,
      animSeed: Math.floor(Math.random() * 6000),
      turnT: (0.4 + Math.random() * 1.6) * 60 // frames until next turn
    });

    counts[sel.key] = cur + 1;
    created++;
  }
}


function updateFarmAnimals(dt) {
  const w = (typeof wave === 'number') ? wave : (typeof window.wave === 'number' ? window.wave : 0);
  if (gameState !== 'farmHub' || (w && w > 0)) return;
  // dt here is in "frames" (1.0 ~= 60fps) in this codebase.
  if (gameState !== "farmHub") return;
  if (!__farmAnimalsInited) initFarmAnimals();

  const hubX0 = 0;
  const hubY0 = 0;
  const hubW = FARMHUB_MAP_W;
  const hubH = FARMHUB_MAP_H;

  const margin = 56;
  const speedScale = dt; // px per frame scaling

  for (const a of farmAnimals) {
    // Occasionally pick a new wander direction (keeps it cozy).
    // Use frame-based timers so it's stable with the engine's dt.
    a.turnT = (a.turnT == null || !isFinite(a.turnT)) ? (0.6 + Math.random() * 2.0) * 60 : (a.turnT - dt);
    if (a.turnT <= 0) {
      a.turnT = (1.6 + Math.random() * 2.6) * 60; // ~seconds -> frames
      const ang = Math.random() * Math.PI * 2;
      const sp = 0.14 + Math.random() * 0.12;     // px / frame
      a.vx = Math.cos(ang) * sp;
      a.vy = Math.sin(ang) * sp;
    }

    a.x += a.vx * speedScale;
    a.y += a.vy * speedScale;

    // Bounce inside hub
    if (a.x < hubX0 + margin) { a.x = hubX0 + margin; a.vx *= -1; }
    if (a.x > hubX0 + hubW - margin) { a.x = hubX0 + hubW - margin; a.vx *= -1; }
    if (a.y < hubY0 + margin) { a.y = hubY0 + margin; a.vy *= -1; }
    if (a.y > hubY0 + hubH - margin) { a.y = hubY0 + hubH - margin; a.vy *= -1; }

    // Direction row based on velocity (4-dir)
    const dx = a.vx, dy = a.vy;
    if (Math.abs(dx) + Math.abs(dy) > 0.001) {
      if (Math.abs(dx) > Math.abs(dy)) a.dir = (dx < 0) ? 1 : 2; // left/right
      else a.dir = (dy < 0) ? 0 : 3; // up/back or down/front
    }
  }
}
function drawFarmAnimalsSprites() {
  // Animals should only be visible in calm FarmHub (not during waves/combat).
  const w = (typeof wave === 'number') ? wave : (typeof window.wave === 'number' ? window.wave : 0);
  if (gameState !== "farmHub" || (w && w > 0)) return;
  if (!farmAnimals.length) return;

  for (const a of farmAnimals) {
    const img = a.sheet;
    if (!img || !img.complete || img.naturalWidth === 0) continue;

    const sx = a.x - camera.x;
    const sy = a.y - camera.y;
    if (sx < -420 || sy < -420 || sx > canvas.width + 420 || sy > canvas.height + 420) continue;

    // Detect frame size per-sheet (CraftPix animals are usually 6x8 frames; Chick is 3x4).
    // IMPORTANT: some sheets are 192x256 which is 32px frames (even though divisible by 64).
    const w = img.naturalWidth;
    const h = img.naturalHeight;

    let frameW = FARM_ANIM_FRAME;
    let frameH = FARM_ANIM_FRAME;

    if (w % 6 === 0 && h % 8 === 0) {
      frameW = Math.floor(w / 6);
      frameH = Math.floor(h / 8);
    } else if (w % 3 === 0 && h % 4 === 0) {
      frameW = Math.floor(w / 3);
      frameH = Math.floor(h / 4);
    } else if (w % 4 === 0 && h % 4 === 0) {
      // fallback (square atlas)
      frameW = Math.floor(w / 4);
      frameH = Math.floor(h / 4);
    }
    const cols = Math.max(1, Math.floor(img.naturalWidth / frameW));
    const rows = Math.max(1, Math.floor(img.naturalHeight / frameH));

    // Many sheets are 8 rows: 4 idle + 4 walk. Some small ones are 4 rows (walk only).
    const hasIdleAndWalk = (rows >= 8);
    const moving = (Math.abs(a.vx) + Math.abs(a.vy)) > 0.01;
    const rowBase = hasIdleAndWalk ? (moving ? 4 : 0) : 0;

    // Per-animal animation timer (stable even if fps jitters)
    a.animT = (a.animT == null || !isFinite(a.animT)) ? 0 : a.animT;
    a.animT += 1; // roughly 60fps in this engine
    const frames = Math.max(1, cols);
    const frame = Math.floor((a.animT + (a.animSeed||0)) / 12) % frames; // ~5fps
    const row = Math.min(rows - 1, rowBase + (a.dir || 3));

    // Draw (feet anchored) — keep consistent scale across 32px/64px sheets
    const scale = 0.625; // 40/64
    const drawW = Math.round(frameW * scale);
    const drawH = Math.round(frameH * scale);

    // Tiny shadow for grounding (even with global shadows off)
    ctx.save();
    ctx.globalAlpha = 0.16;
    ctx.fillStyle = "#000";
    ctx.beginPath();
    // sy is the animal's "feet" point in world space
    ctx.ellipse(Math.round(sx), Math.round(sy) + 2, Math.max(6, drawW * 0.22), Math.max(2.1, drawW * 0.07), 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(
      img,
      frame * frameW, row * frameH, frameW, frameH,
      Math.round(sx - drawW / 2), Math.round(sy - drawH + 4),
      drawW, drawH
    );
    ctx.restore();
  }
}

// Preserve references so legacy helpers later in the file can't overwrite the sprite-based FarmHub animals.
const __drawFarmAnimalsSprites = drawFarmAnimalsSprites;
const __updateFarmAnimalsSprites = updateFarmAnimals;
const __initFarmAnimalsSprites = initFarmAnimals;


function randomSeeded(x, y) {
      const seed = x * 73856093 ^ y * 19349663;
      return ((seed * 9301 + 49297) % 233280) / 233280;
    }

        // Simple edge-based collision: outside the farm image is solid
function isSolidAt(px, py) {
  // Outside world = solid
  if (px < 0 || py < 0) return true;
  if (px > WORLD_WIDTH || py > WORLD_HEIGHT) return true;

  // In combat waves we run full-map (no side bands).
  // In hub/legacy modes, keep the lane restriction so décor stays non-walkable.
  if (gameState !== "playing") {
    if (px < PLAY_MIN_X || px > PLAY_MAX_X) return true;
  }

  return false;
}



    // ===== INPUT =====
const keys = {};
window.__keysRef = keys;   // <-- THIS MUST EXIST, at global scope
// Expose input state for pause/menu systems.
window.__keys = keys;
let mouseX = 0;
let mouseY = 0;
let mouseDown = false;
window.__setMouseDown = (v) => { mouseDown = !!v; };

// mark keys as held down for movement and provide some extra helpers
// We map arrow keys to their WASD equivalents so players can choose either control scheme.
// We also listen for the "R" key to restart the run when the player has died.
window.addEventListener("keydown", e => {
  try {
    const ae = document.activeElement;
    const tag = ae && ae.tagName ? ae.tagName.toLowerCase() : '';
    if (document.body && document.body.classList.contains('ui-open')) {
      // Don't capture movement/shoot keys while a modal UI is open.
      return;
    }
    if (tag === 'input' || tag === 'textarea' || tag === 'select') {
      return;
    }
  } catch(_) {}
  const k = e.key.toLowerCase();
  // Track the raw key
  keys[k] = true;
  // Map arrow keys onto WASD for movement
  if (k === 'arrowup') keys['w'] = true;
  if (k === 'arrowdown') keys['s'] = true;
  if (k === 'arrowleft') keys['a'] = true;
  if (k === 'arrowright') keys['d'] = true;

       // Allow pressing R to restart and then return to the ARC TERMINAL when the run is over
  if (k === 'r') {
    if (typeof gameOver !== 'undefined' && gameOver) {
      // Snapshot the just-finished run stats
      lastRunPoints = points;
      lastRunKills = kills;

      // Reset the run
      restartGame();

      // Then show the ARC TERMINAL hub
      if (typeof showPostIntroOverlay === "function") {
        showPostIntroOverlay();
      }

  // HUB INTERACT: Press E near NPCs / stations (handled in the FarmHub key listener below)

    }
  }
});


window.addEventListener("keyup", e => {
  try {
    const ae = document.activeElement;
    const tag = ae && ae.tagName ? ae.tagName.toLowerCase() : '';
    if (document.body && document.body.classList.contains('ui-open')) {
      return;
    }
    if (tag === 'input' || tag === 'textarea' || tag === 'select') {
      return;
    }
  } catch(_) {}
  const k = e.key.toLowerCase();
  // Unset the raw key
  keys[k] = false;
  // Also unset our WASD mapping if releasing an arrow key
  if (k === 'arrowup') keys['w'] = false;
  if (k === 'arrowdown') keys['s'] = false;
  if (k === 'arrowleft') keys['a'] = false;
  if (k === 'arrowright') keys['d'] = false;
});

// Mouse / shooting: listen on window so UI layers don't block clicks
window.addEventListener("mousemove", e => {
  // If a modal UI is open, don't update aim (and don't fight input focus).
  try {
    if (document.body && document.body.classList.contains('ui-open')) return;
  } catch(_) {}
  const rect = canvas.getBoundingClientRect();
  // Convert client coords -> canvas render-space coords.
  // This fixes aim drift in fullscreen / when CSS size != canvas size.
  const scaleX = (rect.width  ? (canvas.width  / rect.width)  : 1);
  const scaleY = (rect.height ? (canvas.height / rect.height) : 1);
  const rawX = (e.clientX - rect.left) * scaleX;
  const rawY = (e.clientY - rect.top)  * scaleY;
  // IMPORTANT: Aim must match the real pointer position 1:1.
  // "Sensitivity" should not distort absolute cursor aiming (it feels broken).
  mouseX = rawX;
  mouseY = rawY;
});

window.addEventListener("mousedown", e => {
  try {
    if (document.body && document.body.classList.contains('ui-open')) return;
  } catch(_) {}

  // --- FarmHub: click-to-select SPRITES cards (instant switch, no restart) ---
  try {
    if (e.button === 0 && gameState === "farmHub") {
      const rect = canvas.getBoundingClientRect();
      const cx = (e.clientX - rect.left) * (canvas.width / rect.width);
      const cy = (e.clientY - rect.top) * (canvas.height / rect.height);

      const __z = (typeof ARC_CAMERA_ZOOM === "number" && isFinite(ARC_CAMERA_ZOOM)) ? ARC_CAMERA_ZOOM : 1;
      const wx = camera.x + (cx / __z);
      const wy = camera.y + (cy / __z);

      // Click inside the SPRITES station selects the clicked sprite.
      if (typeof HUB_SPRITES !== "undefined" && HUB_SPRITES &&
          wx >= HUB_SPRITES.x && wx <= (HUB_SPRITES.x + HUB_SPRITES.w) &&
          wy >= HUB_SPRITES.y && wy <= (HUB_SPRITES.y + HUB_SPRITES.h)) {

        const cards = (typeof HUB_SPRITE_IMAGES !== "undefined" && Array.isArray(HUB_SPRITE_IMAGES)) ? HUB_SPRITE_IMAGES : [];
        const count = Math.min(3, cards.length || 0);
        if (count > 0) {
          // Mirror the draw positions used in drawFarmHubStations()
          const sx = HUB_SPRITES.x;
          const sy = HUB_SPRITES.y;
          const gap = 34;
          const x0 = sx + 10;
          const baseY = sy + 34;

          let picked = -1;
          for (let i = 0; i < count; i++) {
            const x = x0 + i * gap + 14;
            const dx = wx - x;
            const dy = wy - baseY;
            if ((dx*dx + dy*dy) <= (20*20)) { picked = i; break; }
          }

          if (picked >= 0) {
            const cfg = cards[picked] && cards[picked].cfg ? cards[picked].cfg : null;
            if (cfg && cfg.id) {
              selectedCharacterId = cfg.id;

              // Apply immediately
              try {
                if (typeof applyCharacterConfig === "function") applyCharacterConfig(cfg);
                else {
                  if (cfg.idleSrc) playerIdleImg.src = cfg.idleSrc;
                  if (cfg.walkSrc) playerWalkImg.src = cfg.walkSrc;
                  try { localStorage.setItem("arc_selected_character", selectedCharacterId); } catch(_) {}
                }
              } catch(_) {}

              try { if (typeof saveSelectedLoadout === "function") saveSelectedLoadout(); } catch(_) {}
              try { localStorage.setItem("arc_selected_character", selectedCharacterId); } catch(_) {}

              try { if (typeof toastCenter === "function") toastCenter("SPRITE: " + (cfg.name || cfg.id)); } catch(_) {}
            }
            // Don't start shooting when clicking hub UI
            return;
          }
        }
      }
    }
  } catch(_) {}

  if (e.button === 0) mouseDown = true;               // left click = shoot
  if (e.button === 2 && gameState === "playing") {    // right click = dash
    tryDash();
  }
});

window.addEventListener("mouseup", e => {
  try {
    if (document.body && document.body.classList.contains('ui-open')) return;
  } catch(_) {}
  if (e.button === 0) mouseDown = false;
});

window.addEventListener("contextmenu", e => e.preventDefault());



   // ===== AUDIO =====
let audioCtx = null;
let musicInterval = null;
let musicStep = 0;

// Master audio buses so Settings sliders actually work.
// We route *all* music + SFX into these GainNodes.
let __masterBus = null;
let __sfxBus = null;
let __musicBus = null;

function __ensureAudioBuses(){
  if (!audioCtx) return;
  if (__masterBus && __sfxBus && __musicBus) return;
  try {
    __masterBus = audioCtx.createGain();
    __sfxBus = audioCtx.createGain();
    __musicBus = audioCtx.createGain();
    __sfxBus.connect(__masterBus);
    __musicBus.connect(__masterBus);
    __masterBus.connect(audioCtx.destination);
  } catch(e) {}
  __applyAudioSettings();
}

function __applyAudioSettings(){
  try {
    if (!audioCtx) return;
    __ensureAudioBuses();
    const m = (typeof window.arcMasterVolume === 'number' && isFinite(window.arcMasterVolume)) ? window.arcMasterVolume : 1;
    const s = (typeof window.arcSfxVolume === 'number' && isFinite(window.arcSfxVolume)) ? window.arcSfxVolume : 1;
    const mu = (typeof window.arcMusicVolume === 'number' && isFinite(window.arcMusicVolume)) ? window.arcMusicVolume : 0.65;
    if (__masterBus) __masterBus.gain.value = Math.max(0, Math.min(1, m));
    if (__sfxBus) __sfxBus.gain.value = Math.max(0, Math.min(1, s));
    if (__musicBus) __musicBus.gain.value = Math.max(0, Math.min(1, mu));
  } catch(e) {}
}

function __sfxOut(){ __ensureAudioBuses(); return __sfxBus || (audioCtx ? audioCtx.destination : null); }
function __musicOut(){ __ensureAudioBuses(); return __musicBus || (audioCtx ? audioCtx.destination : null); }

// "farmhub" = main hub song, "village" = calm farm / menus, "cave" = intense combat
let currentMusicMood = "village";

// Hard stop for the procedural melody loop.
// Used so each biome can be truly "one soundscape" without stacking tracks.
function __stopMusicLoop(){
  try{
    if (musicInterval) {
      clearInterval(musicInterval);
      musicInterval = null;
    }
  } catch(e) {}
}

function setMusicMood(mood) {
  if (currentMusicMood === mood) return;
  currentMusicMood = mood;

  // restart background loop when mood changes
  __stopMusicLoop();
  if (audioCtx) {
    startMusic();
  }
}

// Wave-based music flavors (keeps early game vibe, then ramps up with distinct loops).
function setWaveMusicForWave(w) {
  const ww = Math.max(1, Math.floor(w || 1));
  // Keep hub/menus intact.
  if (gameState !== 'playing') return;

  // Unique wave-tier themes ONLY for 16–30 (requested).
  if (ww >= 26 && ww <= 30) return setMusicMood('wave26');
  if (ww >= 21 && ww <= 25) return setMusicMood('wave21');
  if (ww >= 16 && ww <= 20) return setMusicMood('wave16');

  // After wave 30, fall back to the normal combat loop.
  return setMusicMood('cave');
}


// ===== BIOME AMBIENCE (zone-specific vibe) =====
// We keep this separate from the melody loop so each map has its own "air".
// Routed through __musicOut() so the Music volume slider controls it.
let __biomeAmbienceNodes = [];
let __biomeAmbienceInterval = null;
let __currentBiome = "farm";

function __stopBiomeAmbience(){
  try{
    if (__biomeAmbienceInterval) { clearInterval(__biomeAmbienceInterval); __biomeAmbienceInterval = null; }
    for (const n of __biomeAmbienceNodes) {
      try { n.stop && n.stop(); } catch(e) {}
      try { n.disconnect && n.disconnect(); } catch(e) {}
      try { n.gain && n.gain.disconnect && n.gain.disconnect(); } catch(e) {}
    }
  } catch(e) {}
  __biomeAmbienceNodes = [];
}

// Tiny helper: looping noise buffer
function __makeLoopNoise(seconds=1.0){
  const sr = audioCtx.sampleRate;
  const len = Math.max(1, Math.floor(sr * seconds));
  const buf = audioCtx.createBuffer(1, len, sr);
  const d = buf.getChannelData(0);
  for (let i=0;i<len;i++){
    // pink-ish: integrate white slightly
    d[i] = (Math.random()*2-1) * 0.6;
  }
  const src = audioCtx.createBufferSource();
  src.buffer = buf;
  src.loop = true;
  return src;
}

function __startSnowAmbience(){
  // wind bed (soft, airy)
  const src = __makeLoopNoise(1.25);
  const hp = audioCtx.createBiquadFilter(); hp.type="highpass"; hp.frequency.value = 350;
  const lp = audioCtx.createBiquadFilter(); lp.type="lowpass"; lp.frequency.value = 2200;
  const g = audioCtx.createGain(); g.gain.value = 0.0;

  // gentle movement (gusts)
  const lfo = audioCtx.createOscillator(); lfo.type="sine"; lfo.frequency.value = 0.07;
  const lfoG = audioCtx.createGain(); lfoG.gain.value = 0.12;
  lfo.connect(lfoG).connect(g.gain);

  src.connect(hp).connect(lp).connect(g).connect(__musicOut());
  const now = audioCtx.currentTime;
  g.gain.setValueAtTime(0.0001, now);
  g.gain.exponentialRampToValueAtTime(0.14, now + 1.2);

  src.start(now); lfo.start(now);

  __biomeAmbienceNodes.push(src, lfo, g, hp, lp);

  // occasional icy chime (very subtle)
  __biomeAmbienceInterval = setInterval(() => {
    if (!audioCtx) return;
    const t = audioCtx.currentTime;
    const o = audioCtx.createOscillator();
    const gg = audioCtx.createGain();
    o.type = "sine";
    o.frequency.value = 780 + Math.random()*240;
    gg.gain.setValueAtTime(0.0001, t);
    gg.gain.exponentialRampToValueAtTime(0.055, t + 0.01);
    gg.gain.exponentialRampToValueAtTime(0.0001, t + 0.35);
    o.connect(gg).connect(__musicOut());
    o.start(t);
    o.stop(t + 0.4);
  }, 2200);
}

function __startDesertAmbience(){
  // dusty wind bed (lower + drier)
  const src = __makeLoopNoise(1.0);
  const bp = audioCtx.createBiquadFilter(); bp.type="bandpass"; bp.frequency.value = 520; bp.Q.value = 0.9;
  const lp = audioCtx.createBiquadFilter(); lp.type="lowpass"; lp.frequency.value = 1400;
  const g = audioCtx.createGain(); g.gain.value = 0.0;

  const lfo = audioCtx.createOscillator(); lfo.type="sine"; lfo.frequency.value = 0.05;
  const lfoG = audioCtx.createGain(); lfoG.gain.value = 0.10;
  lfo.connect(lfoG).connect(g.gain);

  src.connect(bp).connect(lp).connect(g).connect(__musicOut());
  const now = audioCtx.currentTime;
  g.gain.setValueAtTime(0.0001, now);
  g.gain.exponentialRampToValueAtTime(0.13, now + 1.2);

  src.start(now); lfo.start(now);
  __biomeAmbienceNodes.push(src, lfo, g, bp, lp);

  // distant desert "hit" / thunk occasionally
  __biomeAmbienceInterval = setInterval(() => {
    if (!audioCtx) return;
    const t = audioCtx.currentTime;
    const o = audioCtx.createOscillator();
    const gg = audioCtx.createGain();
    o.type = "sine";
    o.frequency.setValueAtTime(90, t);
    o.frequency.exponentialRampToValueAtTime(55, t + 0.28);
    gg.gain.setValueAtTime(0.0001, t);
    gg.gain.exponentialRampToValueAtTime(0.07, t + 0.02);
    gg.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);
    o.connect(gg).connect(__musicOut());
    o.start(t);
    o.stop(t + 0.55);
  }, 5200);
}

function __startVoidAmbience(){
  // creepy drone (detuned oscillators + slow tremolo)
  const now = audioCtx.currentTime;

  const o1 = audioCtx.createOscillator(); o1.type="sine"; o1.frequency.value = 48;
  const o2 = audioCtx.createOscillator(); o2.type="triangle"; o2.frequency.value = 48 * 1.01;
  const o3 = audioCtx.createOscillator(); o3.type="sine"; o3.frequency.value = 96 * 0.995;

  const g = audioCtx.createGain(); g.gain.value = 0.0;
  const lp = audioCtx.createBiquadFilter(); lp.type="lowpass"; lp.frequency.value = 520;

  const trem = audioCtx.createOscillator(); trem.type="sine"; trem.frequency.value = 0.11;
  const tremG = audioCtx.createGain(); tremG.gain.value = 0.10;
  trem.connect(tremG).connect(g.gain);

  o1.connect(lp); o2.connect(lp); o3.connect(lp);
  lp.connect(g).connect(__musicOut());

  g.gain.setValueAtTime(0.0001, now);
  g.gain.exponentialRampToValueAtTime(0.16, now + 1.4);

  o1.start(now); o2.start(now); o3.start(now); trem.start(now);
  __biomeAmbienceNodes.push(o1,o2,o3,trem,g,lp);

  // tiny shimmer blips
  __biomeAmbienceInterval = setInterval(() => {
    if (!audioCtx) return;
    const t = audioCtx.currentTime;
    const o = audioCtx.createOscillator();
    const gg = audioCtx.createGain();
    o.type = "sine";
    o.frequency.value = 420 + Math.random()*680;
    gg.gain.setValueAtTime(0.0001, t);
    gg.gain.exponentialRampToValueAtTime(0.03, t + 0.01);
    gg.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);
    o.connect(gg).connect(__musicOut());
    o.start(t);
    o.stop(t + 0.25);
  }, 2600);
}

function setBiomeVibe(biome){
  const b = biome || "farm";
  if (__currentBiome === b) return;
  __currentBiome = b;

  if (!audioCtx) return;

  __stopBiomeAmbience();

  // By default, we don't want multiple "tracks" stacking.
  // Snow/Desert/Void are pure ambience soundscapes (no melody loop).
  const ambienceOnly = (b === 'snow' || b === 'desert' || b === 'desertPNG' || b === 'void');
  if (ambienceOnly) {
    __stopMusicLoop();
  }

  // Set melody mood + start ambience
  if (b === "snow") {
    // ambience-only
    __startSnowAmbience();
  } else if (b === "desert" || b === "desertPNG") {
    // ambience-only
    __startDesertAmbience();
  } else if (b === "void") {
    // ambience-only
    __startVoidAmbience();
  } else if (b === "farmhub") {
    setMusicMood("farmhub");
    // no extra bed here; hub already has its own song vibe
  } else {
    setMusicMood("village");
  }
}

    function initAudio() {
      if (!audioCtx) {
        try {
          audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        } catch {}
      }
      if (audioCtx && audioCtx.state === "suspended") {
        audioCtx.resume();
      }
      try { __applyAudioSettings(); } catch(e) {}
      if (audioCtx && !musicInterval) {
        startMusic();
      }
      // start ambience for the current biome once audio is unlocked
      try { if (typeof setBiomeVibe === 'function') setBiomeVibe(mapMode || __currentBiome || 'farm'); } catch(e) {}
    }
    window.addEventListener("click", initAudio, { once: true });

    function playGunshot(power = 1, weaponId = "") {
      if (!audioCtx) return;
      
      // Weapon-specific shaping (AK = punchier, more "realistic" thump)
      const wid = (weaponId || "").toLowerCase();
      const isAK = wid.includes("ak");
const t0 = audioCtx.currentTime;

      // master gain so we can shape everything together
      const masterGain = audioCtx.createGain();
      masterGain.gain.value = 0.85 * power;
      masterGain.connect(__sfxOut());

      // sharp mechanical click / crack
      if (isAK) {
        const now = audioCtx.currentTime;

        // Crunchy noise burst (muzzle blast)
        const buf = audioCtx.createBuffer(1, audioCtx.sampleRate * 0.06, audioCtx.sampleRate);
        const data = buf.getChannelData(0);
        for (let i = 0; i < data.length; i++) {
          const t = i / data.length;
          data[i] = (Math.random() * 2 - 1) * Math.exp(-t * 10);
        }
        const src = audioCtx.createBufferSource();
        src.buffer = buf;

        const bp = audioCtx.createBiquadFilter();
        bp.type = "bandpass";
        bp.frequency.setValueAtTime(1500, now);
        bp.Q.value = 2.4;

        const g = audioCtx.createGain();
        g.gain.setValueAtTime(0.0001, now);
        g.gain.exponentialRampToValueAtTime(0.35 * power, now + 0.005);
        g.gain.exponentialRampToValueAtTime(0.0001, now + 0.07);

        src.connect(bp).connect(g).connect(__sfxOut());
        src.start(now);
        src.stop(now + 0.08);

        // Low thump body
        const oscL = audioCtx.createOscillator();
        const gL = audioCtx.createGain();
        oscL.type = "sine";
        oscL.frequency.setValueAtTime(120, now);
        oscL.frequency.exponentialRampToValueAtTime(70, now + 0.08);
        gL.gain.setValueAtTime(0.0001, now);
        gL.gain.exponentialRampToValueAtTime(0.22 * power, now + 0.006);
        gL.gain.exponentialRampToValueAtTime(0.0001, now + 0.09);
        oscL.connect(gL).connect(__sfxOut());
        oscL.start(now);
        oscL.stop(now + 0.1);

        return;
      }

      const osc = audioCtx.createOscillator();
      const oscGain = audioCtx.createGain();
      osc.type = "square";
      const base = 650 + Math.random() * 180;
      osc.frequency.setValueAtTime(base, t0);
      osc.frequency.exponentialRampToValueAtTime(base * 0.45, t0 + 0.09);
      oscGain.gain.setValueAtTime(0.6, t0);
      oscGain.gain.exponentialRampToValueAtTime(0.01, t0 + 0.09);
      osc.connect(oscGain);
      oscGain.connect(masterGain);
      osc.start(t0);
      osc.stop(t0 + 0.1);

      // short noise burst for the body of the shot
      const duration = 0.16;
      const sampleRate = audioCtx.sampleRate;
      const bufferSize = Math.floor(sampleRate * duration);
      const buffer = audioCtx.createBuffer(1, bufferSize, sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        const t = i / bufferSize;
        const envelope = (1 - t) * (1 - t);
        // slightly more low-mid weight so it feels like a weapon, not a dot
        data[i] = (Math.random() * 2 - 1) * envelope * power * 0.9;
      }

      const noise = audioCtx.createBufferSource();
      noise.buffer = buffer;

      const bp = audioCtx.createBiquadFilter();
      bp.type = "bandpass";
      bp.frequency.value = 1400;
      bp.Q = 0.9;

      const noiseGain = audioCtx.createGain();
      noiseGain.gain.value = 0.38 * power;

      noise.connect(bp);
      bp.connect(noiseGain);
      noiseGain.connect(masterGain);
      noise.start(t0);
      noise.stop(t0 + duration);
    }

    function playEnemyShot() {
      if (!audioCtx) return;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "square";
      osc.frequency.value = 280;
      gain.gain.setValueAtTime(0.22, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.12);
      osc.connect(gain);
      gain.connect(__sfxOut());
      osc.start();
      osc.stop(audioCtx.currentTime + 0.12);
    }
function playFootstep() {
  if (!audioCtx) return;
  const t0 = audioCtx.currentTime;

  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  const filter = audioCtx.createBiquadFilter();

  // Slight randomization for variation
  const baseFreqs = [90, 110, 130];
  const base = baseFreqs[Math.floor(Math.random() * baseFreqs.length)];
  const jitter = (Math.random() - 0.5) * 15;

  osc.type = "sine";
  osc.frequency.setValueAtTime(base + jitter, t0);

  filter.type = "lowpass";
  filter.frequency.setValueAtTime(420, t0);

  gain.gain.setValueAtTime(0.0, t0);
  gain.gain.linearRampToValueAtTime(0.18, t0 + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.25);

  osc.connect(filter);
  filter.connect(gain);
  gain.connect(__sfxOut());

  osc.start(t0);
  osc.stop(t0 + 0.25);
}

    function playUIBeep(freq = 600) {
      if (!audioCtx) return;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "triangle";
      osc.frequency.value = freq;
      gain.gain.value = 0.15;
      osc.connect(gain);
      gain.connect(__sfxOut());
      osc.start();
      osc.stop(audioCtx.currentTime + 0.12);
    }

// ===== CRAZY MODE SFX: Dash + ARC Rain (placeholder WebAudio, replace later) =====
function playDashWhoosh() {
  if (!audioCtx) return;
  const now = audioCtx.currentTime;

  // crisp whoosh
  const noiseBuf = audioCtx.createBuffer(1, audioCtx.sampleRate * 0.09, audioCtx.sampleRate);
  const data = noiseBuf.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
  const noise = audioCtx.createBufferSource();
  noise.buffer = noiseBuf;

  const filter = audioCtx.createBiquadFilter();
  filter.type = "highpass";
  filter.frequency.setValueAtTime(240, now);
  filter.frequency.linearRampToValueAtTime(1800, now + 0.085);

  const gain = audioCtx.createGain();
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(0.28, now + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.11);

  // low thump for "SHIFT feels good"
  const thumpOsc = audioCtx.createOscillator();
  thumpOsc.type = "sine";
  thumpOsc.frequency.setValueAtTime(90, now);
  thumpOsc.frequency.exponentialRampToValueAtTime(55, now + 0.08);

  const thumpGain = audioCtx.createGain();
  thumpGain.gain.setValueAtTime(0.0001, now);
  thumpGain.gain.exponentialRampToValueAtTime(0.18, now + 0.01);
  thumpGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);

  const out = __sfxOut();

  noise.connect(filter).connect(gain).connect(out);
  thumpOsc.connect(thumpGain).connect(out);

  noise.start(now);
  noise.stop(now + 0.12);

  thumpOsc.start(now);
  thumpOsc.stop(now + 0.13);
}

function playEnemyDeathSoft() {
  if (!audioCtx) return;
  const now = audioCtx.currentTime;

  // a tiny "plop" instead of harsh beep
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = "triangle";
  osc.frequency.setValueAtTime(220, now);
  osc.frequency.exponentialRampToValueAtTime(120, now + 0.08);

  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(0.06, now + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.10);

  const lp = audioCtx.createBiquadFilter();
  lp.type = "lowpass";
  lp.frequency.setValueAtTime(900, now);

  const out = __sfxOut();

  osc.connect(lp).connect(gain).connect(out);
  osc.start(now);
  osc.stop(now + 0.11);
}

function playArcRainSting() {
  if (!audioCtx) return;
  const now = audioCtx.currentTime;
  const freqs = [196, 247, 294]; // Solana-ish uplifting chord
  freqs.forEach((f, i) => {
    const osc = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(f, now);
    g.gain.setValueAtTime(0.0001, now);
    g.gain.exponentialRampToValueAtTime(0.14, now + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.45);
    const pan = audioCtx.createStereoPanner();
    pan.pan.value = (i - 1) * 0.25;
    osc.connect(g).connect(pan).connect(__sfxOut());
    osc.start(now);
    osc.stop(now + 0.5);
  });

  // glitter noise burst
  const buf = audioCtx.createBuffer(1, audioCtx.sampleRate * 0.18, audioCtx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (data.length * 0.35));
  const src = audioCtx.createBufferSource();
  src.buffer = buf;

  const bp = audioCtx.createBiquadFilter();
  bp.type = "bandpass";
  bp.frequency.setValueAtTime(2200, now);
  bp.Q.value = 6;

  const g = audioCtx.createGain();
  g.gain.setValueAtTime(0.0001, now);
  g.gain.exponentialRampToValueAtTime(0.22, now + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, now + 0.22);

  src.connect(bp).connect(g).connect(__sfxOut());
  src.start(now);
  src.stop(now + 0.25);
}

// ===== CRAZY MODE: JACK-IN boot + "ITS RAINING ARC!!" start beat =====
function startJackInSequence(onDone) {
  const overlay = document.getElementById("jackin-overlay");
  const statusEl = document.getElementById("jackin-status");
  const fillEl = document.getElementById("jackin-fill");
  if (!overlay || !statusEl || !fillEl) { onDone && onDone(); return; }

  overlay.classList.remove("hidden");
  const steps = ["LINKING WALLETâ¦", "SYNCING ARC BALANCEâ¦", "OPENING SOLANA SHARDâ¦", "THROUGHPUT: ONLINE"];
  let i = 0;
  let done = false;

  const finish = () => {
    if (done) return;
    done = true;
    overlay.classList.add("hidden");
    window.removeEventListener("keydown", onKey);
    overlay.removeEventListener("click", finish);
    onDone && onDone();
  };

  const onKey = (e) => { if (e.code === "Space" || e.code === "Enter") finish(); };
  window.addEventListener("keydown", onKey);
  overlay.addEventListener("click", finish);

  const tick = () => {
    if (done) return;
    statusEl.textContent = steps[i] || steps[steps.length - 1];
    fillEl.style.transform = `scaleX(${Math.min(1, (i + 1) / steps.length)})`;
    i++;
    if (i >= steps.length) {
      setTimeout(finish, 420);
    } else {
      setTimeout(tick, 420);
    }
  };
  tick();
}

function startItsRainingArc() {
  const overlay = document.getElementById("arc-rain-overlay");
  if (!overlay) return;
  overlay.classList.remove("hidden");
  try { playArcRainSting(); } catch {}
  // small camera shake if available
  try { shakeTime = Math.max(shakeTime, 220); shakeIntensity = Math.max(shakeIntensity, 7); } catch {}
  setTimeout(() => overlay.classList.add("hidden"), 1100);
}


    function playGlassBreak() {
      if (!audioCtx) return;
      const t0 = audioCtx.currentTime;

      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(1500, t0);
      osc.frequency.exponentialRampToValueAtTime(400, t0 + 0.18);
      gain.gain.setValueAtTime(0.28, t0);
      gain.gain.exponentialRampToValueAtTime(0.01, t0 + 0.2);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(t0);
      osc.stop(t0 + 0.2);

      const duration = 0.2;
      const sampleRate = audioCtx.sampleRate;
      const bufferSize = Math.floor(sampleRate * duration);
      const buffer = audioCtx.createBuffer(1, bufferSize, sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        const t = i / bufferSize;
        const envelope = (1 - t) * (1 - t);
        data[i] = (Math.random() * 2 - 1) * envelope * 0.7;
      }
      const src = audioCtx.createBufferSource();
      src.buffer = buffer;
      const filter = audioCtx.createBiquadFilter();
      filter.type = "highpass";
      filter.frequency.value = 1600;
      const gain2 = audioCtx.createGain();
      gain2.gain.value = 0.4;
      src.connect(filter);
      filter.connect(gain2);
      gain2.connect(audioCtx.destination);
      src.start(t0);
    }

    function playRewardChime(intensity = 1) {
      if (!audioCtx) return;
      const t0 = audioCtx.currentTime;
      const freqs = [660, 880, 990];
      freqs.forEach((f, i) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = "triangle";
        osc.frequency.value = f;
        const start = t0 + i * 0.05;
        gain.gain.setValueAtTime(0.18, start);
        gain.gain.exponentialRampToValueAtTime(0.01, start + 0.25);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(start);
        osc.stop(start + 0.3);
      });
    }


// Deep whoosh + low sweep when entering the SOLANA REALM
function playRiftEnterSound() {
  if (!audioCtx) return;
  const t0 = audioCtx.currentTime;

  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();

  osc.type = "sawtooth";
  osc.frequency.setValueAtTime(420, t0);
  osc.frequency.exponentialRampToValueAtTime(90, t0 + 0.7);

  gain.gain.setValueAtTime(0.0, t0);
  gain.gain.linearRampToValueAtTime(0.28, t0 + 0.08);
  gain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.8);

  osc.connect(gain);
  gain.connect(audioCtx.destination);
  osc.start(t0);
  osc.stop(t0 + 0.85);
}

// ===== EXTRA JUICE SFX =====
function playKillTick(intensity = 1, pitch = 1) {
  if (!audioCtx) return;
  const t0 = audioCtx.currentTime;

  const g = audioCtx.createGain();
  g.gain.value = 0.22 * intensity;
  g.connect(audioCtx.destination);

  const o = audioCtx.createOscillator();
  o.type = "triangle";
  o.frequency.setValueAtTime(760 * pitch, t0);
  o.frequency.exponentialRampToValueAtTime(240 * pitch, t0 + 0.06);

  const og = audioCtx.createGain();
  og.gain.setValueAtTime(0.0001, t0);
  og.gain.exponentialRampToValueAtTime(1.0, t0 + 0.005);
  og.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.08);

  o.connect(og);
  og.connect(g);
  o.start(t0);
  o.stop(t0 + 0.09);
}

function playElitePing() {
  playKillTick(1.2, 1.35);
}

function playBossSiren() {
  if (!audioCtx) return;
  const t0 = audioCtx.currentTime;

  const g = audioCtx.createGain();
  g.gain.value = 0.25;
  g.connect(__sfxOut());

  const o1 = audioCtx.createOscillator();
  const o2 = audioCtx.createOscillator();
  o1.type = "sawtooth";
  o2.type = "sawtooth";
  o1.frequency.setValueAtTime(220, t0);
  o2.frequency.setValueAtTime(330, t0);

  const lfo = audioCtx.createOscillator();
  const lfoG = audioCtx.createGain();
  lfo.type = "sine";
  lfo.frequency.value = 6.5;
  lfoG.gain.value = 140;
  lfo.connect(lfoG);
  lfoG.connect(o1.frequency);
  lfoG.connect(o2.frequency);

  const eg = audioCtx.createGain();
  eg.gain.setValueAtTime(0.0001, t0);
  eg.gain.exponentialRampToValueAtTime(1.0, t0 + 0.03);
  eg.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.9);

  o1.connect(eg); o2.connect(eg);
  eg.connect(g);

  lfo.start(t0);
  o1.start(t0);
  o2.start(t0);
  lfo.stop(t0 + 0.9);
  o1.stop(t0 + 0.9);
  o2.stop(t0 + 0.9);
}

function playBossPhaseShift() {
  if (!audioCtx) return;
  const t0 = audioCtx.currentTime;
  const g = audioCtx.createGain();
  g.gain.value = 0.18;
  g.connect(__sfxOut());

  const o = audioCtx.createOscillator();
  o.type = "square";
  o.frequency.setValueAtTime(110, t0);
  o.frequency.exponentialRampToValueAtTime(880, t0 + 0.22);

  const og = audioCtx.createGain();
  og.gain.setValueAtTime(0.0001, t0);
  og.gain.exponentialRampToValueAtTime(1.0, t0 + 0.03);
  og.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.28);

  o.connect(og); og.connect(g);
  o.start(t0); o.stop(t0 + 0.3);
}


    function startMusic() {
  if (!audioCtx) return;

  let scale;
  let baseFreq;
  let tempoMs;

  if (currentMusicMood === "farmhub") {
    // Upbeat chiptune loop for the FARM HUB (8-bit, fun, dopamine).
    scale = [0, 2, 4, 7, 9]; // major pentatonic
    baseFreq = 220;          // A3
    tempoMs = 420;           // faster / bouncier
  } else if (currentMusicMood === "village") {
    // Calm, floaty pentatonic
    scale = [0, 3, 5, 7, 10];
    baseFreq = 220;
    tempoMs = 520; // slower = chill
  } else if (currentMusicMood === "wave16") {
    // Mid-run: warm synthwave tension
    scale = [0, 2, 3, 5, 7, 10]; // minor-ish
    baseFreq = 196;             // G3
    tempoMs = 300;
  } else if (currentMusicMood === "wave21") {
    // Late-mid: darker, more aggressive pulse
    scale = [0, 1, 3, 5, 7, 8, 10]; // phrygian-ish
    baseFreq = 174.61;             // F3
    tempoMs = 260;
  } else if (currentMusicMood === "wave26") {
    // Endgame: high stakes, tight rhythm
    scale = [0, 2, 3, 5, 6, 8, 10]; // tense/octatonic-ish
    baseFreq = 220;                // A3
    tempoMs = 240;
  } else {
    // "Cave" / combat: faster and darker
    scale = [0, 2, 3, 5, 7, 10];
    baseFreq = 180;
    tempoMs = 320; // faster = intense
  }

  musicInterval = setInterval(() => {
    const t = audioCtx.currentTime;
    // Pattern lengths + note patterns per tier so each range feels UNIQUE.
    const mood = currentMusicMood;
    const patLen = (mood === "wave26") ? 16 : (mood === "wave21") ? 12 : 8;
    const step = musicStep++ % patLen;

    // Per-mood melodic motion (not just a rotated scale).
    let noteIndex;
    if (mood === "farmhub") {
      // Catchy 8-bit melody (pentatonic bounce + little lift)
      const p = [0,1,2,4, 2,1,0,1, 2,3,4,3, 2,1,0,4];
      noteIndex = scale[p[step % p.length] % scale.length];
    } else if (mood === "wave16") {
      // synthwave-ish arpeggio (warm tension)
      const p = [0,2,4,2, 0,3,5,3];
      noteIndex = scale[p[step % p.length] % scale.length];
    } else if (mood === "wave21") {
      // darker: descending with occasional chromatic bite
      const p = [6,4,3,2, 6,5,3,1, 6,4,2,0];
      noteIndex = scale[Math.abs(p[step % p.length]) % scale.length];
    } else if (mood === "wave26") {
      // endgame: tighter, higher tension jumps
      const p = [0,3,6,3, 1,4,6,4, 2,5,7,5, 3,6,8,6];
      noteIndex = scale[Math.abs(p[step % p.length]) % scale.length];
    } else {
      noteIndex = scale[(step + 2) % scale.length];
    }

    const freq = baseFreq * Math.pow(2, noteIndex / 12);

    // main melody
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    // Slight timbre variety per section
    osc.type = (currentMusicMood === "farmhub") ? "square"
      : (currentMusicMood === "wave21") ? "sawtooth"
      : (currentMusicMood === "wave26") ? "square"
      : "sine";
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.0, t);
    const mainAmp = (currentMusicMood === "cave") ? 0.14
      : (currentMusicMood === "wave16") ? 0.13
      : (currentMusicMood === "wave21") ? 0.12
      : (currentMusicMood === "wave26") ? 0.12
      : 0.11;
    const decay = (currentMusicMood === "cave") ? 0.28
      : (currentMusicMood === "wave26") ? 0.22
      : 0.38;
    gain.gain.linearRampToValueAtTime(mainAmp, t + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.005, t + decay);
    osc.connect(gain);
    gain.connect(__musicOut());
    osc.start(t);
    osc.stop(t + 0.45);

    // Extra groove for wave tiers (keeps it feeling like it evolves)
    if (currentMusicMood === "wave16" || currentMusicMood === "wave21" || currentMusicMood === "wave26") {
      const mood = currentMusicMood;

      // ---------- Hi-hat / tick ----------
      const hatEvery = (mood === "wave26") ? 1 : (mood === "wave21") ? 2 : 2;
      if (step % hatEvery === 1) {
        const n = audioCtx.createBufferSource();
        const b = audioCtx.createBuffer(1, Math.floor(audioCtx.sampleRate * (mood === "wave26" ? 0.02 : 0.03)), audioCtx.sampleRate);
        const d = b.getChannelData(0);
        for (let i=0;i<d.length;i++) d[i] = (Math.random()*2-1) * 0.7 * Math.exp(-i/(d.length/6));
        n.buffer = b;
        const ng = audioCtx.createGain();
        ng.gain.setValueAtTime(0.0001, t);
        const hatAmp = (mood === "wave26") ? 0.075 : (mood === "wave21") ? 0.055 : 0.045;
        ng.gain.exponentialRampToValueAtTime(hatAmp, t + 0.004);
        ng.gain.exponentialRampToValueAtTime(0.0001, t + (mood === "wave26" ? 0.035 : 0.055));
        const hp = audioCtx.createBiquadFilter();
        hp.type = "highpass";
        hp.frequency.value = (mood === "wave16") ? 1400 : (mood === "wave21") ? 2200 : 2600;
        n.connect(hp); hp.connect(ng); ng.connect(__musicOut());
        n.start(t);
        n.stop(t + 0.08);
      }

      // ---------- Kick (wave16 synthwave pulse) ----------
      if (mood === "wave16" && step % 4 === 0) {
        const kOsc = audioCtx.createOscillator();
        const kG = audioCtx.createGain();
        kOsc.type = "sine";
        kOsc.frequency.setValueAtTime(95, t);
        kOsc.frequency.exponentialRampToValueAtTime(45, t + 0.12);
        kG.gain.setValueAtTime(0.0001, t);
        kG.gain.exponentialRampToValueAtTime(0.16, t + 0.01);
        kG.gain.exponentialRampToValueAtTime(0.0001, t + 0.20);
        kOsc.connect(kG); kG.connect(__musicOut());
        kOsc.start(t);
        kOsc.stop(t + 0.22);
      }

      // ---------- Snare / clap (wave21) ----------
      if (mood === "wave21" && (step === 4 || step === 10)) {
        const n = audioCtx.createBufferSource();
        const b = audioCtx.createBuffer(1, Math.floor(audioCtx.sampleRate * 0.08), audioCtx.sampleRate);
        const d = b.getChannelData(0);
        for (let i=0;i<d.length;i++) d[i] = (Math.random()*2-1) * 0.85 * Math.exp(-i/(d.length/10));
        n.buffer = b;
        const bp = audioCtx.createBiquadFilter();
        bp.type = "bandpass";
        bp.frequency.value = 1200;
        bp.Q.value = 0.8;
        const g = audioCtx.createGain();
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(0.10, t + 0.01);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.12);
        n.connect(bp); bp.connect(g); g.connect(__musicOut());
        n.start(t);
        n.stop(t + 0.20);
      }

      // ---------- Bass (shared but shaped differently) ----------
      const bassEvery = (mood === "wave26") ? 2 : 4;
      if (step % bassEvery === 0) {
        const bass = audioCtx.createOscillator();
        const bg = audioCtx.createGain();
        bass.type = (mood === "wave26") ? "square" : "triangle";
        const bf = baseFreq / 2;
        bass.frequency.setValueAtTime(bf, t);
        bg.gain.setValueAtTime(0.0001, t);
        const bassAmp = (mood === "wave26") ? 0.12 : (mood === "wave21") ? 0.10 : 0.08;
        bg.gain.exponentialRampToValueAtTime(bassAmp, t + 0.01);
        bg.gain.exponentialRampToValueAtTime(0.0001, t + 0.30);
        const lp = audioCtx.createBiquadFilter();
        lp.type = "lowpass";
        lp.frequency.value = (mood === "wave26") ? 190 : (mood === "wave21") ? 160 : 220;
        bass.connect(lp); lp.connect(bg); bg.connect(__musicOut());
        bass.start(t);
        bass.stop(t + 0.35);
      }
    }

    // FARM HUB extras: soft kick + bass pulse so it feels like a "real" song.
    if (currentMusicMood === "farmhub") {
      // gentle kick (every 2 steps)
      if (step % 2 === 0) {
        const kOsc = audioCtx.createOscillator();
        const kG = audioCtx.createGain();
        kOsc.type = "sine";
        kOsc.frequency.setValueAtTime(110, t);
        kOsc.frequency.exponentialRampToValueAtTime(55, t + 0.12);
        kG.gain.setValueAtTime(0.0001, t);
        kG.gain.exponentialRampToValueAtTime(0.12, t + 0.01);
        kG.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
        kOsc.connect(kG);
        kG.connect(__musicOut());
        kOsc.start(t);
        kOsc.stop(t + 0.18);
      }

      // bass pulse (root / fifth alternating)
      const bass = audioCtx.createOscillator();
      const bG = audioCtx.createGain();
      bass.type = "sine";
      const bassSemis = (step % 4 === 0) ? 0 : 7;
      bass.frequency.value = (baseFreq / 2) * Math.pow(2, bassSemis / 12);
      bG.gain.setValueAtTime(0.0001, t);
      bG.gain.exponentialRampToValueAtTime(0.055, t + 0.02);
      bG.gain.exponentialRampToValueAtTime(0.0001, t + 0.48);
      bass.connect(bG);
      bG.connect(__musicOut());
      bass.start(t);
      bass.stop(t + 0.5);
    }

    // Wave 16–30+: add a low "drive" so late waves feel bigger without being loud.
    if (currentMusicMood === 'wave16' || currentMusicMood === 'wave21' || currentMusicMood === 'wave26') {
      // gated noise hat (every step)
      const n = __makeLoopNoise(0.05);
      const hp = audioCtx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 2200;
      const ng = audioCtx.createGain();
      const hatAmp = (currentMusicMood === 'wave26') ? 0.022 : (currentMusicMood === 'wave21') ? 0.018 : 0.015;
      ng.gain.setValueAtTime(0.0001, t);
      ng.gain.exponentialRampToValueAtTime(hatAmp, t + 0.01);
      ng.gain.exponentialRampToValueAtTime(0.0001, t + 0.06);
      n.connect(hp).connect(ng).connect(__musicOut());
      n.start(t);
      n.stop(t + 0.08);

      // kick (every 2 steps)
      if (step % 2 === 0) {
        const k = audioCtx.createOscillator();
        const kg = audioCtx.createGain();
        k.type = 'sine';
        const kickBase = (currentMusicMood === 'wave26') ? 85 : (currentMusicMood === 'wave21') ? 92 : 98;
        k.frequency.setValueAtTime(kickBase, t);
        k.frequency.exponentialRampToValueAtTime(kickBase * 0.55, t + 0.11);
        kg.gain.setValueAtTime(0.0001, t);
        kg.gain.exponentialRampToValueAtTime((currentMusicMood === 'wave26') ? 0.12 : 0.10, t + 0.01);
        kg.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
        k.connect(kg).connect(__musicOut());
        k.start(t);
        k.stop(t + 0.18);
      }
    }

    // pad / ambience
    if (step % 4 === 0) {
      const pad = audioCtx.createOscillator();
      const padGain = audioCtx.createGain();
      pad.type = "triangle";

      if (currentMusicMood === "farmhub") {
        pad.frequency.value = baseFreq / 2;
        padGain.gain.setValueAtTime(0.045, t);
        padGain.gain.exponentialRampToValueAtTime(0.004, t + 1.4);
      } else if (currentMusicMood === "village") {
        pad.frequency.value = baseFreq / 2;
        padGain.gain.setValueAtTime(0.04, t);
        padGain.gain.exponentialRampToValueAtTime(0.005, t + 1.2);
      } else {
        // a bit harsher + shorter in combat
        pad.frequency.value = baseFreq;
        padGain.gain.setValueAtTime(0.06, t);
        padGain.gain.exponentialRampToValueAtTime(0.003, t + 0.8);
      }

      pad.connect(padGain);
      padGain.connect(__musicOut());
      pad.start(t);
      pad.stop(t + 1.3);
    }
  }, tempoMs);
}

    // ===== PLAYER / ENTITIES =====
    const playerBase = {
      x: WORLD_WIDTH / 2,
      y: WORLD_HEIGHT / 2,
      r: 10,
      speed: 3.2,
      maxHp: 100,
      hp: 100,
      fireRate: 200,
      damage: 36,
      bulletSpeed: 7.5,
      level: 1,
      xp: 0,
      nextLevelXp: 300,
      dashSpeed: 8.5,
      dashDuration: 140,
      dashCooldown: 1100,
      headshotMultiplier: 2
    };

    let player = {};
let bullets = [];
let enemyBullets = [];
let enemies = [];
let powerups = [];

function spawnPowerup(x, y) {
      const r = Math.random();
      let kind;
      if (r < 0.25) kind = "health";
      else if (r < 0.45) kind = "damage";
      else if (r < 0.6) kind = "speed";
      else if (r < 0.75) kind = "xp";
      else if (r < 0.9) kind = "speed2x";
      else kind = "gear_or_weapon";
      powerups.push({ x, y, r: 6, kind, ttl: 15000 });
    }

// === ARC CRATE + HEART PICKUPS ===
// ARC crates carry a fixed ARC value (already includes multipliers at time of kill).
function spawnArcCrate(x, y, arcValue){
  const v = Math.max(1, Math.round(Number(arcValue) || 0));

  // Clamp into world bounds first
  let xx = Number(x) || 0;
  let yy = Number(y) || 0;

  // During active waves, keep drops inside the playable lane (prevents side-band spawns).
  try {
    const wW = (typeof WORLD_WIDTH === 'number' && isFinite(WORLD_WIDTH)) ? WORLD_WIDTH : 2600;
    const wH = (typeof WORLD_HEIGHT === 'number' && isFinite(WORLD_HEIGHT)) ? WORLD_HEIGHT : 2000;
    xx = Math.max(16, Math.min(wW - 16, xx));
    yy = Math.max(16, Math.min(wH - 16, yy));

    if (typeof wave === 'number' && wave >= 1 && typeof PLAY_LANE_WIDTH === 'number' && isFinite(PLAY_LANE_WIDTH)) {
      const laneMinX = (wW - PLAY_LANE_WIDTH) / 2;
      const laneMaxX = laneMinX + PLAY_LANE_WIDTH;
      xx = Math.max(laneMinX + 18, Math.min(laneMaxX - 18, xx));
    }

    // If it landed in a solid tile, nudge outward in a tiny spiral to find a free spot.
    if (typeof isSolidAt === 'function' && isSolidAt(xx, yy)) {
      const baseX = xx, baseY = yy;
      for (let r = 6; r <= 60; r += 6) {
        for (let a = 0; a < Math.PI * 2; a += Math.PI / 4) {
          const tx = baseX + Math.cos(a) * r;
          const ty = baseY + Math.sin(a) * r;
          if (!isSolidAt(tx, ty)) { xx = tx; yy = ty; r = 999; break; }
        }
      }
    }
  } catch(_) {}

  powerups.push({ x: xx, y: yy, r: 8, kind: "arc_crate", ttl: 18000, arcValue: v });
}
// Small hearts: tiny heal pickups (used when you are missing HP).
function spawnSmallHeart(x, y, heal){
  const h = Math.max(6, Math.round(Number(heal) || 12));
  let xx = x, yy = y;
  try {
    xx = Math.max(8, Math.min((WORLD_WIDTH || xx) - 8, xx));
    yy = Math.max(8, Math.min((WORLD_HEIGHT || yy) - 8, yy));
    if (typeof mapMode === 'string' && mapMode !== 'desertPNG') {
      if (typeof PLAY_MIN_X === 'number' && typeof PLAY_MAX_X === 'number') {
        xx = Math.max(PLAY_MIN_X + 10, Math.min(PLAY_MAX_X - 10, xx));
      }
    }
  } catch(_) {}
  powerups.push({ x: xx, y: yy, r: 7, kind: "heart_small", ttl: 15000, heal: h });
}

let damagePopups = [];

// Tiny floating damage numbers (tasteful).
function spawnDamageNumber(amount, x, y, isHeadshot=false) {
  const v = Math.max(1, Math.round(Number(amount) || 0));
  // keep it subtle; no spam from rapid multi-hit
  damagePopups.push({
    x: x + (Math.random()*6-3),
    y: y - 10 + (Math.random()*4-2),
    value: v,
    ttl: 520,
    baseTtl: 520,
    vy: 0.22 + Math.random()*0.06,
    vx: (Math.random()*0.06-0.03),
    isHeadshot: !!isHeadshot
  });
}
let arcOrbs = [];      // ← NEW: ARC magnet orbs
let particles = [];

let chaosStormActive = false;
let chaosStormEnd = 0;
let chaosStormNext = 0;
let chaosStormStrikes = []; // {x,y,t0,detAt}

let playerTrail = [];          // ← NEW: trail points
let playerTrailColor = "236, 72, 153"; // default RGB (pink)
let screenShake = 0;
let time = 0;
let points = 0;
let kills = 0;

// Lifetime totals across runs (for ARC Terminal + leaderboard vibes)
let totalArc = 0;
let totalKills = 0;


// =========================
// LIFETIME SAVE (Meta-Progression Core)
// Persists TOTAL ARC / TOTAL KILLS across sessions.
// =========================
const LIFETIME_SAVE_KEY = "arc_lifetime_v1";
let __lifetimeSaveDirty = false;
let __lifetimeSaveTimer = 0;

function loadLifetimeStats() {
  try {
    const raw = localStorage.getItem(LIFETIME_SAVE_KEY);
    if (!raw) return;
    const obj = JSON.parse(raw);
    if (obj && typeof obj === "object") {
      if (typeof obj.totalArc === "number" && isFinite(obj.totalArc)) totalArc = Math.max(0, Math.floor(obj.totalArc));
      if (typeof obj.totalKills === "number" && isFinite(obj.totalKills)) totalKills = Math.max(0, Math.floor(obj.totalKills));
    }
  } catch (e) {}
}

function __saveLifetimeStatsNow() {
  try {
    __lifetimeSaveDirty = false;
    localStorage.setItem(LIFETIME_SAVE_KEY, JSON.stringify({
      totalArc: (typeof totalArc === "number" ? Math.floor(totalArc) : 0),
      totalKills: (typeof totalKills === "number" ? Math.floor(totalKills) : 0)
    }));
  } catch (e) {}
}

function scheduleSaveLifetimeStats() {
  __lifetimeSaveDirty = true;
  if (__lifetimeSaveTimer) return;
  __lifetimeSaveTimer = setTimeout(() => {
    __lifetimeSaveTimer = 0;
    if (__lifetimeSaveDirty) __saveLifetimeStatsNow();
  }, 450);
}

function addLifetimeArc(amount) {
  const a = Number(amount) || 0;
  if (!a) return;
  totalArc = (typeof totalArc === "number" ? totalArc : 0) + a;
  try { window.totalArc = totalArc; } catch(e) {}
  scheduleSaveLifetimeStats();
}

function spendLifetimeArc(amount) {
  const a = Math.max(0, Math.floor(Number(amount) || 0));
  if (!a) return;
  totalArc = Math.max(0, (typeof totalArc === "number" ? totalArc : 0) - a);
  try { window.totalArc = totalArc; } catch(e) {}
  scheduleSaveLifetimeStats();
}

// Expose lifetime totals for overlays that are defined outside this scope.
// Without this, overlays (Shop/Void/Hub) may read TOTAL ARC as 0.
try {
  window.getLifetimeArc = () => (typeof totalArc === "number" && isFinite(totalArc)) ? Math.max(0, Math.floor(totalArc)) : 0;
  window.addLifetimeArc = addLifetimeArc;
  window.spendLifetimeArc = spendLifetimeArc;
  window.getLifetimeKills = () => (typeof totalKills === "number" && isFinite(totalKills)) ? Math.max(0, Math.floor(totalKills)) : 0;
} catch (e) {}

function addLifetimeKills(amount) {
  const a = Number(amount) || 0;
  if (!a) return;
  totalKills = (typeof totalKills === "number" ? totalKills : 0) + a;
  scheduleSaveLifetimeStats();
}

// Load once on boot
try { loadLifetimeStats(); } catch (e) {}
try { window.addEventListener("beforeunload", () => { try { __saveLifetimeStatsNow(); } catch(e) {} }); } catch (e) {}

let lastShotTime = 0;
let lastDashTime = -9999;
let dashEndTime = -9999;
let dashId = 0;
let perfectDashWindowEnd = 0;


// footstep SFX cooldown
let lastFootstepTime = 0;
const FOOTSTEP_INTERVAL = 260; // ms between steps
    let camera = { x: 0, y: 0 };

    let bossKillsTrigger = 20;
    let bossAlive = false;
    let gameOver = false;
    let lastTime = performance.now();
    let animTime = 0;
    let playerFacingAngle = 0;

    let shakeTime = 0;
    let shakeIntensity = 0;

    let lastKillTime = 0;
    let killComboCount = 0;
    let lastKillToastTime = 0;
    let lastComboRewardTier = 0;
    let lastComboRewardAt = 0;
let lastEnemyDeathSfxAt = 0;

const DOUBLE_KILL_WINDOW = 1200;

let xpMultiplier = 1;

// === WAVE SYSTEM ===
let wave = 1;
let waveEnemiesTarget = 0;
let waveEnemiesSpawned = 0;
let waveEnemiesKilled = 0;
let waveInBreak = false;
let waveBreakEndTime = 0;
let waveBreakRequiresPortal = false;
let waveSpawnCooldown = 0;
let waveBossSpawned = false;
let currentWaveConfig = null;

// === MID-WAVE EVENTS (little surprises / retention juice) ===
let waveStartedAt = 0;
let waveEventPlanned = false;
let waveEventAt = 0;
let waveEventDone = false;


// Next-wave "VOID" portal (appears after clearing a wave)
let nextWavePortalActive = false;
let nextWavePortalX = 0;
let nextWavePortalY = 0;
let nextWavePortalPulse = 0;
let waveWarpActive = false;
let waveWarpT = 0; // 0..1

// Auto-enter countdown for zone changes (replaces "Press E")
const WAVE_PORTAL_COUNTDOWN_MS = 7000;
let wavePortalCountdownActive = false;
let wavePortalCountdownEnd = 0;
let wavePortalCountdownDurationMs = WAVE_PORTAL_COUNTDOWN_MS;

// simple screen flash for wave transitions (VFX)
let waveFlashAlpha = 0;

// ===== CINEMATIC JUICE =====
let slowMoTime = 0;      // seconds of temporary slow-motion
let bossPulseAlpha = 0;  // 0..1 vignette pulse during boss phases

// === RIFT DUNGEONS ===
let inRift = false;
let riftDepth = 0;
let riftEnemiesTarget = 0;
let riftEnemiesSpawned = 0;
let riftEnemiesKilled = 0;
let riftSpawnCooldown = 0;
let riftPortalActive = false;
let riftPortalX = 0;
let riftPortalY = 0;
let pendingWaveAfterRift = null;
let riftEnterFlash = 0;   // 0..1 fade when entering SOLANA REALM


// === ARC MULTIPLIER / STREAK ===
let arcMultiplier = 1;            // how much ARC is multiplied
let arcStreak = 0;                // number of kills in streak
let arcStreakLastKillTime = 0;    // timestamp of last streak kill
const ARC_STREAK_WINDOW = 4000;   // ms allowed between kills

// === RUN GOAL + RUN SUMMARY (must-have retention loop) ===
let runGoal = null;              // {id,label,target,unit}
let runStartTime = 0;
let wavesCleared = 0;
  try { if (typeof window.resetVoidPointRunFlag === 'function') window.resetVoidPointRunFlag(); } catch(e) {};
let networkEventsCleared = 0;
let perfectDashCount = 0;
let bestArcStreak = 0;
let runGoalCompleted = false;
let runGoalWasDone = false;

function pickRunGoal() {
  runGoalWasDone = false;
  runGoalCompleted = false;
  // Keep goals simple + readable. All use stats we already track.
  const pool = [
    { id: "survive_waves", label: "Survive to Wave", target: 8, unit: "wave" },
    { id: "earn_arc",      label: "Earn ARC",       target: 2500, unit: "arc" },
    { id: "streak",        label: "Reach Kill Streak", target: 12, unit: "streak" },
    { id: "perfect_dash",  label: "Perfect Dashes", target: 3, unit: "count" },
    { id: "net_events",    label: "Clear Network Events", target: 2, unit: "count" },
  ];

  // Slight scaling based on player level if available
  const lvl = (window.player && window.player.level) ? window.player.level : 1;

  const g = pool[Math.floor(Math.random() * pool.length)];
  const goal = { ...g };

  if (goal.id === "survive_waves") goal.target = (lvl <= 2 ? 8 : 10);
  if (goal.id === "earn_arc")      goal.target = (lvl <= 2 ? 2500 : 4000);
  if (goal.id === "streak")        goal.target = (lvl <= 2 ? 12 : 16);

  runGoal = goal;
  runGoalCompleted = false;
  renderRunGoalHUD();
}

function getRunGoalProgress() {
  if (!runGoal) return { cur: 0, target: 1, done: false };

  let cur = 0;
  if (runGoal.id === "survive_waves") cur = wave; // current wave reached
  if (runGoal.id === "earn_arc") cur = points;
  if (runGoal.id === "streak") cur = arcStreak;
  if (runGoal.id === "perfect_dash") cur = perfectDashCount;
  if (runGoal.id === "net_events") cur = networkEventsCleared;

  const target = runGoal.target || 1;
  const done = cur >= target;
  return { cur, target, done };
}

function renderRunGoalHUD() {
  const panel = document.getElementById("run-goal-panel");
  if (!panel) return;

  // Only show in active play
  if (typeof gameState !== "undefined" && gameState !== "playing") {
    panel.style.display = "none";
    return;
  }
  panel.style.display = "block";

  const titleEl = document.getElementById("run-goal-title");
  const subEl = document.getElementById("run-goal-sub");
  const fillEl = document.getElementById("run-goal-bar-fill");
  const footEl = document.getElementById("run-goal-foot");

  if (!runGoal) {
    if (titleEl) titleEl.textContent = "Run Goal";
    if (subEl) subEl.textContent = "…";
    if (fillEl) fillEl.style.width = "0%";
    if (footEl) footEl.textContent = "";
    return;
  }

  const p = getRunGoalProgress();
  const pct = Math.max(0, Math.min(1, p.cur / p.target));
  if (titleEl) titleEl.textContent = p.done ? "Run Goal ✅" : "Run Goal";
  if (p.done && !runGoalWasDone) onRunGoalCompleted();
  runGoalWasDone = p.done;
  if (subEl) subEl.textContent = runGoal.label + " " + runGoal.target;
  if (fillEl) fillEl.style.width = (pct * 100).toFixed(1) + "%";
  if (footEl) footEl.textContent = p.cur.toLocaleString() + " / " + p.target.toLocaleString();
}


function onRunGoalCompleted() {
  // Fire once per goal completion
  if (runGoalCompleted) return;
  runGoalCompleted = true;

  // Celebration banner (uses your existing system banner)
  if (typeof showSystemBanner === "function") {
    showSystemBanner("🏁 GOAL COMPLETE! +BONUS", 1700);
  } else if (typeof toastCenter === "function") {
    toastCenter("GOAL COMPLETE! +BONUS");
  }

  // Reward: small ARC + small heal
  const base = (runGoal && typeof runGoal.target === "number") ? runGoal.target : 1000;
  const bonusArc = Math.max(250, Math.floor(base * 0.10));
  if (typeof points === "number") points += bonusArc;

  try {
    if (typeof player !== "undefined" && player && typeof player.hp === "number") {
      const maxHp =
        (typeof player.maxHp === "number") ? player.maxHp :
        (typeof player.maxHP === "number") ? player.maxHP :
        (typeof player.hpMax === "number") ? player.hpMax :
        player.hp;
      const heal = Math.max(8, Math.floor(maxHp * 0.15));
      player.hp = Math.min(maxHp, player.hp + heal);
    }
  } catch (e) {}

  // Optional: quick screen shake for juice
  if (typeof triggerShake === "function") triggerShake(8);

  // Roll a new goal shortly after so the HUD stays meaningful
  setTimeout(() => {
    runGoalCompleted = false;
    pickRunGoal();
    runGoalWasDone = false;
    renderRunGoalHUD();
  }, 450);
}



function buildRunSummaryHTML() {
  const durMs = Math.max(0, performance.now() - (runStartTime || performance.now()));
  const mins = Math.floor(durMs / 60000);
  const secs = Math.floor((durMs % 60000) / 1000);

  const p = getRunGoalProgress();
  const goalLine = runGoal
    ? (runGoal.label + " " + runGoal.target + " — " + (p.done ? "COMPLETED ✅" : "Not completed"))
    : "None";

  const muts = (typeof runMutations !== "undefined" && Array.isArray(runMutations) && runMutations.length)
    ? runMutations.map(m => "• " + m).join("<br/>")
    : "None";

  return `
    <div style="font-weight:800; letter-spacing:0.2px; margin-bottom:6px;">RUN SUMMARY</div>
    <div style="opacity:0.9;">Goal: <span style="color:#facc15;">${goalLine}</span></div>
    <div style="margin-top:6px;">Waves cleared: <b>${Math.max(0, wave-1)}</b></div>
    <div>ARC earned: <b>${points.toLocaleString()}</b></div>
    <div>Kills: <b>${kills.toLocaleString()}</b></div>
    <div>Best streak: <b>${bestArcStreak}</b></div>
    <div>Perfect dashes: <b>${perfectDashCount}</b></div>
    <div>Network events cleared: <b>${networkEventsCleared}</b></div>
    <div style="margin-top:8px; opacity:0.9;">Time survived: <b>${mins}m ${secs}s</b></div>
    <div style="margin-top:8px; opacity:0.85;">
      Mutations this run:<br/>
      <span style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', monospace; font-size:11px;">${muts}</span>
    </div>
  `;
}



// =====================================================
// ARC MUTATIONS (roguelite run modifiers) + NETWORK EVENTS
// =====================================================
let runMutations = [];          // array of mutation ids active this run
let mutationRollWave = 1;       // which wave we rolled (debug)
function hasMutation(id) { return runMutations.indexOf(id) !== -1; }

// --- HUD refs (Mutation panel) ---
let mutationsPanelEl = null;
let mutationsListEl = null;
let netEventNameEl = null;
let netEventBarFillEl = null;
let netEventBarWrapEl = null;

function initMutationsHUD() {
  try {
    mutationsPanelEl = document.getElementById("mutations-panel");
    mutationsListEl  = document.getElementById("mutations-list");
    netEventNameEl   = document.getElementById("netevent-name");
    netEventBarFillEl= document.getElementById("netevent-timerbar-fill");
    netEventBarWrapEl= document.getElementById("netevent-timerbar");
  } catch (e) {}
}

function showMutationsHUD(show) {
  if (!mutationsPanelEl) return;
  mutationsPanelEl.classList.toggle("hidden", !show);
}

const MUTATION_POOL = [
  {
    id: "corrupted_yield",
    name: "Corrupted Yield",
    desc: "+40% ARC gain, but kills may spawn mini-swarms."
  },
  {
    id: "validator_lag",
    name: "Validator Lag",
    desc: "Dash cooldown +45%, but dashing triggers brief slow-mo."
  },
  {
    id: "mev_predator",
    name: "MEV Predator",
    desc: "Bosses drop extra ARC, but elites spawn a bit more often."
  },
  {
    id: "glass_cannon",
    name: "Glass Cannon",
    desc: "+25% damage, -18% max HP."
  }
];

function renderMutationsHUD() {
  if (!mutationsPanelEl || !mutationsListEl) return;

  // list mutations
  const lines = runMutations.map(id => {
    const m = MUTATION_POOL.find(x => x.id === id);
    if (!m) return "• " + id;
    return "• " + m.name;
  });

  mutationsListEl.textContent = lines.length ? lines.join("\n") : "• None";

  // network event line
  if (netEventNameEl) {
    netEventNameEl.textContent = networkEvent ? networkEvent.label : "None";
  }

  // event timer bar
  if (netEventBarFillEl && netEventBarWrapEl) {
    if (!networkEvent) {
      netEventBarWrapEl.style.display = "none";
    } else {
      netEventBarWrapEl.style.display = "block";
      const ratio = Math.max(0, Math.min(1, (networkEvent.end - performance.now()) / networkEvent.duration));
      netEventBarFillEl.style.transform = "scaleX(" + ratio + ")";
    }
  }
}

function rollRunMutations(now) {
  runMutations = [];
  mutationRollWave = wave || 1;

  // Roll 1 mutation always, 2nd mutation from wave 4+, 3rd from wave 8+
  let rollCount = 1;
  if (wave >= 4 && Math.random() < 0.55) rollCount++;
  if (wave >= 8 && Math.random() < 0.35) rollCount++;

  const pool = MUTATION_POOL.slice();
  for (let i = 0; i < rollCount && pool.length; i++) {
    const idx = Math.floor(Math.random() * pool.length);
    const m = pool.splice(idx, 1)[0];
    runMutations.push(m.id);
  }

  // Apply immediate stat impacts
  try {
    if (hasMutation("validator_lag")) {
      // Make it hurt, but not unplayable
      player.dashCooldown = Math.max(500, Math.round(player.dashCooldown * 1.45));
      player.baseDashCooldown = player.dashCooldown;
    }
    if (hasMutation("glass_cannon")) {
      player.damage = Math.round(player.damage * 1.25);
      player.bodyDamage = player.damage;
      player.maxHp = Math.max(40, Math.round(player.maxHp * 0.82));
      player.hp = Math.min(player.hp, player.maxHp);
    }
  } catch (e) {}

  // Hype toast (one line, readable)
  try {
    const names = runMutations.map(id => (MUTATION_POOL.find(x => x.id === id)?.name || id));
    showSystemBanner("MUTATION: " + names.join(" + "), 3200);
  } catch (e) {}

  // debug hook
  window.__arcMutations = runMutations.slice();

  // refresh HUD
  renderMutationsHUD();
}

// === NETWORK EVENTS (mid-run chaos) ===
// networkEvent: { type, label, start, end, duration, t, data }
// === ARC OVERDRIVE (streak-based hype mode) ===
let overdriveActive = false;
let overdriveEndAt = 0;
let overdriveCooldownUntil = 0;

function maybeStartOverdrive(now) {
  if (overdriveActive) return;
  if (now < overdriveCooldownUntil) return;

  // requires meaningful streak / multiplier
  if (typeof arcMultiplier !== "number") return;
  if (arcMultiplier < 2.5) return;

  overdriveActive = true;
  overdriveEndAt = now + 9000;
  overdriveCooldownUntil = now + 26000;

  try { showSystemBanner("â¡ ARC OVERDRIVE", 2600); } catch (e) {}
  try { playRewardChime(); } catch (e) {}
  try { triggerShake(6); } catch (e) {}
}

function stopOverdrive() {
  if (!overdriveActive) return;
  overdriveActive = false;
  try { showSystemBanner("OVERDRIVE ENDED", 1800); } catch (e) {}
}

let networkEvent = null;
let nextNetworkEventAt = 0;

function scheduleNextNetworkEvent(now) {
  // 18–36 seconds
  nextNetworkEventAt = now + (18000 + Math.random() * 18000);
}

// Helpers for fast & safe spawns
function spawnEventEnemy(type, x, y) {
  try {
    // Some spawnEnemy implementations accept optional x,y (yours does in multiple places)
    spawnEnemy(type, x, y);
  } catch (e) {
    try { spawnEnemy(type); } catch {}
  }
}

function startNetworkEvent(type, now) {
  const common = (label, durationMs) => {
    networkEvent = {
      type,
      label,
      start: now,
      end: now + durationMs,
      duration: durationMs,
      t: 0,
      data: {}
    };
    waveFlashAlpha = Math.max(waveFlashAlpha, 0.9);
    triggerShake(10);
    showSystemBanner("â  NETWORK EVENT: " + label.toUpperCase(), 3400);
    playRewardChime();
    // optional CSS vibe hooks
    document.body.classList.toggle("event-blackout", type === "blackout");
    renderMutationsHUD();
  };

  if (type === "arc_storm_DISABLED") {
    common("ARC Storm", 12000);
    networkEvent.data.spawnCd = 0;
    return;
  }

  if (type === "portal_breach") {
    common("Portal Breach", 14000);
    networkEvent.data.spawnCd = 0;
    networkEvent.data.portalX = player.x + (Math.random() * 2 - 1) * 220;
    networkEvent.data.portalY = player.y + (Math.random() * 2 - 1) * 180;
    return;
  }

  
if (type === "bounty_protocol") {
  common("Bounty Protocol", 14000);
  networkEvent.data.spawned = false;
  networkEvent.data.bountyAlive = false;
  return;
}

if (type === "packet_rush") {
  common("Packet Rush", 12000);
  networkEvent.data.spawnCd = 0;
  return;
}

if (type === "blackout") {
    common("Validator Blackout", 10000);
    // subtle speed buff to enemies during blackout (handled in update)
    networkEvent.data.pulseCd = 0;
    return;
  }
}

function stopNetworkEvent() {
  if (!networkEvent) return;
  networkEventsCleared += 1;
  renderRunGoalHUD();
  document.body.classList.remove("event-blackout");
  showSystemBanner(networkEvent.label.toUpperCase() + " CLEARED", 2400);
  playUIBeep(520);
  networkEvent = null;
  renderMutationsHUD();
}

function pickRandomNetworkEvent() {
  // Keep it spicy but readable. Weight ARC Storm slightly higher.
  const pool = [
    "arc_storm_DISABLED", "arc_storm_DISABLED",
    "portal_breach",
    "blackout"
  ];
  return pool[Math.floor(Math.random() * pool.length)];
}

function updateNetworkEvents(dt, now) {
  if (gameState !== "playing" || gameOver) return;
  if (inRift) return; // keep rifts clean

  // streak-based hype mode
  try {
    if (!overdriveActive) maybeStartOverdrive(now);
    if (overdriveActive && now >= overdriveEndAt) stopOverdrive();
  } catch(e) {}

  if (!nextNetworkEventAt) scheduleNextNetworkEvent(now);

  if (!networkEvent && now >= nextNetworkEventAt && wave >= 2) {
    startNetworkEvent(pickRandomNetworkEvent(), now);
    scheduleNextNetworkEvent(now);
  }

  if (!networkEvent) return;

  // End condition
  if (now >= networkEvent.end) {
    stopNetworkEvent();
    return;
  }

  // Update timer + UI
  networkEvent.t += dt;
  renderMutationsHUD();

  // ---- PORTAL BREACH ----
  if (networkEvent.type === "portal_breach") {
    networkEvent.data.spawnCd -= dt;
    if (networkEvent.data.spawnCd <= 0) {
      networkEvent.data.spawnCd = 0.7;
      const px = networkEvent.data.portalX;
      const py = networkEvent.data.portalY;
      const aliveNonBoss = enemies.filter(e => !e.isBoss).length;
      const cap = Math.min(38 + wave * 2, 70);
      if (aliveNonBoss < cap) {
        const r = Math.random();
        // lean elites sometimes
        const t = r < 0.35 ? "elite" : (r < 0.68 ? "fast" : "swarm");
        spawnEventEnemy(t, px + (Math.random() * 2 - 1) * 60, py + (Math.random() * 2 - 1) * 60);
        triggerShake(2);
      }
    }
    // small slow-mo hits to sell portal vibes
    if (Math.random() < 0.02) slowMoTime = Math.max(slowMoTime, 0.03);
    return;
  }

  
// ---- BOUNTY PROTOCOL ----
if (networkEvent.type === "bounty_protocol") {
  if (!networkEvent.data.spawned) {
    networkEvent.data.spawned = true;
    const bx = player.x + (Math.random() * 2 - 1) * 220;
    const by = player.y + (Math.random() * 2 - 1) * 180;
    try {
      spawnEventEnemy("elite", bx, by);
      // mark the most recent elite as bounty (best-effort)
      const elite = enemies.slice().reverse().find(e => e && e.type === "elite" && !e.isBoss);
      if (elite) {
        elite.__isBounty = true;
        elite.__bountyValue = 360 + wave * 45;
        elite.__bountyHeal = 14;
        networkEvent.data.bountyAlive = true;
      }
    } catch (e) {}
    triggerShake(4);
    showSystemBanner("ð¯ BOUNTY TARGET SPAWNED", 2600);
  }

  if (networkEvent.data.bountyAlive) {
    const still = enemies.some(e => e && e.__isBounty && !e.isBoss);
    if (!still) {
      networkEvent.data.bountyAlive = false;
      showSystemBanner("BOUNTY CLAIMED", 2200);
      networkEvent.end = Math.min(networkEvent.end, now);
    }
  }
  if (Math.random() < 0.015) slowMoTime = Math.max(slowMoTime, 0.02);
  return;
}

// ---- PACKET RUSH ----
if (networkEvent.type === "packet_rush") {
  networkEvent.data.spawnCd -= dt;
  if (networkEvent.data.spawnCd <= 0) {
    networkEvent.data.spawnCd = 0.85;
    const aliveNonBoss = enemies.filter(e => !e.isBoss).length;
    const cap = Math.min(42 + wave * 2, 78);
    if (aliveNonBoss < cap) {
      const r = Math.random();
      const t = r < 0.55 ? "fast" : (r < 0.82 ? "swarm" : "splitter");
      spawnEventEnemy(t);
    }
  }
  if (Math.random() < 0.05) triggerShake(1);
  return;
}

// ---- BLACKOUT ----
  if (networkEvent.type === "blackout") {
    // occasional pulse
    networkEvent.data.pulseCd -= dt;
    if (networkEvent.data.pulseCd <= 0) {
      networkEvent.data.pulseCd = 1.1;
      triggerShake(2);
      slowMoTime = Math.max(slowMoTime, 0.02);
    }
    return;
  }
}

let xpBoostActive = false;
let xpBoostEndTime = 0;
let xpBoostDuration = 8000;

    let speedBoostActive = false;
    let speedBoostEndTime = 0;
    let speedBoostDuration = 6000;
    let baseMoveSpeed = playerBase.speed;

    // === AURORA MOUNTAIN SKY BACKGROUND ===
    const skyBgImg = new Image();
    // Disable loading the nebula sky; leave src empty to prevent 404 errors
    skyBgImg.src = "";
    let skyBgLoaded = false;
    skyBgImg.onload = () => {
      skyBgLoaded = true;
    };


    // SIMPLE moon craters so drawSky won't throw
    const moonCraters = [
      { angle: -0.8, dist: 0.28, radius: 5 },
      { angle: 0.3, dist: 0.4, radius: 8 },
      { angle: 1.1, dist: 0.12, radius: 4 },
      { angle: -1.6, dist: 0.48, radius: 6 }
    ];

    // SKY: one consolidated implementation (stars + moon + nebula)
    const skyStars = [];
    let skyInitDone = false;

    function initSky() {
      skyStars.length = 0;
      const starCount = 120;
      for (let i = 0; i < starCount; i++) {
        skyStars.push({
          x: Math.random(),
          y: Math.random() * 0.9,
          size: 0.6 + Math.random() * 1.3,
          depth: 0.3 + Math.random() * 0.7,
          twSpeed: 0.6 + Math.random() * 1.4,
          phase: Math.random() * Math.PI * 2
        });
      }
      skyInitDone = true;
    }

        function drawSky() {
      if (!skyInitDone) initSky();

      // 1) basic dark fill as safety background
      ctx.fillStyle = "#020617";
      ctx.fillRect(0, 0, __vw, __vh);

      // 2) draw aurora mountain PNG as a parallax background
      if (skyBgLoaded && skyBgImg.naturalWidth > 0 && skyBgImg.naturalHeight > 0) {
        const viewW = canvas.width;
        const viewH = canvas.height;

        const imgW = skyBgImg.naturalWidth;
        const imgH = skyBgImg.naturalHeight;
        const imgAspect = imgW / imgH;

        // scale image so it always covers the whole screen
        let targetH = viewH;
        let targetW = targetH * imgAspect;

        if (targetW < viewW) {
          // if it's not wide enough, base on width instead
          targetW = viewW;
          targetH = targetW / imgAspect;
        }

        // slow parallax so sky moves a little with camera
        const parallax = 0.18; // smaller = slower movement
        const camX = camera.x * parallax;

        // tile horizontally so huge maps never "run out" of sky
        let offsetX = -(camX % targetW);
        if (offsetX > 0) offsetX -= targetW;

        // anchor mountains so bottom of image sits at bottom of screen
        const offsetY = viewH - targetH;

        for (let x = offsetX; x < viewW + targetW; x += targetW) {
          ctx.drawImage(
            skyBgImg,
            0, 0, imgW, imgH,
            x, offsetY,
            targetW, targetH
          );
        }
      }

      // 3) OPTIONAL: soft stars on top of the sky (keeps the vibe)
      ctx.save();
      const t = performance.now() * 0.001;
      for (const s of skyStars) {
        const parallax = 0.25 * s.depth;
        const sx = s.x * canvas.width - camera.x * parallax;
        const sy = s.y * canvas.height * 0.9 - camera.y * parallax * 0.3;
        if (sx < -20 || sx > canvas.width + 20 || sy < -20 || sy > canvas.height + 20) continue;

        const tw = 0.5 + 0.5 * Math.sin(t * s.twSpeed + s.phase);
        const r = s.size * (0.6 + tw * 0.8);
        ctx.globalAlpha = 0.3 + tw * 0.5;
        ctx.beginPath();
        ctx.arc(sx, sy, r, 0, Math.PI * 2);
        ctx.fillStyle = "#e5e7eb";
        ctx.fill();
      }
      ctx.restore();
    }


    // wind streaks
    const windLines = [];
    function initWind() {
      for (let i = 0; i < 18; i++) {
        windLines.push({
          x: WORLD_WIDTH / 2 - 500 + Math.random() * 1000,
          y: WORLD_HEIGHT / 2 - 500 + Math.random() * 1000,
          vx: 0.18 + Math.random() * 0.3
        });
      }
    }

    // ===== FALLING LEAVES AROUND TREES (WORLD SPACE) =====
function updateGroundLeaves(dt) {
  const speedScale = dt * 60;

  groundLeaves.forEach(l => {
    if (l.y < l.groundY) {
      l.y += l.vy * speedScale;
      l.swayPhase += l.swaySpeed * speedScale;
      l.x += Math.sin(l.swayPhase) * 0.2 * speedScale * 0.1;
    } else {
      if (Math.random() < 0.0009 * speedScale) {
        l.y = l.startY;
        l.swayPhase = Math.random() * Math.PI * 2;
      }
    }
  });
}

function drawGroundLeaves() {
  if (!groundLeaves.length) return;

  ctx.save();

  groundLeaves.forEach(l => {
    const sx = l.x - camera.x;
    const sy = l.y - camera.y;
    if (sx < -40 || sy < -40 || sx > canvas.width + 40 || sy > canvas.height + 40) return;

    ctx.save();
    ctx.translate(sx, sy);
    ctx.rotate(Math.sin(l.swayPhase) * 0.4);

    const s = l.size;
    const grad = ctx.createLinearGradient(-s, -s, s, s);

    if (l.tint < 0.33) {
      grad.addColorStop(0, "rgba(34,197,94,0.0)");
      grad.addColorStop(0.5, "rgba(74,222,128,0.9)");
      grad.addColorStop(1, "rgba(21,128,61,0.0)");
    } else if (l.tint < 0.66) {
      grad.addColorStop(0, "rgba(250,204,21,0.0)");
      grad.addColorStop(0.5, "rgba(234,179,8,0.9)");
      grad.addColorStop(1, "rgba(161,98,7,0.0)");
    } else {
      grad.addColorStop(0, "rgba(248,113,113,0.0)");
      grad.addColorStop(0.5, "rgba(239,68,68,0.9)");
      grad.addColorStop(1, "rgba(127,29,29,0.0)");
    }

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.ellipse(0, 0, s * 1.2, s * 0.7, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  });

  ctx.restore();
}

// ===== CINEMATIC FALLING LEAVES (screen-space overlay) =====
const leafParticles = [];

function makeLeaf(x, y) {
  return {
    x,
    y,
    vy: 0.35 + Math.random() * 0.6,
    vx: -0.2 + Math.random() * 0.4,
    size: 8 + Math.random() * 10,
    rotation: Math.random() * Math.PI * 2,
    spin: (Math.random() * 0.03 + 0.01) * (Math.random() < 0.5 ? 1 : -1),
    swayPhase: Math.random() * Math.PI * 2,
    swaySpeed: 0.02 + Math.random() * 0.04,
    tint: Math.random()
  };
}

function initLeaves() {
  leafParticles.length = 0;

  const count = Math.floor((canvas.width * canvas.height) / 60000);
  const clamped = Math.max(15, Math.min(45, count));

  for (let i = 0; i < clamped; i++) {
    leafParticles.push(
      makeLeaf(
        Math.random() * canvas.width,
        Math.random() * canvas.height
      )
    );
  }
}

function updateLeaves(dt) {
  const speedScale = dt * 60;

  for (let i = 0; i < leafParticles.length; i++) {
    const l = leafParticles[i];

    l.x += l.vx * speedScale;
    l.y += l.vy * speedScale;
    l.rotation += l.spin * speedScale;
    l.swayPhase += l.swaySpeed * speedScale;
    l.x += Math.sin(l.swayPhase) * 0.35 * speedScale * 0.1;

    if (l.y - l.size > canvas.height + 40 || l.x < -80 || l.x > canvas.width + 80) {
      leafParticles[i] = makeLeaf(
        Math.random() * (canvas.width + 200) - 100,
        -40 - Math.random() * canvas.height * 0.4
      );
    }
  }
}

function drawLeaves() {
  if (!leafParticles.length) return;

  ctx.save();
  ctx.globalAlpha = 0.7;

  leafParticles.forEach(l => {
    const sx = l.x;
    const sy = l.y;

    if (sx < -60 || sx > canvas.width + 60 || sy < -60 || sy > canvas.height + 80) return;

    ctx.save();
    ctx.translate(sx, sy);
    ctx.rotate(l.rotation);

    const s = l.size;
    const grad = ctx.createLinearGradient(-s, -s, s, s);

    if (l.tint < 0.33) {
      grad.addColorStop(0, "rgba(34,197,94,0.0)");
      grad.addColorStop(0.5, "rgba(74,222,128,0.85)");
      grad.addColorStop(1, "rgba(21,128,61,0.0)");
    } else if (l.tint < 0.66) {
      grad.addColorStop(0, "rgba(250,204,21,0.0)");
      grad.addColorStop(0.5, "rgba(234,179,8,0.85)");
      grad.addColorStop(1, "rgba(161,98,7,0.0)");
    } else {
      grad.addColorStop(0, "rgba(248,113,113,0.0)");
      grad.addColorStop(0.5, "rgba(239,68,68,0.85)");
      grad.addColorStop(1, "rgba(127,29,29,0.0)");
    }

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(0, -s);
    ctx.quadraticCurveTo(s, 0, 0, s);
    ctx.quadraticCurveTo(-s, 0, 0, -s);
    ctx.fill();

    ctx.restore();
  });

  ctx.restore();
}

// ===== UI ELEMENTS =====
const hpBar = document.getElementById("hp-bar");
const xpBar = document.getElementById("xp-bar");
const arcStreakBar   = document.getElementById("arc-streak-bar");      // ok if null
const hpLabel        = document.getElementById("hp-label");
const xpLabel        = document.getElementById("xp-label");
const arcStreakLabel = document.getElementById("arc-streak-label") || document.getElementById("arc-streak-value");    // ok if null
const levelLabel     = document.getElementById("level-label");
const pointsLabel    = document.getElementById("points-label");
const arcMultLabel   = document.getElementById("arc-mult-label");      // may be null, that's fine
const killsLabel     = document.getElementById("kills-label");
const dashLabel      = document.getElementById("dash-label");
const bossLabel      = document.getElementById("boss-label");
const bossbar        = document.getElementById("bossbar");
const bossbarFill    = document.getElementById("bossbar-fill");
const bossbarHp      = document.getElementById("bossbar-hp");
const bossbarName    = document.getElementById("bossbar-name");
const gameOverEl     = document.getElementById("game-over");
const gameOverStatsEl = document.getElementById("game-over-stats");
const restartBtn     = document.getElementById("restart-btn");

    const ach1Fill = document.getElementById("ach-1-fill");
    const ach2Fill = document.getElementById("ach-2-fill");
    const ach3Fill = document.getElementById("ach-3-fill");
    const ach1Meta = document.getElementById("ach-1-meta");
    const ach2Meta = document.getElementById("ach-2-meta");
    const ach3Meta = document.getElementById("ach-3-meta");

    const mainMenu = document.getElementById("main-menu");

    const centerToast = document.getElementById("center-toast");
    const portalHint = document.getElementById("portal-hint");

    // Zone transition summary (shown only when swapping to a NEW map/tileset)
    const zoneSummaryOverlay = document.getElementById("zone-summary-overlay");
    const zoneSummaryTitle   = document.getElementById("zone-summary-title");
    const zoneSummarySub     = document.getElementById("zone-summary-sub");
    const zoneSummaryRelics  = document.getElementById("zone-summary-relics");
    const zoneSummaryStats   = document.getElementById("zone-summary-stats");
    const zoneSummaryNext    = document.getElementById("zone-summary-next");
    const zoneSummaryTimerValue = document.getElementById("zone-summary-timer-value");
    const zoneSummaryTimerFill  = document.getElementById("zone-summary-timer-fill");

    const xpBoostWrapper = document.getElementById("xp-boost-wrapper");
    const xpBoostFill = document.getElementById("xp-boost-fill");
    const speedBoostWrapper = document.getElementById("speed-boost-wrapper");
    const speedBoostFill = document.getElementById("speed-boost-fill");

    // upgrade panel
    const upgradeOverlay = document.getElementById("upgrade-overlay");
    const upgradeArcLabel = document.getElementById("upgrade-arc-label");
    const weaponInfoEl = document.getElementById("weapon-info");
    const gearInfoEl = document.getElementById("gear-info");
    const rollWeaponBtn = document.getElementById("roll-weapon-btn");
    const rollGearBtn = document.getElementById("roll-gear-btn");
    const closeUpgradeBtn = document.getElementById("close-upgrade-btn");
    let upgradeOpen = false;
    // LEVEL-UP overlay
    const levelUpOverlay = document.getElementById("levelup-overlay");
    const levelUpButtons = levelUpOverlay
      ? levelUpOverlay.querySelectorAll("[data-upgrade]")
      : [];
    let levelUpOpen = false;
    let pendingLevelUps = 0;

// ===== Leveling / XP helpers (restored for Rift rewards) =====
function openLevelUpOverlay() {
      if (!levelUpOverlay) return;
      levelUpOpen = true;
      gameState = "upgrade"; // pause main update loop
      levelUpOverlay.style.display = "flex";
    }

function closeLevelUpOverlay() {
      if (!levelUpOverlay) return;
      levelUpOverlay.style.display = "none";
      levelUpOpen = false;

      pendingLevelUps = Math.max(0, pendingLevelUps - 1);
      if (pendingLevelUps > 0) {
        // immediately process the next queued level-up
        openLevelUpOverlay();
      } else {
        gameState = "playing";
  try { showMutationsHUD(true); } catch(e) {}
      }
    }

function triggerLevelUp() {
      playUIBeep(650);
      if (levelUpOpen) {
        // already picking an upgrade, just queue this one
        return;
      }
      openLevelUpOverlay();
    }

function applyLevelUp(kind) {
      // Apply buffs to BASE stats so they persist with gear changes
      if (kind === "damage") {
        player.baseDamage = Math.round(player.baseDamage * 1.2);
      } else if (kind === "speed") {
        player.baseSpeed = player.baseSpeed * 1.15;
      } else if (kind === "vitality") {
        player.baseMaxHp += 30;
      } else if (kind === "firerate") {
        player.baseFireRate = Math.max(80, player.baseFireRate - 20);
      }

      // Rebuild final stats from base + gear + weapon
      recomputeStats();

      // Optional: heal to full on any level-up
      player.hp = player.maxHp;

      // Close overlay / maybe chain next level-up
      closeLevelUpOverlay();
    }

function addXP(amount) {
      const gearMult = player.xpGearMult || 1;
      amount *= xpMultiplier * gearMult;
      player.xp += amount;

      while (player.xp >= player.nextLevelXp) {
        player.xp -= player.nextLevelXp;
        player.level++;
        player.nextLevelXp = Math.floor(player.nextLevelXp * 1.8);
        pendingLevelUps++;
        triggerLevelUp();
      }
    }

// expose XP function for other systems (plain-browser global)
window.addXP = addXP;


    // clicking buttons chooses an upgrade
    levelUpButtons.forEach((btn, idx) => {
      btn.addEventListener("click", () => {
        const kind = btn.getAttribute("data-upgrade");
        applyLevelUp(kind);
      });
    });
if (restartBtn) {
  restartBtn.addEventListener("mouseenter", () => {
    restartBtn.style.transform = "translateY(-1px)";
    restartBtn.style.boxShadow = "0 20px 60px rgba(0,0,0,0.95)";
    restartBtn.style.background =
      "linear-gradient(135deg, #0f172a, #020617)";
    restartBtn.style.filter = "brightness(1.05)";
  });

  restartBtn.addEventListener("mouseleave", () => {
    restartBtn.style.transform = "translateY(0)";
    restartBtn.style.boxShadow = "0 16px 46px rgba(0,0,0,0.9)";
    restartBtn.style.background =
      "linear-gradient(135deg, #020617, #020617)";
    restartBtn.style.filter = "brightness(1)";
  });
}

// ===== BLOOD MOON EVENT UI (MAX JUICE, SAFE) =====
let bloodMoonActive = false;
let bloodMoonBanner;

// set up keyframes + banner once
(function setupBloodMoonBanner() {
  // keyframes just for this banner
  const style = document.createElement("style");
  style.textContent = `
@keyframes bmPopIn {
  0%   { transform: translateX(-50%) translateY(-12px) scale(0.85); opacity: 0; }
  55%  { transform: translateX(-50%) translateY(0) scale(1.10); opacity: 1; }
  100% { transform: translateX(-50%) translateY(0) scale(1.0); opacity: 1; }
}
@keyframes bmGlowPulse {
  0%   { box-shadow: 0 0 16px rgba(0,255,163,0.6), 0 0 28px rgba(220,31,255,0.55); }
  50%  { box-shadow: 0 0 26px rgba(0,255,163,1),   0 0 40px rgba(220,31,255,0.95); }
  100% { box-shadow: 0 0 16px rgba(0,255,163,0.6), 0 0 28px rgba(220,31,255,0.55); }
}
@keyframes bmShimmer {
  0%   { background-position: 0% 50%; }
  100% { background-position: 100% 50%; }
}
`;
  document.head.appendChild(style);

  bloodMoonBanner = document.createElement("div");
  bloodMoonBanner.id = "blood-moon-banner";

  // inner layout: glowing moon + text
  bloodMoonBanner.innerHTML = `
    <span style="
      display:inline-block;
      width:12px;
      height:12px;
      margin-right:10px;
      border-radius:999px;
      background: radial-gradient(circle, #facc15 0%, #f97316 40%, transparent 70%);
      box-shadow:
        0 0 10px rgba(250,204,21,0.9),
        0 0 18px rgba(248,250,252,0.8);
      vertical-align:middle;
    "></span>
    <span style="display:inline-block; text-align:left;">
      <span style="font-weight:700; font-size:11px;">BLOOD MOON</span><br/>
      <span style="font-size:9px; opacity:0.85;">DANGER + REWARDS RISING</span>
    </span>
  `;

  Object.assign(bloodMoonBanner.style, {
    position: "fixed",
    top: "145px", // adjust up/down if needed
    left: "50%",
    transform: "translateX(-50%) translateY(-8px) scale(0.9)",
    padding: "9px 22px",
    borderRadius: "999px",
    fontFamily: "'Press Start 2P', system-ui, sans-serif",
    letterSpacing: "0.16em",
    textTransform: "uppercase",
    zIndex: "999999",
    opacity: "0",
    pointerEvents: "none",
    color: "#E5E7EB",
    backgroundImage: "linear-gradient(120deg, rgba(15,23,42,0.96), rgba(15,23,42,0.98))",
    border: "1px solid rgba(148,163,184,0.85)",
    boxShadow: "0 0 18px rgba(0,0,0,1)",
    backgroundSize: "260% 260%",
    textShadow:
      "0 0 4px rgba(15,23,42,1)," +
      "0 0 14px rgba(0,255,163,0.9)," +
      "0 0 22px rgba(220,31,255,0.9)",
    transition: "opacity 0.25s ease-out, transform 0.25s ease-out"
  });

  document.body.appendChild(bloodMoonBanner);
})();

function showBloodMoonBanner() {
  bloodMoonActive = true;
  if (!bloodMoonBanner) return;

  bloodMoonBanner.style.opacity = "1";
  bloodMoonBanner.style.transform = "translateX(-50%) translateY(0) scale(1)";

  // reset animation so pop-in plays every time
  bloodMoonBanner.style.animation = "none";
  void bloodMoonBanner.offsetWidth; // force reflow
  bloodMoonBanner.style.animation =
    "bmPopIn 0.4s ease-out, bmGlowPulse 2.6s ease-in-out infinite, bmShimmer 9s linear infinite";
}

function hideBloodMoonBanner() {
  bloodMoonActive = false;
  if (!bloodMoonBanner) return;

  bloodMoonBanner.style.opacity = "0";
  bloodMoonBanner.style.transform = "translateX(-50%) translateY(-8px) scale(0.9)";
  bloodMoonBanner.style.animation = "none";
}


    // number keys 1–4 choose while level-up is open
    window.addEventListener("keydown", (e) => {
      if (!levelUpOpen) return;
      const k = e.key;
      if (k === "1" || k === "2" || k === "3" || k === "4") {
        const index = parseInt(k, 10) - 1;
        const btn = levelUpButtons[index];
        if (btn) {
          const kind = btn.getAttribute("data-upgrade");
          applyLevelUp(kind);
        }
      }
    });

restartBtn.addEventListener("click", () => {
  // Full restart into active play
  restartGame();
});
// ===== PLAYER & ENEMY SPRITES =====
    const playerSprites = [
      [
        "............",
        "....hhhh....",
        "...hhhhhh...",
        "...hsssshh..",
        "...hsssshh..",
        "....ssss....",
        "....jjjj....",
        "...jjjjjj...",
        "...jjjjjj...",
        "...bbbbbb...",
        "...bbbbbb...",
        "...pp..pp...",
        "...pp..pp...",
        "....f..f....",
        "............",
        "............",
      ],
      [
        "............",
        "....hhhh....",
        "...hhhhhh...",
        "...hsssshh..",
        "...hsssshh..",
        "....ssss....",
        "....jjjj....",
        "...jjjjjj...",
        "...jjjjjj...",
        "...bbbbbb...",
        "...bbb.bb...",
        "...pp..p....",
        "...pp..pp...",
        "....f..f....",
        "............",
        "............",
      ],
      [
        "............",
        "....hhhh....",
        "...hhhhhh...",
        "...hsssshh..",
        "...hsssshh..",
        "....ssss....",
        "....jjjj....",
        "...jjjjjj...",
        "...jjjjjj...",
        "...bbbbbb...",
        "...bb.bbb...",
        "....p..pp...",
        "...pp..pp...",
        "....f..f....",
        "............",
        "............",
      ],
    ];
        


// bullet sprite
const bulletImg = new Image();
bulletImg.src = "bullet.png";  // yellow bullet pixel sprite

// === ENEMY SPRITESHEETS (mushroom variants) ===
const enemySheetBlue = new Image();
enemySheetBlue.src = "Mushroom_Reg.png";     // blue default mushroom

const enemySheetSpike = new Image();
enemySheetSpike.src = "Mushroom_spike.png";  // pink spiky mushroom (fast enemy)

const enemySheetSpotted = new Image();
enemySheetSpotted.src = "Mushroom_spotted.png";

// === FOREST MONSTERS (waves 1–5 replacement) ===
const forestMushIdle = new Image(); forestMushIdle.src = "assets/forest_mushroom/Mushroom-Idle.png";
const forestMushRun  = new Image(); forestMushRun.src  = "assets/forest_mushroom/Mushroom-Run.png";
const forestMushAtk  = new Image(); forestMushAtk.src  = "assets/forest_mushroom/Mushroom-Attack.png";
// (Other sheets included in assets/forest_mushroom for future use: Hit/Die/Stun.)
   // green mushroom

// === Tiny RPG enemy pack (used in Desert Vault waves 6–11) ===
const orcWalkImg = new Image(); orcWalkImg.src = "assets/enemies/tinyRPG/orc_walk.png";
const orcAttackImg = new Image(); orcAttackImg.src = "assets/enemies/tinyRPG/orc_attack.png";
const orcDeathImg = new Image(); orcDeathImg.src = "assets/enemies/tinyRPG/orc_death.png";
const soldierWalkImg = new Image(); soldierWalkImg.src = "assets/enemies/tinyRPG/soldier_walk.png";
const soldierAttackImg = new Image(); soldierAttackImg.src = "assets/enemies/tinyRPG/soldier_attack.png";
const soldierDeathImg = new Image(); soldierDeathImg.src = "assets/enemies/tinyRPG/soldier_death.png";
const enemyArrowImg = new Image(); enemyArrowImg.src = "assets/enemies/tinyRPG/arrow.png";

// === Wave 12 Snow enemies (custom sheets) ===
const wave12ImpA = new Image(); wave12ImpA.src = "assets/enemies/wave12/Screenshot_2026-01-08_183942_left.png";
const wave12DemonA = new Image(); wave12DemonA.src = "assets/enemies/wave12/Screenshot_2026-01-08_183942_right.png";
const wave12ImpB = new Image(); wave12ImpB.src = "assets/enemies/wave12/Screenshot_2026-01-08_183930_left.png";
const wave12DemonB = new Image(); wave12DemonB.src = "assets/enemies/wave12/Screenshot_2026-01-08_183930_right.png";
let wave12ImpA_CK = null, wave12DemonA_CK = null, wave12ImpB_CK = null, wave12DemonB_CK = null;
// These sheets were provided as screenshots with a solid dark background.
// Key them to transparent at runtime so they render cleanly.
wave12ImpA.onload = () => { try { wave12ImpA_CK = chromaKeyToCanvas(wave12ImpA, { threshold: 58 }); } catch(e) {} };
wave12DemonA.onload = () => { try { wave12DemonA_CK = chromaKeyToCanvas(wave12DemonA, { threshold: 58 }); } catch(e) {} };
wave12ImpB.onload = () => { try { wave12ImpB_CK = chromaKeyToCanvas(wave12ImpB, { threshold: 58 }); } catch(e) {} };
wave12DemonB.onload = () => { try { wave12DemonB_CK = chromaKeyToCanvas(wave12DemonB, { threshold: 58 }); } catch(e) {} };

// === Desert PNG boss (sandboss) ===
const sandBossImg = new Image(); sandBossImg.src = "assets/bosses/sandboss.png";
// === Wave 15 boss (Minotaur) ===
// NOTE: replace this path with your actual minotaur sprite file if different.
const minotaurBossImg = new Image(); minotaurBossImg.src = "assets/bosses/minotaur.png";


// === Skeletons pack (Waves 16–20) ===
const skelIdleImg   = new Image(); skelIdleImg.src   = "assets/enemies/skeleton/skeleton_idle_clean.png";
const skelWalkImg   = new Image(); skelWalkImg.src   = "assets/enemies/skeleton/skeleton_walk_clean.png";
const skelAttackImg = new Image(); skelAttackImg.src = "assets/enemies/skeleton/skeleton_attack_clean.png";
const skelDieImg    = new Image(); skelDieImg.src    = "assets/enemies/skeleton/skeleton_die_clean.png";
// === Slimes pack (Waves 21–25) ===
const slime1RunImg    = new Image(); slime1RunImg.src    = "assets/enemies/slime/slime1_run.png";
const slime1AttackImg = new Image(); slime1AttackImg.src = "assets/enemies/slime/slime1_attack.png";
const slime2RunImg    = new Image(); slime2RunImg.src    = "assets/enemies/slime/slime2_run.png";
const slime2AttackImg = new Image(); slime2AttackImg.src = "assets/enemies/slime/slime2_attack.png";
const slime3RunImg    = new Image(); slime3RunImg.src    = "assets/enemies/slime/slime3_run.png";
const slime3AttackImg = new Image(); slime3AttackImg.src = "assets/enemies/slime/slime3_attack.png";

// === Rat pack (Late waves / Void) ===
// 32x32 frames, 6 frames per sheet (192x32)
const ratIdleImg = new Image();   ratIdleImg.src   = "assets/enemies/rat/rat-idle-outline.png";
const ratRunImg  = new Image();   ratRunImg.src    = "assets/enemies/rat/rat-run-outline.png";
const ratAtkImg  = new Image();   ratAtkImg.src    = "assets/enemies/rat/rat-attack-outline.png";
const ratDieImg  = new Image();   ratDieImg.src    = "assets/enemies/rat/rat-death-outline.png";



// === Dark Fantasy Enemy pack (Late waves) ===
const batIdleImg   = new Image(); batIdleImg.src   = "assets/enemies/darkfantasy/bat/Bat-IdleFly.png";
const batRunImg    = new Image(); batRunImg.src    = "assets/enemies/darkfantasy/bat/Bat-Run.png";
const batAttackImg = new Image(); batAttackImg.src = "assets/enemies/darkfantasy/bat/Bat-Attack1.png";
const batHurtImg   = new Image(); batHurtImg.src   = "assets/enemies/darkfantasy/bat/Bat-Hurt.png";
const batDieImg    = new Image(); batDieImg.src    = "assets/enemies/darkfantasy/bat/Bat-Die.png";

// === Golem boss (Wave 30) ===
const golemWalkImg   = new Image(); golemWalkImg.src   = "assets/enemies/golem1_orange/Golem_1_walk.png";
const golemIdleImg   = new Image(); golemIdleImg.src   = "assets/enemies/golem1_orange/Golem_1_idle.png";
const golemAttackImg = new Image(); golemAttackImg.src = "assets/enemies/golem1_orange/Golem_1_attack.png";
const golemHurtImg   = new Image(); golemHurtImg.src   = "assets/enemies/golem1_orange/Golem_1_hurt.png";
const golemDieImg    = new Image(); golemDieImg.src    = "assets/enemies/golem1_orange/Golem_1_die.png";

// === Farm animals (FarmHub only) ===
const FARM_ANIM_SHEEP  = new Image(); FARM_ANIM_SHEEP.src  = "assets/farm_animals/Sheep_animation_without_shadow.png";
const FARM_ANIM_PIGLET = new Image(); FARM_ANIM_PIGLET.src = "assets/farm_animals/Piglet_animation_without_shadow.png";
const FARM_ANIM_LAMB   = new Image(); FARM_ANIM_LAMB.src   = "assets/farm_animals/Lamb_animation_without_shadow.png";
const FARM_ANIM_CHICK  = new Image(); FARM_ANIM_CHICK.src  = "assets/farm_animals/Chick_animation_without_shadow.png";
const FARM_ANIM_TURKEY = new Image(); FARM_ANIM_TURKEY.src = "assets/farm_animals/Turkey_animation_without_shadow.png";
const FARM_ANIM_ROOST  = new Image(); FARM_ANIM_ROOST.src  = "assets/farm_animals/Rooster_animation_without_shadow.png";

// Aliases / additional farm animal sheets used by the FarmHub wander system.
// (Keeping explicit names avoids runtime ReferenceErrors.)
const FARM_ANIM_PIG = FARM_ANIM_PIGLET;
const FARM_ANIM_CALF = new Image(); FARM_ANIM_CALF.src = "assets/farm_animals/Calf_animation_without_shadow.png";
const FARM_ANIM_BULL = new Image(); FARM_ANIM_BULL.src = "assets/farm_animals/Bull_animation_without_shadow.png";

const phantomImg = new Image();
phantomImg.src = "phantom.png";   // boss sprite


// === EVIL WIZARD BOSS (Wave 20) ===
const evilWizRunImg = new Image();
evilWizRunImg.src = "assets/evil_wizard/Run.png";
const evilWizIdleImg = new Image();
evilWizIdleImg.src = "assets/evil_wizard/Idle.png";
const evilWizAttack1Img = new Image();
evilWizAttack1Img.src = "assets/evil_wizard/Attack1.png";
const evilWizDeathImg = new Image();
evilWizDeathImg.src = "assets/evil_wizard/Death.png";
// Sprite pack frame configs (per-enemy; do NOT override global defaults)
// Default (legacy) enemy sheet (Forest Mushroom pack used waves 1–5)
const DEFAULT_ENEMY_FRAME_W = 80;
const DEFAULT_ENEMY_FRAME_H = 64;

// Forest Mushroom pack (single-row sheets, 80x64 frames)
const FOREST_MUSHROOM = {
  frameW: 80, frameH: 64,
  run:  { img: (typeof forestMushRunImg !== 'undefined') ? forestMushRunImg : null,  frames: 8 },
  idle: { img: (typeof forestMushIdleImg !== 'undefined') ? forestMushIdleImg : null, frames: 7 },
  atk:  { img: (typeof forestMushAttackImg !== 'undefined') ? forestMushAttackImg : null, frames: 10 }
};

// Skeleton pack (single-row, cleaned, 32x64 frames)
const SKELETON_PACK = {
  frameW: 32, frameH: 64,
  run:  { img: skelWalkImg,   frames: 15 },
  idle: { img: skelIdleImg,   frames: 12 },
  atk:  { img: skelAttackImg, frames: 15 }
};

// Slime pack (4-direction sheets, 64x64 frames, 4 rows)
const SLIME_PACK = {
  frameW: 64, frameH: 64,
  // rows: 0=down, 1=left, 2=right, 3=up (common top-down ordering)
  rows: 4,
  variants: [
    { run: slime1RunImg, atk: slime1AttackImg },
    { run: slime2RunImg, atk: slime2AttackImg },
    { run: slime3RunImg, atk: slime3AttackImg }
  ],
  runFrames: 8,
  // attack frames vary by sheet width; computed at draw-time
};

// Rat pack (single-row, 32x32 frames)
const RAT_PACK = {
  frameW: 32, frameH: 32,
  idle: { img: ratIdleImg, frames: 6 },
  run:  { img: ratRunImg,  frames: 6 },
  atk:  { img: ratAtkImg,  frames: 6 },
  die:  { img: ratDieImg,  frames: 6 }
};


// Bat pack (DarkFantasy, single-row sheets; frame size inferred at draw-time)
const BAT_PACK = {
  frameH: 32, // default; actual derived from sheet height
  idle: { img: batIdleImg },
  run:  { img: batRunImg },
  atk:  { img: batAttackImg },
  hurt:{ img: batHurtImg },
  die: { img: batDieImg }
};

// Golem boss pack (single-row sheets; this pack uses varying frame widths per animation)
const GOLEM1_PACK = {
  frameH: 64,
  idle: { img: golemIdleImg,   frames: 10 },
  run:  { img: golemWalkImg,   frames: 12 },
  atk:  { img: golemAttackImg, frames: 15 },
  hurt:{ img: golemHurtImg,   frames: 5 },
  die: { img: golemDieImg,    frames: 15 }
};

// EVil Wizard boss pack (single-row, 250x250 frames)
const EVIL_WIZ_PACK = {
  frameW: 250, frameH: 250,
  idle: { img: evilWizIdleImg,   frames: 8 },
  run:  { img: evilWizRunImg,    frames: 8 },
  atk:  { img: evilWizAttack1Img,frames: 8 },
  die:  { img: evilWizDeathImg,  frames: 7 }
};
// start from first frame in that row
const ENEMY_ANIM_FRAMES = 4;   // <-- only use frames 0..5



const PLAYER_IMG_WIDTH = 96;
const PLAYER_IMG_HEIGHT = 96;

// Visual tuning
const ENABLE_ENTITY_SHADOWS = false; // set true to restore ground shadows under entities
const ENABLE_MUSHROOM_TINY_SHADOW = true; // keep a tiny cute shadow under mushroom enemies even when global shadows are off

// Tiny shadow should ONLY appear under mushroom enemies when global shadows are disabled.
// (Some enemies use padded frames; we key off wave/theme/type to avoid shadows everywhere.)
function __isMushroomEnemyForShadow(enemy, wave, inRift, mapMode){
  if (!enemy) return false;
  const t = (enemy.type || "").toLowerCase();
  const s = (enemy.skin || "").toLowerCase();
  const k = (enemy.spriteKey || "").toLowerCase();
  const n = (enemy.name || "").toLowerCase();
  if (t.includes("mush") || s.includes("mush") || k.includes("mush") || n.includes("mush")) return true;
  // Early forest waves use mushroom packs even if type isn't labeled.
  if (!enemy.isBoss && (wave >= 1 && wave <= 5) && !inRift && mapMode !== "desertPNG") return true;
  // Legacy/other ground mush enemies often have a small radius.
  if (!enemy.isBoss && (enemy.r || 0) <= 12 && (mapMode === "forest" || mapMode === "farmHub" || mapMode === "field" || mapMode === "Level_0")) return true;
  return false;
}
const PLAYER_VISUAL_SCALE_MULT = 0.70; // chibi scale: smaller, cuter on-screen

const PLAYER_WALK_FRAMES = 6;
const PLAYER_DUST_FRAMES = 6;

let playerWalkFrame = 0;
let playerDustFrame = 0;
let playerWalkTimer = 0;
let playerDustTimer = 0;

const PLAYER_WALK_FRAME_DURATION = 80; // ms per frame
const PLAYER_DUST_FRAME_DURATION = 60;

let playerIsMoving = false;
let playerFacing = 'south'; // south/north/east/west






    const SPRITE_WIDTH = 12;
    const SPRITE_HEIGHT = 16;
    const SPRITE_SCALE = 2.5;

    const enemySpritesBase = [
      [
        "............",
        "............",
        "....hhhh....",
        "...hsssshh..",
        "...hsssshh..",
        "....sssss...",
        ".....sss....",
        "....aaaa....",
        "...aaBBBB...",
        "...aaBBBB...",
        "....PPPP....",
        "....PPPP....",
        ".....FF.....",
        "....F..F....",
        "............",
        "............",
      ],
      [
        "............",
        "............",
        "....hhhh....",
        "...hsssshh..",
        "...hsssshh..",
        "....sssss...",
        ".....sss....",
        "....aaaa....",
        "...aaBBBB...",
        "...aaBBBB...",
        "....PPPP....",
        "....PPP.....",
        "....F.F.....",
        ".....F......",
        "............",
        "............",
      ],
      [
        "............",
        "............",
        "....hhhh....",
        "...hsssshh..",
        "...hsssshh..",
        "....sssss...",
        ".....sss....",
        "....aaaa....",
        "...aaBBBB...",
        "...aaBBBB...",
        "....PPPP....",
        ".....PPP....",
        ".....F.F....",
        "......F.....",
        "............",
        "............",
      ],
    ];
// === IMAGE-BASED PLAYER SPRITE ===
const playerIdleImg = new Image();
applyBaseBodyFromGender();

const playerWalkImg = new Image();

// =============================================================
// FORCE-APPLY SELECTED CHARACTER (Pink/Owlet/Dude) ON BOOT
// Fixes: player becomes invisible (only gun + shadow) when a monster
// character id is selected but the sprite sheets were never applied.
// =============================================================
window.__syncSelectedCharacterSprites = function __syncSelectedCharacterSprites(){
  try {
    // Read the stored selection (support both key variants used across builds)
    const stored = (function(){
      try {
        return localStorage.getItem('arcSelectedChar') || localStorage.getItem('arc_selected_character') || '';
      } catch(_) { return ''; }
    })();

    // Default to pink if missing/invalid.
    let cid = stored || 'pink';
    let cfg = null;
    try {
      if (typeof CHARACTER_CONFIGS !== 'undefined' && Array.isArray(CHARACTER_CONFIGS)) {
        cfg = CHARACTER_CONFIGS.find(c => c && c.id === cid) || null;
      }
    } catch(_) { cfg = null; }

    if (!cfg) {
      cid = 'pink';
      try {
        if (typeof CHARACTER_CONFIGS !== 'undefined' && Array.isArray(CHARACTER_CONFIGS)) {
          cfg = CHARACTER_CONFIGS.find(c => c && c.id === cid) || null;
        }
      } catch(_) { cfg = null; }
    }

    // Apply monster sheets if config exists; otherwise leave base body path.
    if (cfg && cfg.idleSrc && cfg.walkSrc) {
      playerIdleImg.src = cfg.idleSrc;
      playerWalkImg.src = cfg.walkSrc;
      try { selectedCharacterId = cfg.id; } catch(_) {}
      try {
        localStorage.setItem('arcSelectedChar', cfg.id);
        localStorage.setItem('arc_selected_character', cfg.id);
      } catch(_) {}
      if (cfg.trailColor) {
        try { playerTrailColor = cfg.trailColor; } catch(_) {}
      }
    }
  } catch(e) {
    // never crash boot
  }
};

// Run immediately so the sprite is never blank on first frame.
try { window.__syncSelectedCharacterSprites(); } catch(_) {}

function getBaseGender(){
  try { return localStorage.getItem("arc_gender_v1") || "male"; } catch(_) { return "male"; }
}
function applyBaseBodyFromGender(){
  const g = getBaseGender();

  const male = {
    idle: {
      south: "Base_Idle_SOUTH_4.png",
      north: "Base_Idle_NORTH_4.png",
      east:  "Base_Idle_EAST_4.png",
      west:  "Base_Idle_WEST_4.png"
    },
    walk: {
      south: "Base_Walk_SOUTH_6.png",
      north: "Base_Walk_NORTH_6.png",
      east:  "Base_Walk_EAST_6.png",
      west:  "Base_Walk_WEST_6.png"
    }
  };
  const female = { ...male }; // same for now

  const set = (g === "female") ? female : male;
  window.__baseBodySheets = set;

  // IMPORTANT:
  // Do NOT overwrite the currently selected character sprites here.
  // The monster characters (Pink/Owlet/Dude) are driven by
  // applyCharacterConfig() and use playerIdleImg/playerWalkImg.
  // Base bodies are still available via baseIdleImgs/baseWalkImgs.
  try { window.__activeBodyKey = g; } catch(_){}
}
applyBaseBodyFromGender();

const playerDustImg = new Image();
playerDustImg.src = "Walk_Run_Push_Dust_6.png";

// Gun sprite (changes based on selected weapon)
const gunSpriteImg = new Image();
gunSpriteImg.src = "red.png";  // default; overridden after you pick a weapon
// powerup treasure spritesheet (Treasure.png, 16x16 grid of 16x16 tiles)
const powerupSheetImg = new Image();
powerupSheetImg.src = "Treasure.png";   // file next to game.js

const POWERUP_TILE_SIZE = 16;  // each tile is 16x16
    function playerColorForChar(c) {
      switch (c) {
        case "h": return "#0b1120";
        case "s": return "#fed7aa";
        case "j": return "#b45309";
        case "b": return "#1d4ed8";
        case "p": return "#111827";
        case "f": return "#020617";
        default: return null;
      }
    }

    function enemyColorForChar(c, enemy) {
      const type = enemy.isBoss ? "boss" : enemy.type;
      if (c === "h") {
        if (type === "tanky") return "#111827";
        if (type === "ranged") return "#082f49";
        return "#020617";
      }
      if (c === "s") return "#fecaca";
      if (c === "a") {
        if (type === "fast") return "#b91c1c";
        if (type === "tanky") return "#7c3aed";
        if (type === "ranged") return "#22c55e";
        if (type === "boss") return "#f97316";
        return "#4b5563";
      }
      if (c === "B") {
        if (type === "fast") return "#ef4444";
        if (type === "tanky") return "#a855f7";
        if (type === "ranged") return "#4ade80";
        if (type === "boss") return "#facc15";
        return "#9ca3af";
      }
      if (c === "P") return "#020617";
      if (c === "F") return "#000000";
      return null;
    }
function drawPlayerTrail() {
  if (!playerTrail.length) return;
  // Cosmetic trail (set in Inventory). "none" disables.
  try { if (cosmetics && cosmetics.trail === "none") return; } catch(e) {}

  ctx.save();
  ctx.imageSmoothingEnabled = false;

  for (let i = 0; i < playerTrail.length; i++) {
    const p = playerTrail[i];
    const alpha = p.life * 0.6;
    if (alpha <= 0) continue;

    const sx = p.x - camera.x;
    const sy = p.y - camera.y;

    const r = player.r + 2 * p.life;
    ctx.beginPath();
    // old: playerTrailColor (sprite) — now cosmetics-driven
    const col = (typeof getCosColor === "function")
      ? getCosColor((cosmetics && cosmetics.trail) || "purple", alpha)
      : ("rgba(" + (playerTrailColor || "168,85,247") + "," + alpha + ")");
    ctx.fillStyle = col;
    ctx.arc(sx, sy, r, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

// Cosmetic Aura (glow behind player) — runs in any state (mostly visible in hub)
function drawPlayerAura(screenX, screenY) {
  
  // Disabled: aura/glow removed per request.
  return;
try {
    if (!cosmetics || cosmetics.aura === "none") return;
  } catch(e) { return; }

  const t = performance.now() * 0.001;
  const pulse = 0.90 + 0.10 * Math.sin(t * 3.0);

  // Requested: smaller aura (less screen domination, especially with close-up camera).
  const baseR = Math.max(8, player.r * 0.95);
  const colKey = (cosmetics && cosmetics.aura) || "cyan";

  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  ctx.globalAlpha = 0.95 * pulse;

  const g = ctx.createRadialGradient(screenX, screenY, baseR * 0.15, screenX, screenY, baseR);
  const c1 = (typeof getCosColor === "function") ? getCosColor(colKey, 0.95) : "rgba(56,189,248,0.95)";
  const c2 = (typeof getCosColor === "function") ? getCosColor(colKey, 0.38) : "rgba(56,189,248,0.38)";
  g.addColorStop(0, c1);
  g.addColorStop(0.55, c2);
  g.addColorStop(1, "rgba(0,0,0,0)");

  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(screenX, screenY, baseR, 0, Math.PI * 2);
  ctx.fill();

  // Soft outer ring (smaller + subtler).
  ctx.globalAlpha = 0.55 * pulse;
  const g2 = ctx.createRadialGradient(screenX, screenY, baseR * 0.55, screenX, screenY, baseR * 1.15);
  const c3 = (typeof getCosColor === "function") ? getCosColor(colKey, 0.32) : "rgba(56,189,248,0.32)";
  g2.addColorStop(0, c3);
  g2.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = g2;
  ctx.beginPath();
  ctx.arc(screenX, screenY, baseR * 1.15, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}


            function drawPlayerSprite(px, py, frameIndex) {
  // IMPORTANT:
  // Base bodies are 96x96 per frame.
  // Monster sheets (Pink/Owlet/Dude) are 32x32 per frame.
  // If we always crop using 96x96, monster frames crop outside the image
  // and the character becomes "invisible" (you'll only see shadow + gun).
  // So we compute per-character frame size and then scale so monsters
  // match the base body's on-screen size.
  let w = PLAYER_IMG_WIDTH;
  let h = PLAYER_IMG_HEIGHT;

  const baseScale = ((typeof PLAYER_SCALE !== 'undefined' ? PLAYER_SCALE : 1.0) * PLAYER_VISUAL_SCALE_MULT);
  // Final scale may be adjusted later (monster 32px frames are scaled up to match 96px bodies).
  let scale = baseScale;
  let dw = w * scale;
  let dh = h * scale;

  // subtle idle/walk bob + idle breathing so the character feels alive
  const bobPhase = animTime * (playerIsMoving ? 0.018 : 0.012);
  const bobOffsetRaw = Math.sin(bobPhase) * (playerIsMoving ? 2.2 : 1.2);
  // FarmHub: reduce bob so the character doesn't read like it's hovering over props/ground.
  const __hubBobMul = (gameState === 'farmHub') ? (playerIsMoving ? 0.55 : 0.30) : 1.0;
  const bobOffset = bobOffsetRaw * __hubBobMul;

  // tiny idle "breathing" scale pulse (feet-anchored)
  const breathe = playerIsMoving ? 0 : (Math.sin(animTime * 0.01) * 0.015);
  // shadow (moved below after we compute feet anchoring)
ctx.imageSmoothingEnabled = false;

  
  // Choose which body to render.
  // - Monster characters: use the selected CHARACTER_CONFIGS sprite sheets.
  // - Base body (directional): only used if the selected character id is NOT one of the configs.
  let cfg = null;
  try {
    cfg = (typeof CHARACTER_CONFIGS !== 'undefined' && Array.isArray(CHARACTER_CONFIGS))
      ? CHARACTER_CONFIGS.find(c => c && c.id === selectedCharacterId)
      : null;
  } catch(_) { cfg = null; }

  const useMonster = !!cfg; // Pink / Owlet / Dude

  // Directional sprite sheet & frame (only for base bodies)
  const dir = (playerFacing || "south");

  let img = null;
  let frame = 0;

  // We will choose the correct frame size after we pick an image.
  // Base bodies use 96x96 frames. Monster sheets use 32x32 frames.

  if (!useMonster) {
    ensureBaseBodyImages();
    const idleFrames = 4;
    img = baseIdleImgs[dir] || playerIdleImg;
    frame = Math.floor((animTime / 220) % idleFrames);
  } else {
    // Monster idle: may be 1-frame (Pink) or multi-frame (_Idle_4).
    img = playerIdleImg;
    // Monster frame size is square and matches naturalHeight (typically 32).
    if (img && img.naturalHeight) {
      w = img.naturalHeight;
      h = img.naturalHeight;
    } else {
      w = 32; h = 32;
    }
    // Scale monsters up so they match the base body size.
    scale = scale * (PLAYER_IMG_WIDTH / w);
    dw = w * scale;
    dh = h * scale;

    const frames = (img && img.naturalWidth) ? Math.max(1, Math.floor(img.naturalWidth / w)) : 1;
    frame = Math.floor((animTime / 220) % frames);
  }

  if (playerIsMoving) {
    if (!useMonster) {
      img = baseWalkImgs[dir] || playerWalkImg;
      frame = playerWalkFrame;
    } else {
      img = playerWalkImg;
      // Ensure monster frame size + scaling is correct for walk sheets too.
      if (img && img.naturalHeight) {
        w = img.naturalHeight;
        h = img.naturalHeight;
      } else {
        w = 32; h = 32;
      }
      scale = ((typeof PLAYER_SCALE !== 'undefined' ? PLAYER_SCALE : 1.0) * PLAYER_VISUAL_SCALE_MULT) * (PLAYER_IMG_WIDTH / w);
      dw = w * scale;
      dh = h * scale;
      const frames = (img && img.naturalWidth) ? Math.max(1, Math.floor(img.naturalWidth / w)) : 1;
      frame = (typeof playerWalkFrame === 'number') ? (playerWalkFrame % frames) : 0;
    }

  // Draw dust when moving
    if (playerDustImg.complete && playerDustImg.naturalWidth > 0) {
      const dustFrameW = playerDustImg.width / PLAYER_DUST_FRAMES;
      const dustFrameH = playerDustImg.height;
      const dustSrcX = playerDustFrame * dustFrameW;

      const dustScale = 1.0;
      const dustW = dustFrameW * dustScale;
      const dustH = dustFrameH * dustScale;

      ctx.save();
      ctx.translate(px, py + 5); // Adjusted position for dust at feet
      const flip = Math.cos(playerFacingAngle) < 0 ? -1 : 1;
      ctx.scale(flip, 1);

      ctx.drawImage(
        playerDustImg,
        dustSrcX, 0, dustFrameW, dustFrameH,
        -dustW / 2, -dustH / 2,
        dustW, dustH
      );

      ctx.restore();
    }
  } else {
    playerDustFrame = 0; // Reset dust when not moving
  }

  // Finalize frame size + scale now that we have the chosen sheet.
  if (useMonster) {
    const mh = (img && img.naturalHeight) ? img.naturalHeight : 32;
    w = mh;
    h = mh;
    // Chibi monsters: keep them intentionally smaller/cuter than the base bodies.
    // Requested: slightly bigger than the tiny build, but still chibi.
    scale = baseScale * (PLAYER_IMG_WIDTH / w) * 0.78;
  } else {
    w = PLAYER_IMG_WIDTH;
    h = PLAYER_IMG_HEIGHT;
    scale = baseScale;
  }
  dw = w * scale;
  dh = h * scale;

  const frameW = w;
  const frameH = h;
  const srcX = frame * frameW;

  // flip horizontally when aiming left, normal when aiming right
  const flip = Math.cos(playerFacingAngle) < 0 ? -1 : 1;

  if (img.complete && img.naturalWidth > 0) {
    ctx.save();
ctx.imageSmoothingEnabled = false;

// Anchor the sprite to the player's "feet" (bottom-center).
// Our custom GUY sheet has a slightly different baseline than the stock bodies.
const isGuy = (img && img.src && img.src.indexOf("Guy_") !== -1);
// Anchor point from feet (so the character doesn't look "floating").
// Base bodies need a slightly higher anchor (they have more empty pixels at the bottom).
// Monster sheets are tighter, so we anchor closer to full height.
// For monsters, anchor slightly BELOW the full height so the feet are never clipped.
// Monsters were looking "floating" because their anchor was too high.
// Anchor monsters closer to true bottom so feet sit on the ground.
const anchorY = useMonster ? (dh * 0.98) : (dh * (isGuy ? 0.84 : 0.88));

// Grounding: translate to the collision-circle "feet" then draw the sprite up from there.
// Monsters were still looking floaty, so we anchor a little lower.
const feetOffset = useMonster ? (player.r * 1.32) : (player.r * (gameState === 'farmHub' ? 0.78 : 0.92));

// Small extra down nudge for monsters so feet never clip.
const downOffset = useMonster ? (18 * scale) : (isGuy ? (2 * scale) : ((gameState === 'farmHub') ? (3 * scale) : 0));

// shadow (feet-anchored so it doesn't "trip" with close-up camera)
if (ENABLE_MUSHROOM_TINY_SHADOW || ENABLE_ENTITY_SHADOWS) {
  const shadowY = py + feetOffset + 6 - (bobOffset * 0.25) + downOffset;
  ctx.fillStyle = "rgba(15,23,42,0.9)";
  ctx.beginPath();
  ctx.ellipse(
    px,
    shadowY,
    Math.max(8, (player.r + 6) * 0.62),
    Math.max(5, (player.r / 2 + 2) * 0.62),
    0,
    0,
    Math.PI * 2
  );
  ctx.fill();
}


// Snap to whole pixels for crisp pixel art.
const tx = Math.round(px);
const ty = Math.round(py + feetOffset - bobOffset + downOffset);

ctx.translate(tx, ty);

// Feet-anchored breathing: slight squash/stretch while idle.
if (!playerIsMoving && breathe) {
  ctx.scale(flip * (1 - breathe), (1 + breathe));
} else {
  ctx.scale(flip, 1);
}

// draw sprite with its bottom at y=0 in local space
ctx.drawImage(
  img,
  srcX, 0, frameW, frameH,
  -dw / 2, -anchorY,
  dw, dh
);

ctx.restore();
} else {

    // fallback
    ctx.fillStyle = "#f97316";
    ctx.beginPath();
    ctx.arc(px, py, player.r, 0, Math.PI * 2);
    ctx.fill();
  }


  // =============================================================
  // NOTE: Shirt/Outfit badges disabled.
  // The customization flow now only equips a single wearable: HAT.
  // =============================================================

  // =============================================================
  // =============================================================
  // Halo removed per request.

const usingGuy = !!(img && img.src && img.src.includes("Guy_"));

      // Weapon should only appear during waves (in-run).
  if (gameState === "playing") {
// gun (selected weapon sprite) - draw as held item so non-weapon character sprites still show it
const gunImg = gunSpriteImg;
const gunLoaded = gunImg && gunImg.complete && gunImg.naturalWidth > 0;

if (gunLoaded) {
  // Scale weapon a bit larger and anchor it to the hands (instead of floating in front).
  // Chibi weapon scale: keep it smaller than the body so it doesn't dominate.
  // For monster/chibi bodies, tie the gun size to the (small) body scale.
  const targetGunW = useMonster
    ? Math.max(26, Math.min(64, dw * 0.95))   // chibi: readable but not huge
    : Math.max(34, Math.min(86, dw * (usingGuy ? 0.92 : 0.88)));

  const gunScale = targetGunW / Math.max(1, gunImg.naturalWidth);
  const gw = gunImg.naturalWidth * gunScale;
  const gh = gunImg.naturalHeight * gunScale;

  // Local space origin is at the player's feet (bottom-center), after translate(px, py - bobOffset)
  const anchorY = useMonster ? (dh * 0.94) : (dh * (usingGuy ? 0.84 : 0.88));
  const downOffset = useMonster ? (3 * scale) : (usingGuy ? (1 * scale) : 0);
// Hand anchor (tuned so the gun sits in his hands)
  // Guy sheets place hands a bit closer to the torso center.
  let hx = dw * (usingGuy ? 0.12 : 0.22);
  let hy = -anchorY + dh * (usingGuy ? 0.60 : 0.56);

  // Monsters are much smaller (chibi) so keep the weapon tucked closer.
  if (useMonster) {
    hx = dw * 0.10;
    hy = -anchorY + dh * 0.66;
  }

  if (playerFacing === "west")  hx = -dw * (useMonster ? 0.10 : (usingGuy ? 0.12 : 0.22));
  if (playerFacing === "north") { hy = -anchorY + dh * (usingGuy ? 0.62 : 0.54); }
  if (playerFacing === "south") { hy = -anchorY + dh * (usingGuy ? 0.64 : 0.60); }

  // Nudge gun down so it sits more naturally in the hands
  hy += dh * (usingGuy ? 0.18 : 0.14);

  ctx.save();
  ctx.imageSmoothingEnabled = false;

  const _tx = Math.round(px);
  const _ty = Math.round(py - bobOffset + downOffset);
  ctx.translate(_tx, _ty);

  // Flip only when facing west so the weapon matches the sprite direction.
  const _flip = (playerFacing === "west") ? -1 : 1;
  ctx.scale(_flip, 1);

  // IMPORTANT: rotate around the *grip point* so the weapon stays in the hands.
  // (Rotating around the feet makes the gun swing upward and float.)
  const gripX = hx;
  const gripY = hy;
  ctx.translate(gripX, gripY);

  // Rotate towards aim direction (relative to current facing).
  ctx.rotate(playerFacingAngle || 0);

  // Draw with the grip near (0,0) in local space
  const drawX = -gw * 0.38;
  const drawY = -gh * 0.36;
  ctx.drawImage(gunImg, 0, 0, gunImg.naturalWidth, gunImg.naturalHeight, drawX, drawY, gw, gh);
  ctx.restore();
}
else {

    // fallback: simple line gun if image not loaded yet
    const gunLen = player.r + 8;
    const gx = px + Math.cos(playerFacingAngle) * gunLen;
    const gy = py + Math.sin(playerFacingAngle) * gunLen - 2;
    ctx.strokeStyle = "#f9fafb";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(px, py - 3);
    ctx.lineTo(gx, gy);
    ctx.stroke();
  }
}

  } // end weapon-in-run gate


    
function drawEnemySprite(sx, sy, enemy, frameIndex) {
  ctx.imageSmoothingEnabled = false;

  // === BOSS RENDER ===
  if (enemy.isBoss) {
    const t = animTime || 0;

    // --- Desert PNG boss: SANDBOSS (sandboss.png) ---
    if (enemy.bossKind === 'sandboss') {
      const tMs = performance.now();
      const img = sandBossImg;
      if (img && ((img.naturalWidth || img.width) > 0)) {
        const frameW = 96, frameH = 96;
        const cols = Math.max(1, Math.floor((img.naturalWidth || img.width) / frameW)); // usually 3
        const frameMs = 110;
        enemy.__animSeed = (enemy.__animSeed ?? ((Math.random() * 1000) | 0));
        const frame = Math.floor((tMs + enemy.__animSeed) / frameMs) % Math.min(cols, 3);

        // Direction row by player vector (0 down,1 left,2 right,3 up)
        const dx = (player.x - enemy.x), dy = (player.y - enemy.y);
        let row = 0;
        if (Math.abs(dx) > Math.abs(dy)) row = (dx < 0) ? 1 : 2;
        else row = (dy < 0) ? 3 : 0;

        const drawW = 220;
        const drawH = 220;
        ctx.save();
        ctx.translate(Math.round(sx), Math.round(sy));
        ctx.imageSmoothingEnabled = false;

        // shadow
        ctx.globalAlpha = 0.35;
        ctx.fillStyle = "#000";
        ctx.beginPath();
        ctx.ellipse(0, 10, drawW*0.28, drawW*0.16, 0, 0, Math.PI*2);
        ctx.fill();
        ctx.globalAlpha = 1;

        ctx.drawImage(img, frame * frameW, row * frameH, frameW, frameH, -drawW/2, -drawH + 28, drawW, drawH);
        ctx.restore();

        enemy.__hudBarOffset = drawH + 18;
        enemy.hitYOffset = drawH * 0.55;
        enemy.__didDrawSprite = true;
        return;
      }
      // if image not ready, fall through
    }

    // --- Wave 15 boss: MINOTAUR ---
    if (enemy.bossKind === 'minotaur') {
      const tMs = performance.now();
      const img = minotaurBossImg;
      if (img && ((img.naturalWidth || img.width) > 0)) {
        // Supports either a single-frame PNG or a 3x4 directional sheet (96x96 frames) like sandboss.
        const frameW = 96, frameH = 96;
        const iw = (img.naturalWidth || img.width);
        const ih = (img.naturalHeight || img.height);
        const cols = Math.max(1, Math.floor(iw / frameW));
        const rows = Math.max(1, Math.floor(ih / frameH));

        let frame = 0;
        if (cols > 1) {
          const frameMs = 105;
          enemy.__animSeed = (enemy.__animSeed ?? ((Math.random() * 1000) | 0));
          frame = Math.floor((tMs + enemy.__animSeed) / frameMs) % Math.min(cols, 3);
        }

        // If it looks like a 4-row directional sheet, pick row by player vector; otherwise use row 0.
        let row = 0;
        if (rows >= 4) {
          const dx = (player.x - enemy.x), dy = (player.y - enemy.y);
          if (Math.abs(dx) > Math.abs(dy)) row = (dx < 0) ? 1 : 2;
          else row = (dy < 0) ? 3 : 0;
        }

        const drawW = 240;
        const drawH = 240;
        ctx.save();
        ctx.translate(Math.round(sx), Math.round(sy));
        ctx.imageSmoothingEnabled = false;

        // shadow
        ctx.globalAlpha = 0.38;
        ctx.fillStyle = "#000";
        ctx.beginPath();
        ctx.ellipse(0, 12, drawW*0.30, drawW*0.17, 0, 0, Math.PI*2);
        ctx.fill();
        ctx.globalAlpha = 1;

        // Draw frame or whole image if it's not a sheet.
        if (iw >= frameW && ih >= frameH && rows >= 1) {
          ctx.drawImage(img, frame * frameW, row * frameH, frameW, frameH, -drawW/2, -drawH + 30, drawW, drawH);
        } else {
          // Fallback: single-image draw
          ctx.drawImage(img, -drawW/2, -drawH + 30, drawW, drawH);
        }

        // Extra boss readability: faint glow pulse
        const pulse = 0.55 + 0.45 * Math.sin(tMs * 0.006);
        ctx.globalCompositeOperation = 'lighter';
        ctx.globalAlpha = 0.10 * pulse;
        ctx.beginPath();
        ctx.ellipse(0, -drawH*0.35, drawW*0.40, drawH*0.40, 0, 0, Math.PI*2);
        ctx.fillStyle = 'rgba(250,204,21,1)';
        ctx.fill();

        ctx.restore();

        enemy.__hudBarOffset = drawH + 18;
        enemy.hitYOffset = drawH * 0.55;
        enemy.__didDrawSprite = true;
        return;
      }
      // if image not ready, fall through
    }


    // --- Wave 20 boss: EVIL WIZARD ---
    if (enemy.bossKind === 'evilWizard') {
      const now = performance.now(); // ms clock
      const frameW = 250, frameH = 250;
      // These sheets have a lot of transparent padding. Crop into the actual wizard so the boss reads big.
      const cropX = 94, cropY = 49, cropW = 85, cropH = 132;

      // IMPORTANT: remove the sword-hit animation entirely.
      // Wizard always uses idle/run visually; his threat is the ranged bullets.
      const img = (enemy.isMoving ? evilWizRunImg : evilWizIdleImg);

      if (img && img.complete && img.naturalWidth > 0) {
        const frames = Math.max(1, Math.floor(img.naturalWidth / frameW));
        const frameMs = 92;
        const idx = Math.floor((now / frameMs) % frames);

        // Size tuned to read as a boss (cropped sprite)
        const baseH = 190; // on-screen height
        const scale = baseH / cropH;
        const drawW = cropW * scale;
        const drawH = cropH * scale;

        // Face the player
        const flip = (enemy && typeof enemy.facing === 'number') ? enemy.facing : 1;

        // Shadow: small + tight (no giant blob)
        const shadowW = 16;
        const shadowH = 4;
        ctx.save();
        ctx.globalAlpha = 0.22;
        ctx.fillStyle = "rgba(15,23,42,1)";
        ctx.beginPath();
        ctx.ellipse(sx, sy + 12, shadowW / 2, shadowH / 2, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // HP bar anchor above head
        enemy.__hudBarY = sy - drawH - 14;

        ctx.save();
        const px = Math.round(sx);
        const py = Math.round(sy);
        ctx.translate(px, py);
        ctx.scale(flip, 1);
        ctx.imageSmoothingEnabled = false;

        // Slightly lower the sprite so he doesn't look like he's hovering.
        const footDrop = 42;
        ctx.drawImage(img, idx * frameW + cropX, cropY, cropW, cropH, -drawW / 2, -drawH + footDrop, drawW, drawH);
        ctx.restore();
        return;
      }
      // If not ready, fall through to default boss sprite
    }
      // If not ready, fall through to phantom fallback below.

    
    

// --- Wave 30 boss: GOLEM (Orange) ---
if (enemy.bossKind === 'golem1') {
  const tMs = performance.now();
  // Normalize legacy attack timers if they look like seconds.
  if (typeof enemy.attackUntil === 'number' && enemy.attackUntil > 0 && enemy.attackUntil < 100000) {
    enemy.attackUntil = enemy.attackUntil * 1000;
  }
  if (typeof enemy.attackStart === 'number' && enemy.attackStart > 0 && enemy.attackStart < 100000) {
    enemy.attackStart = enemy.attackStart * 1000;
  }
  const isAttacking = (enemy.attackUntil && tMs < enemy.attackUntil);
  const isDead = (enemy.hp <= 0);

  let img = null;
  if (isDead) img = GOLEM1_PACK.die.img;
  else img = isAttacking ? GOLEM1_PACK.atk.img : (enemy.isMoving ? GOLEM1_PACK.run.img : GOLEM1_PACK.idle.img);

  const packState = isDead ? GOLEM1_PACK.die : (isAttacking ? GOLEM1_PACK.atk : (enemy.isMoving ? GOLEM1_PACK.run : GOLEM1_PACK.idle));
  const frameH = GOLEM1_PACK.frameH;
  if (img && img.complete && img.naturalWidth > 0) {
    const frames = Math.max(1, packState.frames || Math.floor(img.naturalWidth / frameH) || 1);
    const frameW = img.naturalWidth / frames;
    const frameMs = isDead ? 95 : (isAttacking ? 80 : 110);
    const localT = isAttacking ? Math.max(0, tMs - (enemy.attackStart || (tMs - 1))) : tMs;
    enemy.__animSeed = (enemy.__animSeed ?? ((Math.random() * 1000) | 0));
    const frame = Math.floor((localT + enemy.__animSeed) / frameMs) % frames;

    // Big but readable
    const baseW = 180;
    const pulse = 1 + 0.030 * Math.sin(tMs * 0.010 + (enemy.wobblePhase || 0));
    const drawW = baseW * pulse;
    const drawH = drawW * (frameH / frameW);

    // Boss HUD & hit alignment
    enemy.__hudBarOffset = drawH + 26;
    enemy.hitYOffset = drawH * 0.58;

    // Ground shadow (tight)
    ctx.save();
    ctx.globalAlpha = 0.26;
    ctx.fillStyle = "#000";
    ctx.beginPath();
    ctx.ellipse(Math.round(sx), Math.round(sy) + 10, drawW * 0.18, drawH * 0.06, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    const flip = (enemy && typeof enemy.facing === 'number') ? enemy.facing : 1;

    ctx.save();
    ctx.translate(Math.round(sx), Math.round(sy));
    ctx.scale(flip, 1);
    ctx.imageSmoothingEnabled = false;
    // Feet anchored at sy
    const footDrop = 14;
    ctx.drawImage(img, frame * frameW, 0, frameW, frameH, -drawW/2, -drawH + footDrop, drawW, drawH);
    ctx.restore();

    enemy.__didDrawSprite = true;
    return;
  }
  // if not ready, fall through to phantom fallback
}

// --- SKELETON BOSS (waves 16–20; replaces phantom) ---
    if (enemy.bossKind === 'skeletonBoss') {
      const tMs = performance.now();
      // Normalize attack timers to ms (some paths store seconds)
      if (typeof enemy.attackUntil === 'number' && enemy.attackUntil > 0 && enemy.attackUntil < 100000) {
        enemy.attackUntil = enemy.attackUntil * 1000;
      }
      if (typeof enemy.attackStart === 'number' && enemy.attackStart > 0 && enemy.attackStart < 100000) {
        enemy.attackStart = enemy.attackStart * 1000;
      }
      const isAttacking = (enemy.attackUntil && tMs < enemy.attackUntil);
      const img = isAttacking ? skelAttackImg : skelWalkImg;

      const frameW = 48, frameH = 64;
      if (img && img.complete && img.naturalWidth > 0) {
        const frames = Math.max(1, Math.floor(img.naturalWidth / frameW)); // 480/48 = 10
        const frameMs = isAttacking ? 70 : 95;
        const localT = isAttacking ? Math.max(0, tMs - (enemy.attackStart || (tMs - 1))) : tMs;
        enemy.__animSeed = (enemy.__animSeed ?? ((Math.random() * 1000) | 0));
        const frame = Math.floor((localT + enemy.__animSeed) / frameMs) % frames;

        const flip = (enemy && typeof enemy.facing === 'number') ? enemy.facing : 1;

        const baseW = 156; // tuned to feel like a boss on your current camera
        const pulse = 1 + 0.035 * Math.sin(tMs * 0.01 + (enemy.wobblePhase || 0));
        const drawW = baseW * pulse;
        const drawH = (baseW * (frameH / frameW)) * pulse;

        enemy.__hudBarOffset = drawH + 22;
        // Sprites are feet-anchored; keep a per-enemy hit-center offset for bullet collisions.
        enemy.hitYOffset = drawH * 0.58;

        // ground shadow
        if (ENABLE_ENTITY_SHADOWS) {
          ctx.save();
          ctx.globalAlpha = 0.30;
          ctx.fillStyle = "#000";
          ctx.beginPath();
          ctx.ellipse(sx, sy + 4, drawW * 0.28, drawH * 0.10, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }

        // boss aura
        const cx = sx;
        const cy = sy - drawH * 0.62;
        const auraR = drawW * 0.95;
        const grad = ctx.createRadialGradient(cx, cy, auraR * 0.15, cx, cy, auraR);
        grad.addColorStop(0,   "rgba(148,163,184,0.55)");
        grad.addColorStop(0.55,"rgba(56,189,248,0.22)");
        grad.addColorStop(1,   "rgba(0,0,0,0)");
        ctx.save();
        ctx.globalCompositeOperation = "screen";
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(cx, cy, auraR, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalCompositeOperation = "source-over";
        ctx.restore();

        // sprite
        ctx.save();
        ctx.translate(sx, sy);
        ctx.scale(flip, 1);
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(
          img,
          frame * frameW, 0, frameW, frameH,
          -drawW / 2, -drawH, drawW, drawH
        );
        ctx.restore();

        enemy.__didDrawSprite = true;
        return;
      }
      // if not ready, fall through to phantom fallback
    }

// --- Default boss: PHANTOM ---
    if (phantomImg && phantomImg.complete && phantomImg.naturalWidth > 0) {
      const baseSize = 88;
      const wobble = enemy.wobblePhase || 0;
      const floatOffset = Math.sin(t * 0.008 + wobble) * 6;
      const scalePulse = 1 + 0.04 * Math.sin(t * 0.01 + wobble);

      const drawW = baseSize * scalePulse;
      const drawH = baseSize * scalePulse;

      ctx.save();

      // Boss aura glow
      {
        const cx = sx;
        const cy = sy - drawH * 0.55 + floatOffset;
        const auraR = drawW * 1.15;
        const pulse = 0.65 + 0.25 * Math.sin(t * 0.01 + wobble);
        const grad = ctx.createRadialGradient(cx, cy, auraR * 0.18, cx, cy, auraR);
        grad.addColorStop(0,   `rgba(168,85,247,${0.85 * pulse})`);
        grad.addColorStop(0.45,`rgba(56,189,248,${0.55 * pulse})`);
        grad.addColorStop(1,   "rgba(0,0,0,0)");
        ctx.globalAlpha = 0.9;
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(cx, cy, auraR, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
      }

      const rot = 0.06 * Math.sin(t * 0.006 + wobble);
      ctx.translate(sx, sy + floatOffset);
      ctx.rotate(rot);
      ctx.globalAlpha = 0.95;

      enemy.__hudBarY = (sy + floatOffset) - drawH - 14;

      ctx.drawImage(
        phantomImg,
        0, 0, phantomImg.naturalWidth, phantomImg.naturalHeight,
        -drawW / 2, -drawH,
        drawW, drawH
      );

      ctx.restore();
      enemy.__didDrawSprite = true;
      return;
    }
    // if image not ready yet, fall through to mushroom fallback
  }


  

  // === Wave 12 Snow enemies render (custom 68px sheets, 3 frames x 4 directions) ===
  if (!enemy.isBoss && mapMode === 'snow' && wave >= 12 && wave <= 15 &&
      (enemy.skin === 'wave12ImpA' || enemy.skin === 'wave12DemonA' || enemy.skin === 'wave12ImpB' || enemy.skin === 'wave12DemonB')) {

    const tMs = performance.now();
    let img = null;
    let frameW = 68, frameH = 59;

    if (enemy.skin === 'wave12ImpA') { img = (wave12ImpA_CK || wave12ImpA); frameH = 59; }
    else if (enemy.skin === 'wave12DemonA') { img = (wave12DemonA_CK || wave12DemonA); frameH = 59; }
    else if (enemy.skin === 'wave12ImpB') { img = (wave12ImpB_CK || wave12ImpB); frameH = 58; }
    else if (enemy.skin === 'wave12DemonB') { img = (wave12DemonB_CK || wave12DemonB); frameH = 58; }

    if (img && ((img.naturalWidth || img.width) > 0)) {
      const frameMs = 120;
      enemy.__animSeed = (enemy.__animSeed ?? ((Math.random() * 1000) | 0));
      const frame = Math.floor((tMs + enemy.__animSeed) / frameMs) % 3;

      const dx = (player.x - enemy.x), dy = (player.y - enemy.y);
      let row = 0;
      if (Math.abs(dx) > Math.abs(dy)) row = (dx < 0) ? 1 : 2;
      else row = (dy < 0) ? 3 : 0;

      // Size: keep these wave-12 sprites close to the normal enemy scale.
      // enemy.r is our gameplay hit-radius; drawing at ~3.2x keeps sprites readable without
      // turning into huge tiles.
      const eliteMult = enemy.isElite ? 1.12 : 1.0;
      const drawW = Math.min(78, Math.max(46, enemy.r * 3.2 * eliteMult));
      const drawH = drawW * (frameH / frameW);

      enemy.__hudBarOffset = drawH + 12;
      enemy.hitYOffset = drawH * 0.55;

      // shadow
      ctx.save();
      ctx.globalAlpha = 0.28;
      ctx.fillStyle = "#000";
      ctx.beginPath();
      ctx.ellipse(Math.round(sx), Math.round(sy) + 8, drawW*0.22, drawW*0.12, 0, 0, Math.PI*2);
      ctx.fill();
      ctx.restore();

      ctx.save();
      ctx.translate(Math.round(sx), Math.round(sy));
      ctx.imageSmoothingEnabled = false;

      // Anchor at feet (a little above the collider shadow)
      ctx.drawImage(img,
        frame * frameW, row * frameH, frameW, frameH,
        -drawW/2, -drawH + 12, drawW, drawH
      );
      ctx.restore();

      enemy.__didDrawSprite = true;
      return;
    }
  }

    // === Tiny RPG pack render (Desert Vault waves 6–11) ===
  // If an enemy has a TinyRPG skin set, we MUST render it here; otherwise it will fall through
  // to the mushroom sheets (which is what you were seeing on desert waves).
  if (enemy.skin === 'orc' || enemy.skin === 'soldier') {
    // IMPORTANT: attack timers are stored in real milliseconds (performance.now())
    // while animTime is in *seconds*. Mixing them makes enemies look "stuck" in
    // attack frames forever. Always use a ms clock for these sprite sheets.
    const tMs = performance.now();
    // Normalize legacy timers: some AI paths store attackStart/attackUntil in seconds.
    // If values look "too small" to be ms, convert to ms so render + logic align.
    if (typeof enemy.attackUntil === 'number' && enemy.attackUntil > 0 && enemy.attackUntil < 100000) {
      enemy.attackUntil = enemy.attackUntil * 1000;
    }
    if (typeof enemy.attackStart === 'number' && enemy.attackStart > 0 && enemy.attackStart < 100000) {
      enemy.attackStart = enemy.attackStart * 1000;
    }
    const isAttacking = (enemy.attackUntil && tMs < enemy.attackUntil);
    const isDead = (enemy.hp <= 0);

    let img = null;
    const frameW = 100, frameH = 100;

    if (enemy.skin === 'orc') {
      if (isDead) img = orcDeathImg;
      else img = isAttacking ? orcAttackImg : orcWalkImg;
    } else {
      if (isDead) img = soldierDeathImg;
      else img = isAttacking ? soldierAttackImg : soldierWalkImg;
    }

    if (img && img.complete && img.naturalWidth > 0) {
      const frames = Math.max(1, Math.floor(img.naturalWidth / frameW));

      // Animation timing: TinyRPG sheets are meant to be snappy.
      // Walk loops continuously; attack starts from frame 0 when possible.
      const frameMs = isAttacking ? 65 : 90;
      const localT = isAttacking
        ? Math.max(0, tMs - (enemy.attackStart || (tMs - 1)))
        : tMs;
      enemy.__animSeed = (enemy.__animSeed ?? ((Math.random() * 1000) | 0));
      const frame = Math.floor((localT + enemy.__animSeed) / frameMs) % frames;

      // Size: match our collision radius so they don't look like tiny dots.
      // Player r=10 maps to a ~96px frame. TinyRPG frames are 100px, so ~6x r is right.
      const pxPerR = 8.0; // tuned down: TinyRPG art has padding but should not be giant
      const eliteMult = enemy.isElite ? 1.15 : 1.0;
      const drawW = Math.max(28, enemy.r * pxPerR * eliteMult);
      const drawH = drawW;

      // These sheets face RIGHT by default; flip when facing left.
      // If facing wasn't set by the AI yet, infer it from player position.
      let flip = (enemy && typeof enemy.facing === 'number') ? enemy.facing : 1;
      if (!flip || flip === 0) {
        const dx = (player && typeof player.x === 'number') ? (player.x - enemy.x) : 1;
        flip = (dx < 0) ? -1 : 1;
      }

      // Store an offset (in screen-space) for where the HP bar should sit relative
      // to the enemy's feet. Using absolute Y can drift when render paths change.
      enemy.__hudBarOffset = drawH + 14;
      // Feet-anchored sprite: lift the logical hit center for bullet collisions.
      enemy.hitYOffset = drawH * 0.55;

      // Ground shadow
      if (ENABLE_ENTITY_SHADOWS) {
        ctx.save();
        ctx.globalAlpha = 0.25;
        ctx.fillStyle = "#000";
        ctx.beginPath();
        ctx.ellipse(sx, sy + 3, Math.max(6, enemy.r * 1.35 * eliteMult), Math.max(3, enemy.r * 0.5 * eliteMult), 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Elite aura (subtle, desert readability)
      if (enemy.isElite) {
        const pulse = 0.65 + 0.18 * Math.sin(tMs * 0.008 + (enemy.wobblePhase || 0));
        const cx = sx;
        const cy = sy - drawH * 0.55;
        const auraR = drawW * 0.95;
        const grad = ctx.createRadialGradient(cx, cy, auraR * 0.18, cx, cy, auraR);
        grad.addColorStop(0,   `rgba(251,191,36,${0.55 * pulse})`);
        grad.addColorStop(0.5, `rgba(56,189,248,${0.25 * pulse})`);
        grad.addColorStop(1,   "rgba(0,0,0,0)");
        ctx.save();
        ctx.globalCompositeOperation = "screen";
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(cx, cy, auraR, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      ctx.save();
      ctx.translate(sx, sy);
      ctx.scale(flip, 1);
      ctx.imageSmoothingEnabled = false;
      // Anchor feet to sy
      ctx.drawImage(
        img,
        frame * frameW, 0, frameW, frameH,
        -drawW / 2, -drawH,
        drawW, drawH
      );
      ctx.restore();
      enemy.__didDrawSprite = true;
      return;
    }

    // If TinyRPG assets aren't ready, do NOT fall back to mushrooms (wrong biome).
    // Draw a simple placeholder so gameplay keeps going.
    ctx.save();
    ctx.fillStyle = (enemy.skin === 'soldier') ? "rgba(59,130,246,0.95)" : "rgba(245,158,11,0.95)";
    ctx.beginPath();
    ctx.arc(sx, sy, enemy.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    return;
  }

// === Skeletons pack render (Waves 16–20) ===
  if (enemy.skin === 'skeleton') {
    const t = animTime || 0;
    const isAttacking = (enemy.attackUntil && t < enemy.attackUntil);
    const img = isAttacking ? skelAttackImg : skelWalkImg;
    const frameW = 48, frameH = 64;
    if (img && img.complete && img.naturalWidth > 0) {
      const frames = Math.max(1, Math.floor(img.naturalWidth / frameW));
      const speed = isAttacking ? 0.018 : 0.014;
      const frame = Math.floor(t * speed * 1000) % frames;

      const scale = enemy.isElite ? 0.95 : 0.86;
      const drawW = frameW * scale;
      const drawH = frameH * scale;

      const flip = (enemy && typeof enemy.facing === 'number') ? enemy.facing : 1;

      // HP bar offset from feet
      enemy.__hudBarOffset = drawH + 10;
      enemy.hitYOffset = drawH * 0.55;

      ctx.save();
      ctx.translate(sx, sy);
      ctx.scale(flip, 1);
      ctx.drawImage(
        img,
        frame * frameW, 0, frameW, frameH,
        -drawW / 2, -drawH,
        drawW, drawH
      );
      ctx.restore();
      enemy.__didDrawSprite = true;
      return;
    }
    // if image not ready, fall through to default sprite
  }

  
  // === Slimes pack render (Waves 21–25) ===
  if (enemy.skin === 'slime') {
    // Slime sheets should be driven by a millisecond clock.
    // animTime is in seconds; mixing units makes them appear frozen/deformed.
    const tMs = performance.now();
    // Normalize legacy timers: some AI paths store attackStart/attackUntil in seconds.
    // If values look "too small" to be ms, convert to ms so render + logic align.
    if (typeof enemy.attackUntil === 'number' && enemy.attackUntil > 0 && enemy.attackUntil < 100000) {
      enemy.attackUntil = enemy.attackUntil * 1000;
    }
    if (typeof enemy.attackStart === 'number' && enemy.attackStart > 0 && enemy.attackStart < 100000) {
      enemy.attackStart = enemy.attackStart * 1000;
    }
    const isAttacking = (enemy.attackUntil && tMs < enemy.attackUntil);

    // 4-direction sheets: rows are typically Down, Left, Right, Up.
    const dx = (player && typeof player.x === 'number') ? (player.x - enemy.x) : 0;
    const dy = (player && typeof player.y === 'number') ? (player.y - enemy.y) : 0;
    let row = 0; // down
    if (Math.abs(dx) > Math.abs(dy)) row = (dx < 0) ? 1 : 2; // left/right
    else row = (dy < 0) ? 3 : 0; // up/down

    const v = (enemy.__slimeVariant || 1);
    const runImg    = (v === 2) ? slime2RunImg    : (v === 3 ? slime3RunImg    : slime1RunImg);
    const attackImg = (v === 2) ? slime2AttackImg : (v === 3 ? slime3AttackImg : slime1AttackImg);
    // NOTE: Slime attack sheets were causing some units to get visually "stuck" in attack.
    // For readability, slimes always use the run sheet for animation.
    const img = runImg;

    const frameW = 64, frameH = 64;
    if (img && img.complete && img.naturalWidth > 0) {
      const cols = Math.max(1, Math.floor(img.naturalWidth / frameW));
      const frames = cols;

      const frameMs = 95;
      const localT = tMs;
      enemy.__animSeed = (enemy.__animSeed ?? ((Math.random() * 1000) | 0));
      const frame = Math.floor((localT + enemy.__animSeed) / frameMs) % frames;

      // Slimes are "ground" enemies. Size should track collision radius, but the
      // 64x64 sheets already read chunky in your camera zoom. Keep them tighter.
      const eliteMult = enemy.isElite ? 1.12 : 1.0;
      const pxPerR = 5.6; // reduced (v12 made them huge)
      const drawW = (enemy.isElite ? 62 : 56) * eliteMult; // fixed 64x64 aspect; avoids squish/warp
      const drawH = drawW;

      // HP bar offset from the enemy's feet (store offset, not absolute screen Y)
      enemy.__hudBarOffset = drawH + 18;
      enemy.hitYOffset = drawH * 0.55;

      // Shadow should match the hit footprint, not the sprite's padded frame.
      if (ENABLE_ENTITY_SHADOWS) {
        const shadowW = Math.max(10, enemy.r * 2.1 * eliteMult);
        const shadowH = Math.max(3, enemy.r * 0.65 * eliteMult);
        ctx.save();
        ctx.globalAlpha = 0.22;
        ctx.beginPath();
        ctx.ellipse(sx, sy - 2, shadowW / 2, shadowH / 2, 0, 0, Math.PI * 2);
        ctx.fillStyle = "#000";
        ctx.fill();
        ctx.restore();
      }

      // Some slime sheets are single-row (no 4-direction layout). Clamp row.
      const rowsAvail = Math.max(1, Math.floor((img.naturalHeight || img.height || frameH) / frameH));
      const safeRow = Math.max(0, Math.min(row, rowsAvail - 1));

      const srcX = frame * frameW;
      const srcY = safeRow * frameH;

      ctx.save();
      const px = Math.round(sx);
      const py = Math.round(sy);
      ctx.translate(px, py);
      ctx.imageSmoothingEnabled = false;

      // Readability: subtle 1px outline so slimes pop on busy tiles
      ctx.save();
      ctx.globalAlpha = 0.45;
      for (const [ox, oy] of [[-1,0],[1,0],[0,-1],[0,1]]) {
        ctx.drawImage(img, srcX, srcY, frameW, frameH, -drawW / 2 + ox, -drawH + oy, drawW, drawH);
      }
      ctx.restore();

      // anchor at feet
      ctx.drawImage(img, srcX, srcY, frameW, frameH, -drawW / 2, -drawH, drawW, drawH);
      ctx.restore();
      enemy.__didDrawSprite = true;
      return;

    }
  }

  

// === Bat pack render (Waves 26–31 / Void) ===
if (enemy.skin === 'bat') {
  const tMs = performance.now();
  // Bats are flying; center-anchored.
  const sp = Math.hypot(enemy.vx||0, enemy.vy||0);
  const recentlyShot = (typeof enemy.lastShot === 'number') && (tMs - enemy.lastShot < 220);
  const img = recentlyShot ? batAttackImg : (sp > 0.05 ? batRunImg : batIdleImg);

  if (img && img.complete && img.naturalWidth > 0) {
    const frameH = img.naturalHeight || 32;
    const frameW = frameH; // sheets are square frames
    const frames = Math.max(1, Math.floor(img.naturalWidth / frameW));
    enemy.__animSeed = (enemy.__animSeed ?? ((Math.random() * 1000) | 0));
    const frame = Math.floor((tMs + enemy.__animSeed) / 90) % frames;

    const eliteMult = enemy.isElite ? 1.10 : 1.0;
    const base = 54 * eliteMult;
    const drawW = base;
    const drawH = base;

    // HUD above head
    enemy.__hudBarOffset = drawH + 18;
    enemy.hitYOffset = 0;

    // soft flying shadow
    if (ENABLE_ENTITY_SHADOWS) {
      const shadowW = Math.max(10, enemy.r * 2.2 * eliteMult);
      const shadowH = Math.max(3,  enemy.r * 0.65 * eliteMult);
      ctx.save();
      ctx.globalAlpha = 0.18;
      ctx.beginPath();
      ctx.ellipse(Math.round(sx), Math.round(sy) + 6, shadowW / 2, shadowH / 2, 0, 0, Math.PI * 2);
      ctx.fillStyle = '#000';
      ctx.fill();
      ctx.restore();
    }

    // hover
    const hover = 6 + 2.5 * Math.sin((tMs + (enemy.wobblePhase||0)*1000) * 0.010);

    ctx.save();
    ctx.translate(Math.round(sx), Math.round(sy - hover));
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(img, frame * frameW, 0, frameW, frameH, -drawW/2, -drawH/2, drawW, drawH);
    ctx.restore();
    enemy.__didDrawSprite = true;
    return;
  }
}

// === Rat pack render (Late waves / Void) ===
  if (enemy.skin === 'rat') {
    const tMs = performance.now();
    // Use run most of the time; idle if barely moving.
    const sp = Math.hypot(enemy.vx||0, enemy.vy||0);
    const img = (sp < 0.02) ? RAT_PACK.idle.img : RAT_PACK.run.img;
    const frameW = RAT_PACK.frameW, frameH = RAT_PACK.frameH;
    if (img && img.complete && img.naturalWidth > 0) {
      const frames = Math.max(1, Math.floor(img.naturalWidth / frameW));
      const frame = Math.floor((tMs + (enemy.__animSeed || 0)) / 95) % frames;

      const eliteMult = enemy.isElite ? 1.10 : 1.0;
      const base = 44 * eliteMult; // readable but not huge
      const drawW = base;
      const drawH = base;

      // HUD/Hitbox alignment (feet anchored)
      enemy.__hudBarOffset = drawH + 16;
      enemy.hitYOffset = drawH * 0.55;

      // tiny shadow always (rats feel weird floating otherwise)
      {
        const shadowW = Math.max(10, enemy.r * 2.2 * eliteMult);
        const shadowH = Math.max(3,  enemy.r * 0.70 * eliteMult);
        ctx.save();
        ctx.globalAlpha = 0.22;
        ctx.beginPath();
        ctx.ellipse(Math.round(sx), Math.round(sy) - 2, shadowW / 2, shadowH / 2, 0, 0, Math.PI * 2);
        ctx.fillStyle = '#000';
        ctx.fill();
        ctx.restore();
      }

      const srcX = frame * frameW;
      const srcY = 0;

      ctx.save();
      const px = Math.round(sx);
      const py = Math.round(sy);
      ctx.translate(px, py);
      ctx.imageSmoothingEnabled = false;
      // feet anchor
      ctx.drawImage(img, srcX, srcY, frameW, frameH, -drawW/2, -drawH, drawW, drawH);
      ctx.restore();
      enemy.__didDrawSprite = true;
      return;
    }
  }

  // === NORMAL & ELITE ENEMIES: mushroom spritesheets === mushroom spritesheets ===
  // Waves 1–5: swap the old custom mushrooms for the Forest Monsters pack (premium animation).
  if (!enemy.isBoss && (wave >= 1 && wave <= 5) && !inRift && mapMode !== 'desertPNG') {
    // Forest Monsters mushroom sheets are 80x64 frames (with padding). Using 64x64 caused
    // partial-frame sampling -> flicker/disappear. Anchor feet to sy and keep scale smaller.
    const now = performance.now();
    const useAtk = (enemy.type === 'ranged') && (typeof enemy.lastShot === 'number') && (now - enemy.lastShot < 240);
    const img = useAtk ? forestMushAtk : forestMushRun;

    if (img && img.complete && img.naturalWidth > 0) {
      const frameW = 80, frameH = 64;
      const frames = Math.max(1, Math.floor(img.naturalWidth / frameW)); // exact for these sheets
      const frame = Math.floor(now / (useAtk ? 60 : 85)) % frames;
      const srcX = frame * frameW;
      const srcY = 0;

      // Smaller + cleaner: keep elites slightly larger.
      const scale = enemy.isElite ? 0.86 : 0.78;
      const drawW = frameW * scale;
      const drawH = frameH * scale;

      // Forest mushroom sheets face the opposite direction vs our facing convention.
      // If the enemy is moving right (facing=1), we need to mirror the sprite so it
      // visually faces right toward the player (and vice versa).
      const flip = -((enemy && typeof enemy.facing === 'number') ? enemy.facing : 1);

      // Let the main render loop place the HP bar above the sprite (prevents bars sitting on faces)
      enemy.__hudBarY = sy - drawH - 10;

      ctx.save();

      // elite glow (so Forest enemies still pop)
      if (enemy.isElite) {
        const pulse = 0.72 + 0.18 * Math.sin(now * 0.008 + (enemy.wobblePhase||0));
        const cx = sx;
        const cy = sy - drawH * 0.55;
        const auraR = drawW * 1.05;
        const grad = ctx.createRadialGradient(cx, cy, auraR * 0.18, cx, cy, auraR);
        grad.addColorStop(0,   'rgba(190,242,100,' + (0.55 * pulse) + ')');
        grad.addColorStop(0.45,'rgba(74,222,128,' + (0.20 * pulse) + ')');
        grad.addColorStop(1,   'rgba(0,0,0,0)');
        ctx.globalCompositeOperation = 'screen';
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(cx, cy, auraR, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalCompositeOperation = 'source-over';
      }

      // Shadow (waves 1–5): always draw a small footprint shadow so these enemies read as grounded.
      {
        const r = (enemy.r || 12) * (enemy.isElite ? 1.08 : 1.0);
        const shadowWidth  = Math.max(12, r * 2.0);
        const shadowHeight = Math.max(4,  r * 0.70);
        const shadowY      = sy + 4;
        ctx.save();
        ctx.globalAlpha = 0.38;
        ctx.fillStyle = 'rgba(15,23,42,1)';
        ctx.beginPath();
        ctx.ellipse(sx, shadowY, shadowWidth / 2, shadowHeight / 2, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Sprite (flipped toward player)
      ctx.translate(sx, sy);
      ctx.scale(flip, 1);
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(img, srcX, srcY, frameW, frameH, -drawW / 2, -drawH, drawW, drawH);
      ctx.restore();
      enemy.__didDrawSprite = true;
      return;
    }
  }

  let sheetImg;
  if (enemy.type === "fast" || enemy.type === "swarm") {
    sheetImg = enemySheetSpike;       // pink spiky
  } else if (enemy.type === "tanky" || enemy.type === "brute") {
    sheetImg = enemySheetSpotted;     // green spotted
  } else {
    sheetImg = enemySheetBlue;        // default blue
  }

  // If the mushroom spritesheet is loaded, use it
  if (sheetImg && sheetImg.complete && sheetImg.naturalWidth > 0) {
    // IMPORTANT: these constants may not exist in some builds / wave packs.
    // Referencing an undeclared identifier throws a ReferenceError, so guard via typeof.
    // IMPORTANT: these constants may not exist in some builds / wave packs.
    // Compute animation frame geometry safely from the sheet if needed.
    const safeFrame = (typeof frameIndex === 'number' ? frameIndex : 0);
    const frameW = (typeof window.ENEMY_FRAME_W === 'number' ? window.ENEMY_FRAME_W : (typeof ENEMY_FRAME_W !== 'undefined' ? ENEMY_FRAME_W : 32));
    const frameH = (typeof window.ENEMY_FRAME_H === 'number' ? window.ENEMY_FRAME_H : (typeof ENEMY_FRAME_H !== 'undefined' ? ENEMY_FRAME_H : 32));
    const cols = (typeof window.ENEMY_COLS === 'number' ? window.ENEMY_COLS : (typeof ENEMY_COLS !== 'undefined' ? ENEMY_COLS : Math.max(1, Math.floor((sheetImg.naturalWidth || sheetImg.width || 0) / frameW) || 1)));
    const animRow = (typeof window.ENEMY_ANIM_ROW === 'number' ? window.ENEMY_ANIM_ROW : (typeof ENEMY_ANIM_ROW !== 'undefined' ? ENEMY_ANIM_ROW : 0));
    const animStart = (typeof window.ENEMY_ANIM_START === 'number' ? window.ENEMY_ANIM_START : (typeof ENEMY_ANIM_START !== 'undefined' ? ENEMY_ANIM_START : 0));
    const frames = (
      (typeof window.ENEMY_ANIM_FRAMES === 'number' ? window.ENEMY_ANIM_FRAMES : (typeof ENEMY_ANIM_FRAMES !== 'undefined' ? ENEMY_ANIM_FRAMES : 0)) ||
      (typeof window.ENEMY_TOTAL === 'number' ? window.ENEMY_TOTAL : (typeof ENEMY_TOTAL !== 'undefined' ? ENEMY_TOTAL : 0)) ||
      cols ||
      1
    );
    const localIndex = (safeFrame % frames + frames) % frames; // 0..frames-1
    const idx = animStart + localIndex + animRow * cols;
    const col = idx % cols;
    const row = Math.floor(idx / cols);
    const srcX = col * frameW;
    const srcY = row * frameH;

    const baseScale = enemy.isBoss ? 1.2 : 1.0;
    const drawW = frameW * baseScale;
    const drawH = frameH * baseScale;

    // Legacy mushroom sheets also face opposite; flip toward the player.
    const flip = -((enemy && typeof enemy.facing === 'number') ? enemy.facing : 1);

    ctx.save();

    // ===== ELITE GLOW AURA (this is the juicy part) =====
    if (enemy.isElite && !enemy.isBoss) {
      const t = animTime || 0;
      const wobble = enemy.wobblePhase || 0;
      const pulse = 0.65 + 0.2 * Math.sin(t * 0.008 + wobble);

      const cx = sx;
      const cy = sy - drawH * 0.55;    // center around body
      const auraR = drawW * 0.9;       // size of glow

      const grad = ctx.createRadialGradient(
        cx, cy, auraR * 0.15,
        cx, cy, auraR
      );
      grad.addColorStop(0,   "rgba(190,242,100,0.95)"); // neon lime center
      grad.addColorStop(0.4, "rgba(45,212,191,0.80)");  // teal mid
      grad.addColorStop(1,   "rgba(15,23,42,0.0)");     // fade out

      ctx.globalAlpha *= pulse;
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(cx, cy, auraR, 0, Math.PI * 2);
      ctx.fill();

      ctx.globalAlpha = 1.0;
    }

    // shadow under enemy
    const __mushShadow = ENABLE_MUSHROOM_TINY_SHADOW && __isMushroomEnemyForShadow(enemy, wave, inRift, mapMode);
    if (ENABLE_ENTITY_SHADOWS || __mushShadow) {
      // Tiny, cute shadow (use hit radius, not padded sprite size)
      const r = (enemy.r || 10);
      const shadowWidth  = ENABLE_ENTITY_SHADOWS ? (drawW * 0.55) : (r * 1.05);
      const shadowHeight = ENABLE_ENTITY_SHADOWS ? (drawH * 0.20) : (r * 0.38);
      const shadowY      = sy + 3;

      ctx.fillStyle = ENABLE_ENTITY_SHADOWS ? "rgba(15,23,42,0.70)" : "rgba(15,23,42,0.45)";
      ctx.beginPath();
      ctx.ellipse(sx, shadowY, shadowWidth, shadowHeight, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    // sprite itself (flip around the enemy center)
    ctx.translate(sx, sy);
    ctx.scale(flip, 1);
    ctx.drawImage(
      sheetImg,
      srcX, srcY, frameW, frameH,
      -drawW / 2, -drawH,
      drawW, drawH
    );

    ctx.restore();
    return;
  }

  // Fallback: simple colored circle (just in case)
  ctx.save();
  ctx.fillStyle = enemy.isBoss ? "#f97316" : (enemy.isElite ? "#22c55e" : "#60a5fa");
  ctx.beginPath();
  ctx.arc(sx, sy, enemy.r, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}








    // ===== WEAPONS & GEAR =====
    const WEAPON_POOL = [
  { id: "pistol",  name: "Sidearm Pistol", damageBonus: 0,  fireRateDelta: 0,   bulletSpeed: 7.5,  pellets: 1, spread: 0.02, pierce: 0, description: "Reliable default pistol." },
  { id: "shotgun", name: "Farm Shotgun",   damageBonus: -4, fireRateDelta: 180, bulletSpeed: 7.0,  pellets: 5, spread: 0.25, pierce: 0, description: "Close-range spread. Huge burst, slow fire." },
  { id: "rifle",   name: "Marksman Rifle", damageBonus: 6,  fireRateDelta: 60,  bulletSpeed: 9.0,  pellets: 1, spread: 0.01, pierce: 0, description: "Accurate rifle. More damage and speed." },
  { id: "smg",     name: "ARC SMG",        damageBonus: -6, fireRateDelta: -90, bulletSpeed: 7.8,  pellets: 1, spread: 0.12, pierce: 0, description: "Sprays bullets. Very fast but weaker shots." },
  { id: "sniper",  name: "Solana Sniper",  damageBonus: 22, fireRateDelta: 260, bulletSpeed: 11.5, pellets: 1, spread: 0.0,  pierce: 2, description: "Piercing high-damage shot. Slow but deadly." },
  {
    id: "ak47",
    name: "AK-47",
    description: "Reliable assault rifle. High fire rate, solid damage.",
    damageBonus: 6,       // more damage than pistol / SMG
    fireRateDelta: -3,    // shoots faster than default
    bulletSpeed: 9,       // fast bullets
    pellets: 1,
    pierce: 0
  }
];

// === WEAPON SELECTION CONFIGS (for the pre-game weapon picker) ===
const WEAPON_SELECT_CONFIGS = [
  {
    id: "ak",
    name: "AK-47",
    description: "Classic rifle. Balanced and reliable.",
    weaponId: "ak47",
    spriteSrc: "ak.png"
  },
  {
    id: "red",
    name: "Red Blaster",
    description: "High damage, solid fire rate.",
    weaponId: "ak47",
    spriteSrc: "red.png"
  },
  {
    id: "blue",
    name: "Blue Pulse",
    description: "More precision, slightly lighter shots.",
    weaponId: "rifle",
    spriteSrc: "blue.png"
  }
];


// currently chosen weapon for this run (by id from WEAPON_POOL)
let selectedWeaponId = (typeof window.__pendingSelectedWeapon === "string" ? window.__pendingSelectedWeapon : "ak47");
function getWeaponTemplateById(id) {
  const found = WEAPON_POOL.find(w => w.id === id);
  return found ? clone(found) : clone(WEAPON_POOL[0]);
}

function getSelectedWeapon() {
  return getWeaponTemplateById(selectedWeaponId || WEAPON_POOL[0].id);
}


    const GEAR_POOL = [
      { slot: "helmet",   name: "Rusty Helmet",      rarity: "common",  bonus: { hp: 15 } },
      { slot: "helmet",   name: "Solana Visor",      rarity: "epic",    bonus: { hp: 30, xpMult: 0.15 } },
      { slot: "chest",    name: "Leather Vest",      rarity: "common",  bonus: { hp: 20 } },
      { slot: "chest",    name: "ARC Plate",         rarity: "rare",    bonus: { hp: 35, damage: 3 } },
      { slot: "boots",    name: "Runner Boots",      rarity: "rare",    bonus: { speed: 0.4 } },
      { slot: "gloves",   name: "Gunner Gloves",     rarity: "rare",    bonus: { fireRate: -40 } },
      { slot: "accessory",name: "Lucky Token",       rarity: "rare",    bonus: { xpMult: 0.1 } }
    ];

    function clone(obj) { return JSON.parse(JSON.stringify(obj)); }
function getDefaultWeapon() { return clone(WEAPON_POOL[0]); }
function getRandomWeapon() { const idx = Math.floor(Math.random() * WEAPON_POOL.length); return clone(WEAPON_POOL[idx]); }
function getRandomGear() { const idx = Math.floor(Math.random() * GEAR_POOL.length); return clone(GEAR_POOL[idx]); }

    function equipGear(item) {
      if (!player.gear) player.gear = {};
      player.gear[item.slot] = item;
      recomputeStats();
      showToast("Equipped: " + item.name);
      playRewardChime();
    }

function weaponSummary(w) {
  if (!w) return "No weapon equipped.";

  let txt = "";
  txt += w.name + "\n\n";
  if (w.description) txt += w.description + "\n\n";

  const dmg     = w.damageBonus   != null ? w.damageBonus   : 0;
  const frDelta = w.fireRateDelta != null ? w.fireRateDelta : 0;
  const speed   = w.bulletSpeed   != null ? w.bulletSpeed   : 0;
  const pellets = w.pellets       != null ? w.pellets       : 1;
  const pierce  = w.pierce        != null ? w.pierce        : 0;

  txt += "Damage bonus: " + dmg;
  txt += "\nFire rate Î: " + frDelta + " ms";
  txt += "\nBullet speed: " + speed;
  txt += "\nPellets: " + pellets;
  txt += "\nPierce: " + pierce;

  return txt;
}

function gearSummaryText() {
  if (!player.gear) player.gear = {};

  const slots = ["helmet", "chest", "boots", "gloves", "accessory"];
  let txt = "";

  for (const slot of slots) {
    const item = player.gear[slot];
    if (!item) {
      txt += slot.toUpperCase() + ": (empty)\n";
    } else {
      const b = item.bonus || {};
      const bonuses = [];

      if (b.hp)           bonuses.push("HP +" + b.hp);
      if (b.damage)       bonuses.push("DMG +" + b.damage);
      if (b.fireRate)     bonuses.push("FR " + (b.fireRate >= 0 ? "+" : "") + b.fireRate + " ms");
      if (b.speed)        bonuses.push("SPD +" + b.speed.toFixed(1));
      if (b.dashCooldown) bonuses.push("DashCD " + b.dashCooldown);
      if (b.xpMult)       bonuses.push("XP +" + Math.round(b.xpMult * 100) + "%");

      txt += slot.toUpperCase() + ": " + item.name + " [" + (item.rarity || "common") + "]";
      if (bonuses.length) txt += " (" + bonuses.join(", ") + ")";
      txt += "\n";
    }
  }

  if (!txt) return "No gear equipped.";
  return txt;
}


    function updateUpgradePanel() {
      if (!upgradeOpen) return;
      upgradeArcLabel.textContent = "ARC: " + points.toLocaleString();
      weaponInfoEl.textContent = weaponSummary(player.weapon);
      gearInfoEl.textContent = gearSummaryText();
    }

    function openUpgradePanel() {
      if (upgradeOpen) return;
      upgradeOpen = true;
      upgradeOverlay.style.display = "flex";
      gameState = "upgrade";
      updateUpgradePanel();
    }

    function closeUpgradePanel() {
      if (!upgradeOpen) return;
      upgradeOpen = false;
      upgradeOverlay.style.display = "none";
      gameState = "playing";
    }

    function tryRollWeapon() {
      const cost = 200;
      if (points < cost) {
        showToast("Need " + cost + " ARC");
        playUIBeep(400);
        return;
      }
      points -= cost;
      const newW = getRandomWeapon();
      player.weapon = newW;
      recomputeStats();
      showToast("New weapon: " + newW.name);
      updateUpgradePanel();
    }

    function tryRollGear() {
      const cost = 150;
      if (points < cost) {
        showToast("Need " + cost + " ARC");
        playUIBeep(400);
        return;
      }
      points -= cost;
      const g = getRandomGear();
      equipGear(g);
      updateUpgradePanel();
    }

    // ===== HELPERS =====
    function resetPlayer() {
      Object.assign(player, playerBase);
      player.baseDamage = player.damage;
      player.baseFireRate = player.fireRate;
      player.baseSpeed = player.speed;
      player.baseMaxHp = player.maxHp;
      player.baseDashCooldown = player.dashCooldown;
      player.baseBulletSpeed = player.bulletSpeed;
player.weapon = getSelectedWeapon();
player.gear = { helmet: null, chest: null, boots: null, gloves: null, accessory: null };

      // Reinitialize decorations each run so the map feels fresh
      // initDecorations(); // decorations disabled
      player.xpGearMult = 1;
      player.bodyDamage = player.damage;
      baseMoveSpeed = player.speed;
      recomputeStats();
    }

    function recomputeStats() {
      let dmg = player.baseDamage;
      let fire = player.baseFireRate;
      let speed = player.baseSpeed;
      let maxHp = player.baseMaxHp;
      let dashCd = player.baseDashCooldown;
      let xpGearMult = 1;
      let xpRelicMult = 1;
      let arcRelicMult = 0;

      if (!player.gear) player.gear = {};
      for (const slot in player.gear) {
        const item = player.gear[slot];
        if (!item || !item.bonus) continue;
        const b = item.bonus;
        if (b.hp) maxHp += b.hp;
        if (b.damage) dmg += b.damage;
        if (b.fireRate) fire += b.fireRate;
        if (b.speed) speed += b.speed;
        if (b.dashCooldown) dashCd += b.dashCooldown;
        if (b.xpMult) xpGearMult *= (1 + b.xpMult);
      }

      // --- Relic passive (equipped in inventory) ---
      try {
        const relicName = (window.cosmetics && window.cosmetics.relic) ? window.cosmetics.relic : (cosmetics && cosmetics.relic);
        const fx = getRelicEffect(relicName);
        if (fx) {
          const b = fx.bonus || {};
          if (b.hp) maxHp += b.hp;
          if (b.damage) dmg += b.damage;
          if (b.fireRate) fire += b.fireRate;
          if (b.speed) speed += b.speed;
          if (b.dashCooldown) dashCd += b.dashCooldown;
          if (typeof fx.xpMult === 'number' && isFinite(fx.xpMult)) xpRelicMult *= (1 + fx.xpMult);
          if (typeof fx.arcMult === 'number' && isFinite(fx.arcMult)) arcRelicMult += fx.arcMult;
        }
      } catch(e) {}

      const w = player.weapon;
      if (w) {
        if (w.damageBonus) dmg += w.damageBonus;
        if (w.fireRateDelta) fire += w.fireRateDelta;
        player.bulletSpeed = w.bulletSpeed || player.baseBulletSpeed;
      } else {
        player.bulletSpeed = player.baseBulletSpeed;
      }

      player.damage = dmg;
      player.bodyDamage = dmg;
      player.fireRate = Math.max(80, fire);
      if (overdriveActive) speed *= 1.18;
      // Clamp move speed so relic/gear stacking can't make movement uncontrollably fast.
      // (Keeps the game readable and prevents "I become fast as hell" runs.)
      const SPEED_MAX = 4.2;
      player.speed = Math.min(speed, SPEED_MAX);
      player.maxHp = maxHp;
      if (player.hp > player.maxHp) player.hp = player.maxHp;
      player.dashCooldown = Math.max(400, dashCd);
      player.xpGearMult = xpGearMult;
      player.xpRelicMult = xpRelicMult;
      player.arcRelicMult = arcRelicMult;
      baseMoveSpeed = player.speed;
      // Apply BLACKSMITH forge upgrades (global) to the current weapon + stats
      try { if (window.__applyBlacksmithToPlayer) window.__applyBlacksmithToPlayer(); } catch(e) {}

    }

        
function spawnEnemy(type = null, spawnX = null, spawnY = null) {
  // pick type if not specified (more variety = more dopamine)
  if (!type) {
    const r = Math.random();
    if (r < 0.26)       type = "normal";
    else if (r < 0.46)  type = "fast";
    else if (r < 0.60)  type = "tanky";
    else if (r < 0.70)  type = "swarm";
    else if (r < 0.79)  type = "splitter";
    else if (r < 0.87)  type = "ranged";
    else                type = "brute";
  }

  // spawn position away from player (or override for scripted spawns)
  let x, y;
  if (typeof spawnX === "number" && typeof spawnY === "number") {
    x = spawnX; y = spawnY;
  } else {
    const spawnMargin = 40;
    const spawnMinX = PLAY_MIN_X + spawnMargin;
    const spawnMaxX = PLAY_MAX_X - spawnMargin;
    do {
      x = spawnMinX + Math.random() * (spawnMaxX - spawnMinX);
      y = Math.random() * WORLD_HEIGHT;
    } while (distance(x, y, player.x, player.y) < 260);
  }

  const isBoss = (type === "boss");

  // Decide if this enemy spawns as an ELITE (stronger, glowing, better rewards)
  let isElite = false;
  if (!isBoss) {
    let baseEliteChance = 0.09;
    if (hasMutation("mev_predator")) baseEliteChance *= 1.35;
    if (bloodMoonActive) baseEliteChance *= 2.0;
    const waveBonus = (wave || 1) * 0.002;
    const eliteChance = Math.min(baseEliteChance + waveBonus, 0.25);
    if (Math.random() < eliteChance) isElite = true;
  }

  // basic stats per type (fixed: tanky + ranged were missing)
  const w = (wave || 1);
  let hp, speed, r, pointsReward, xpReward, fireCooldown;

  if (isBoss) {
    type = "boss";
    r = 36;
    hp = 780 + w * 45;
    speed = 1.75 + Math.min(0.35, w * 0.02);
    pointsReward = 110 + Math.floor(w * 7);
    xpReward = 85 + Math.floor(w * 5);
    fireCooldown = 650;
  } else if (type === "swarm") {
    r = 9;
    hp = 22 + w * 1.1;
    speed = 2.95;
    pointsReward = 3;
    xpReward = 3;
    fireCooldown = 999999;
  } else if (type === "fast") {
    r = 12;
    hp = 46 + w * 1.6;
    speed = 2.6;
    pointsReward = 6;
    xpReward = 6;
    fireCooldown = 999999;
  } else if (type === "tanky") {
    r = 17;
    hp = 120 + w * 6.2;
    speed = 1.25;
    pointsReward = 10;
    xpReward = 10;
    fireCooldown = 999999;
  } else if (type === "splitter") {
    r = 15;
    hp = 90 + w * 4.4;
    speed = 1.55;
    pointsReward = 9;
    xpReward = 9;
    fireCooldown = 999999;
  } else if (type === "brute") {
    r = 20;
    hp = 230 + w * 10.5;
    speed = 1.05;
    pointsReward = 14;
    xpReward = 14;
    fireCooldown = 999999;
  } else if (type === "ranged") {
    r = 14;
    hp = 64 + w * 3.2;
    speed = 1.35;
    pointsReward = 8;
    xpReward = 8;
    fireCooldown = 900;
  } else { // normal
    r = 13;
    hp = 56 + w * 2.2;
    speed = 1.65;
    pointsReward = 5;
    xpReward = 5;
    fireCooldown = 999999;
  }

  // ELITE STAT SCALING: chunky and rewarding
  if (!isBoss && isElite) {
    const eliteHpMult = 3.0;
    const eliteSpeedMult = 1.1;
    const eliteRewardMult = 3.0;
    hp *= eliteHpMult;
    speed *= eliteSpeedMult;
    pointsReward = Math.round(pointsReward * eliteRewardMult);
    xpReward = Math.round(xpReward * eliteRewardMult);
  }

  // GLOBAL ENEMY HP TUNING: the game was too easy. Bump baseline enemy HP while keeping bosses reasonable.
  // (Applied after elite scaling so elites remain meaningfully tanky.)
  const __HP_MULT_NORMAL = 1.45;
  const __HP_MULT_BOSS   = 1.25;
  hp *= (isBoss ? __HP_MULT_BOSS : __HP_MULT_NORMAL);

  const enemy = {
    x, y, r,
    type,
    hp,
    maxHp: hp,
    speed,
    pointsReward,
    xpReward,
    wobblePhase: Math.random() * Math.PI * 2,
    lastShot: 0,
    fireCooldown,
    isBoss,
    bossKind: (isBoss ? (((wave===15)) ? 'minotaur' : (((wave===18)||(wave===20)) ? 'evilWizard' : ((wave===30) ? 'golem1' : ((wave>=16 && wave<=20) ? 'skeletonBoss' : 'phantom')))) : null),
    isElite,
    // Tiny RPG skins (Desert Vault waves 6–11)
    skin: null,             // 'orc' | 'soldier' | null
    animState: 'walk',
    animFrame: 0,
    animTimer: 0,
    facing: 1,
    attackUntil: 0,
    attackStart: 0,
    lastMeleeSwing: 0,
    bossPhase: 0,           // 0..2 for boss only
    bossLastSummon: 0,
    // pick a random frame ...
    spritePack: null,
    spriteVariant: 0,
    spriteIndex: 0};

  // If spawned inside a Rift, scale it up
  if (inRift && !enemy.isBoss) {
    const hpScale = 1 + riftDepth * 0.25;
    const speedScale = 1 + riftDepth * 0.15;
    enemy.hp *= hpScale;
    enemy.maxHp = enemy.hp;
    enemy.speed *= speedScale;
    enemy.pointsReward = Math.round(enemy.pointsReward * (1 + riftDepth * 0.2));
    enemy.xpReward = Math.round(enemy.xpReward * (1 + riftDepth * 0.2));
    enemy.isRift = true;
  }


  // Desert Vault (waves 6–11): use Tiny RPG pack enemies only (no mushrooms here)
  if (!enemy.isBoss && (wave >= 6 && wave <= 11) && mapMode === 'desertPNG') {
    enemy.skin = (enemy.type === 'ranged') ? 'soldier' : 'orc';
    // Hitbox sized for the (now) correctly-scaled TinyRPG sprites.
    enemy.r = (enemy.skin === 'orc') ? 16 : 14;
    // TinyRPG sprites are drawn with feet anchored at (x,y). Lift the logical
    // hit center so shots register on the body, not only at the feet.
    enemy.hitYOffset = 30;
  }

  // Desert PNG boss sprite override (waves 6–11)
  if (enemy.isBoss && (wave >= 6 && wave <= 11) && mapMode === 'desertPNG') {
    enemy.bossKind = 'sandboss';
    // Slightly larger collision for boss.
    enemy.r = 42;
  }

  // Snow biome (waves 12–15): Wave 12 custom enemies only
  if (!enemy.isBoss && (wave >= 12 && wave <= 15) && mapMode === 'snow') {
    const roll = Math.random();
    if (roll < 0.25) enemy.skin = 'wave12ImpA';
    else if (roll < 0.50) enemy.skin = 'wave12DemonA';
    else if (roll < 0.75) enemy.skin = 'wave12ImpB';
    else enemy.skin = 'wave12DemonB';

    // Collision tuned to match these 68px frame sheets.
    enemy.r = (enemy.skin.includes('Demon')) ? 16 : 14;
    enemy.hitYOffset = 30;
  }

  // Skeleton tier (waves 16–20): swap visuals to skeleton pack (keeps existing behaviors).
  if (!enemy.isBoss && (wave >= 16 && wave <= 20) && !inRift) {
    enemy.skin = 'skeleton';
    enemy.r = 14;
    // Skeleton sprites are drawn with feet anchored at (x,y); lift hit center.
    enemy.hitYOffset = 32;
  }


  // Slime tier (waves 21–25): swap visuals to slime pack (keeps existing behaviors).
  if (!enemy.isBoss && (wave >= 21 && wave <= 25) && !inRift) {
    enemy.skin = 'slime';
    // Use smaller radius so collisions match the sprite size.
    enemy.r = 12;
    // Slimes are also drawn feet-anchored; lift hit center.
    enemy.hitYOffset = 28;
    // Pick a deterministic-ish variant so the wave has variety.
    if (enemy.__slimeVariant == null) {
      const seed = ((enemy.spawnId || 0) + wave * 1337 + Math.floor(enemy.x * 10) + Math.floor(enemy.y * 10)) >>> 0;
      enemy.__slimeVariant = (seed % 3) + 1; // 1..3
    }
  }


  
// Late-run roster (waves 26–31): keep it tight & readable (no legacy default sprites leaking in).
// Bats + Rats + Slimes only.
  if (!enemy.isBoss && (wave >= 26 && wave <= 31) && !inRift) {
    const roll = Math.random();
    const useRat   = (roll < 0.45);
    const useBat   = (roll >= 0.45 && roll < 0.80);
    // else: slime

    if (useRat) {
      enemy.skin = 'rat';
      enemy.r = 11;
      enemy.hitYOffset = 24;
      if (enemy.__animSeed == null) enemy.__animSeed = ((Math.random() * 1000) | 0);

      // Swarm: fast but low damage + low HP
      enemy.speed *= 1.55;
      enemy.hp *= 0.62;
      enemy.maxHp = enemy.hp;

      // Low damage: store on enemy so melee contact uses it (fallback-safe).
      enemy.contactDamageMult = 0.55;
    } else if (useBat) {
      enemy.skin = 'bat';
      // flying: center-anchored
      enemy.r = 12;
      enemy.hitYOffset = 0;
      enemy.speed *= 1.12;
      enemy.contactDamageMult = 0.80;
    } else {
      // For waves 26–31 we DO NOT use slimes (late roster is rats + bats).
      // Slimes return in the Endless Void (wave 32+).
      if (wave <= 31) {
        enemy.skin = 'rat';
        enemy.r = 11;
        enemy.hitYOffset = 24;
        if (enemy.__animSeed == null) enemy.__animSeed = ((Math.random() * 1000) | 0);
        enemy.speed *= 1.55;
        enemy.hp *= 0.62;
        enemy.maxHp = enemy.hp;
        enemy.contactDamageMult = 0.55;
      } else {
        enemy.skin = 'slime';
        enemy.r = 12;
        enemy.hitYOffset = 28;
        if (enemy.__slimeVariant == null) {
          const seed = ((enemy.spawnId || 0) + wave * 1337 + Math.floor(enemy.x * 10) + Math.floor(enemy.y * 10)) >>> 0;
          enemy.__slimeVariant = (seed % 3) + 1; // 1..3
        }
        enemy.contactDamageMult = 0.85;
      }
    }
  }

  // Endless Void (wave 32+): ALL enemy looks can appear.
  if (!enemy.isBoss && (wave >= 32) && !inRift && mapMode === 'void') {
    const p = Math.random();
    if (p < 0.22) {
      enemy.skin = (enemy.type === 'ranged') ? 'soldier' : 'orc';
      enemy.r = (enemy.skin === 'orc') ? 16 : 14;
      enemy.hitYOffset = 30;
    } else if (p < 0.44) {
      enemy.skin = 'skeleton';
      enemy.r = 14;
      enemy.hitYOffset = 32;
    } else if (p < 0.70) {
      enemy.skin = 'slime';
      enemy.r = 12;
      enemy.hitYOffset = 28;
      if (enemy.__slimeVariant == null) {
        const seed = ((enemy.spawnId || 0) + wave * 1337 + Math.floor(enemy.x * 10) + Math.floor(enemy.y * 10)) >>> 0;
        enemy.__slimeVariant = (seed % 3) + 1;
      }
    } else if (p < 0.88) {
      enemy.skin = 'rat';
      enemy.r = 11;
      enemy.hitYOffset = 24;
      if (enemy.__animSeed == null) enemy.__animSeed = ((Math.random() * 1000) | 0);

} else if (p < 0.94) {
  enemy.skin = 'bat';
  enemy.r = 12;
  enemy.hitYOffset = 0;
    } else {
      // leave default mushroom/legacy visuals (waves 1–5 etc.)
      // keep existing radii
    }
  }


  enemies.push(enemy);

  if (isBoss) {
    bossAlive = true;
    bossPulseAlpha = 1;
    slowMoTime = Math.max(slowMoTime, 0.55);
    waveFlashAlpha = Math.max(waveFlashAlpha, 0.75);
    triggerShake(18);
    showToast("BOSS ONLINE");
    playBossSiren();
  }

  if (enemy.isElite && !enemy.isBoss) {
    playElitePing();
  }
}
function maybeSpawnBoss() {
      if (!bossAlive && kills >= bossKillsTrigger) {
        spawnEnemy("boss");
        bossLabel.textContent = "Boss: spawned!";
        bossKillsTrigger += 30;
      } else if (!bossAlive) {
        const remaining = bossKillsTrigger - kills;
        bossLabel.textContent = "Boss: " + remaining + " kills left";
      }
    }

    

// ===== WAVE CONFIG & CONTROL =====
function getWaveConfig(w) {
  // how many non-boss enemies this wave wants
  const enemyCount = 18 + w * 5; // scales up each wave

  // composition: only existing enemy types
  let mix = {
    normal:  0.34,
    fast:    0.18,
    tanky:   0.16,
    swarm:   0.14,
    splitter:0.10,
    ranged:  0.05,
    brute:   0.03
  };

  if (w >= 4) {
    mix.ranged += 0.05;
    mix.normal -= 0.05;
  }

  // Desert Vault (desertPNG, waves 6–11): add a lot more archers so it doesn't
  // become an all-melee dogpile. Keep the pack vibe: orcs (melee) + soldiers (ranged).
  if (mapMode === 'desertPNG' && w >= 6 && w <= 11) {
    mix = {
      normal:  0.18,
      fast:    0.14,
      tanky:   0.14,
      swarm:   0.12,
      splitter:0.08,
      ranged:  0.30,
      brute:   0.04
    };
  }
  if (w >= 7) {
    mix.fast += 0.04;
    mix.tanky += 0.05;
    mix.splitter += 0.03;
    mix.normal -= 0.12;
  }
  if (w >= 10) {
    mix.brute += 0.03;
    mix.swarm += 0.03;
    mix.normal -= 0.06;
  }

  const bossThisWave = (w % 5 === 0); // every 5th wave has a boss

  return { enemyCount, mix, bossThisWave };
}

function pickEnemyTypeForWave(mix) {
  const r = Math.random();
  let acc = 0;
  const order = ["normal", "fast", "tanky", "swarm", "splitter", "ranged", "brute"];
  for (const type of order) {
    acc += mix[type] || 0;
    if (r <= acc) return type;
  }
  return "normal";
}

function __spawnSupplyDropEvent() {
  // Spawn 3 random powerups as a "supply drop" somewhere away from the player.
  const spawnMargin = 64;
  const spawnMinX = PLAY_MIN_X + spawnMargin;
  const spawnMaxX = PLAY_MAX_X - spawnMargin;

  let x = spawnMinX + Math.random() * (spawnMaxX - spawnMinX);
  let y = 80 + Math.random() * (WORLD_HEIGHT - 160);

  // keep it away from the player so it feels like a mini objective
  let tries = 0;
  while (tries++ < 10 && distance(x, y, player.x, player.y) < 180) {
    x = spawnMinX + Math.random() * (spawnMaxX - spawnMinX);
    y = 80 + Math.random() * (WORLD_HEIGHT - 160);
  }

  // little pop VFX + shake
  triggerShake(10);
  showToast("SUPPLY DROP!");

  // scatter 3 powerups in a tight cluster
  for (let i = 0; i < 3; i++) {
    const ox = (Math.random() * 2 - 1) * 22;
    const oy = (Math.random() * 2 - 1) * 22;
    spawnPowerup(x + ox, y + oy);
  }

  // some particles for readability
  try {
    for (let i = 0; i < 22; i++) {
      particles.push({
        x, y,
        vx: (Math.random() * 2 - 1) * 1.8,
        vy: (Math.random() * 2 - 1) * 1.8,
        r: 2 + Math.random() * 2,
        life: 320 + Math.random() * 260,
        color: "rgba(56,189,248,0.9)"
      });
    }
  } catch (e) {}
}


function __startChaosStorm(durationMs = 12000) {
  chaosStormActive = true;
  chaosStormEnd = performance.now() + durationMs;
  chaosStormNext = performance.now() + 350;
  chaosStormStrikes.length = 0;
  showToast("CHAOS STORM!");
  triggerShake(10);
}

function __updateChaosStorm(dt, now) {
  if (!chaosStormActive) return;
  if (now >= chaosStormEnd) { chaosStormActive = false; chaosStormStrikes.length = 0; return; }

  // spawn a new strike every ~1.1s
  if (now >= chaosStormNext) {
    chaosStormNext = now + 1100 + Math.random() * 240;

    const margin = 80;
    const minX = PLAY_MIN_X + margin;
    const maxX = PLAY_MAX_X - margin;
    let x = minX + Math.random() * (maxX - minX);
    let y = 80 + Math.random() * (WORLD_HEIGHT - 160);

    // bias towards the player area so it feels relevant, but not on top of them
    let tries = 0;
    while (tries++ < 8 && distance(x, y, player.x, player.y) < 120) {
      x = minX + Math.random() * (maxX - minX);
      y = 80 + Math.random() * (WORLD_HEIGHT - 160);
    }

    chaosStormStrikes.push({ x, y, t0: now, detAt: now + 650, r: 70 });
  }

  // detonate finished strikes
  for (let i = chaosStormStrikes.length - 1; i >= 0; i--) {
    const s = chaosStormStrikes[i];
    if (now < s.detAt) continue;

    // damage enemies in radius
    for (const e of enemies) {
      if (!e || e.dead) continue;
      const d = distance(e.x, e.y, s.x, s.y);
      if (d <= s.r) {
        e.hp -= 38;
        const __tHit = performance.now();
        e.__hitFlashUntil = __tHit + 80;
        e.__hpBarFlashUntil = __tHit + 140;
        if (e.hp <= 0) {
          e.hp = 0;
          e.dead = true;
        }
      }
    }

    // small player damage if you stand in it
    if (distance(player.x, player.y, s.x, s.y) <= s.r) {
      player.hp -= 10;
      if (player.hp < 0) player.hp = 0;
    }

    // VFX
    try {
      for (let k = 0; k < 28; k++) {
        const ang = Math.random() * Math.PI * 2;
        const sp = 1.6 + Math.random() * 2.6;
        particles.push({
          x: s.x,
          y: s.y,
          vx: Math.cos(ang) * sp,
          vy: Math.sin(ang) * sp,
          r: 2 + Math.random() * 2,
          life: 260 + Math.random() * 220,
          color: (k % 2) ? "rgba(168,85,247,0.9)" : "rgba(34,211,238,0.85)"
        });
      }
    } catch(e) {}

    triggerShake(10);
    chaosStormStrikes.splice(i, 1);
  }
}

function __drawChaosStormTelegraphs() {
  if (!chaosStormActive) return;
  const now = performance.now();
  for (const s of chaosStormStrikes) {
    const sx = s.x - camera.x;
    const sy = s.y - camera.y;
    if (sx < -140 || sy < -140 || sx > canvas.width + 140 || sy > canvas.height + 140) continue;

    const t = Math.max(0, Math.min(1, (s.detAt - now) / 650));
    const pulse = 0.7 + 0.3 * Math.sin(now * 0.02);

    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = 0.35 * pulse;

    // soft fill
    const g = ctx.createRadialGradient(sx, sy, 0, sx, sy, s.r);
    g.addColorStop(0, "rgba(168,85,247,0.22)");
    g.addColorStop(0.6, "rgba(34,211,238,0.10)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(sx, sy, s.r, 0, Math.PI * 2);
    ctx.fill();

    // ring tightens as it approaches detonation
    ctx.globalAlpha = (0.55 + (1 - t) * 0.25) * pulse;
    ctx.lineWidth = 3;
    ctx.strokeStyle = "rgba(34,211,238,0.55)";
    ctx.beginPath();
    ctx.arc(sx, sy, s.r * (0.85 + 0.15 * t), 0, Math.PI * 2);
    ctx.stroke();

    ctx.restore();
  }
}


function startWave(w) {
  // previous wave cleared when a new wave starts
  if (w > 1) wavesCleared = w - 1;
  wave = w;

  // Reset any pending zone-change countdown state.
  wavePortalCountdownActive = false;
  wavePortalCountdownEnd = 0;

  // Any time a new wave begins, the zone summary (if shown) should go away.
  try { hideZoneSummary && hideZoneSummary(); } catch(e) {}

  // Map/tileset selection is zone-driven (level_0/2/3 PNGs, then desert tileset, then void).
  const zone = getWaveZone(wave);
  // Zone -> map mode
  // level0  = farm lane PNG
  // level2  = desert village PNG (the big desert town / oasis map)
  // level3  = snow forest PNG
  // desert  = desert *tileset* arena (later waves)
  // void    = WAVE ??? starfield arena
  if (zone === 'desert') setMapMode("desert");
  else if (zone === 'void') setMapMode("void");
  else if (zone === 'level3') setMapMode("snow");
  else if (zone === 'level2') setMapMode("desertPNG");
  else setMapMode("farm");

  // Apply zone vibe (music bed + ambience).
  try { setBiomeVibe && setBiomeVibe(mapMode); } catch(e) {}

  // Mid/late-run music shifts (waves 16–20, 21–25, 26–30+).
  try { setWaveMusicForWave && setWaveMusicForWave(wave); } catch(e) {}


    // Trigger every 5 waves (5, 10, 15â¦)
    if (w % 5 === 0) showBloodMoonBanner();
    else hideBloodMoonBanner();

  currentWaveConfig = getWaveConfig(wave);

  waveEnemiesTarget = currentWaveConfig.enemyCount;
  waveEnemiesSpawned = 0;
  waveEnemiesKilled = 0;
  waveInBreak = false;
  waveBossSpawned = false;
  waveSpawnCooldown = 0;

  // mark wave start + roll a small mid-wave event
  waveStartedAt = performance.now();
  waveEventDone = false;
  waveEventPlanned = false;
  waveEventAt = 0;
  // No events on boss waves or inside special realms.
  if (!currentWaveConfig.bossThisWave && wave >= 2 && !inRift) {
    if (Math.random() < 0.22) {
      waveEventPlanned = true;
      // 9s..18s into the wave feels like "mid-wave"
      waveEventAt = waveStartedAt + 9000 + Math.random() * 9000;
    }
  }

  // wave flash VFX
  waveFlashAlpha = 0.55;

  const waveLabelText = (zone === 'void' && wave >= 30) ? 'WAVE ???' : ("WAVE " + wave);
  if (bossLabel) {
    bossLabel.textContent = (zone === 'void' && wave >= 30) ? "Wave ??? starting!" : ("Wave " + wave + " starting!");
  }
  showToast(waveLabelText);
  triggerShake(8);

  // HARD GUARANTEE: when a run starts (Wave 1), always spawn the player at the
  // center of the active combat map and snap the camera to them.
  // Some flows enter combat without going through the Hub portal helper, which
  // could leave the player at an old position (often near 0,0) and make it look
  // like the camera/enemy AI is broken.
  // Wave 1 is the main "enter combat" seam (menu -> run, hub -> run, retry, etc.).
  // Always hard-center the player + camera here, regardless of the current state,
  // so we never start in a corner with a stuck camera.
  if (w === 1) {
    try {
      player.x = WORLD_WIDTH / 2;
      player.y = WORLD_HEIGHT / 2;
    } catch (_) {}
    try {
      centerCameraOnPlayer(true);
    } catch (_) {
      try {
        const __z = (typeof ARC_CAMERA_ZOOM === 'number' && isFinite(ARC_CAMERA_ZOOM)) ? ARC_CAMERA_ZOOM : 1;
        const __vw = canvas.width / __z;
        const __vh = canvas.height / __z;
        camera.x = Math.max(0, Math.min(WORLD_WIDTH - __vw, Math.round(player.x - __vw / 2)));
        camera.y = Math.max(0, Math.min(WORLD_HEIGHT - __vh, Math.round(player.y - __vh / 2)));
      } catch (_) {}
    }
  }
}


function updateWaveSystem(dt, now) {
  // Wave logic only runs in the normal world (not inside rifts)
  if (gameOver || inRift) return;

  // Safety: if somehow we lost the wave config, rebuild it on the fly
  if (!currentWaveConfig) {
    const safeWave = wave || 1;
    currentWaveConfig = getWaveConfig(safeWave);
    waveEnemiesTarget = currentWaveConfig.enemyCount;
    waveEnemiesSpawned = 0;
    waveEnemiesKilled = 0;
    waveInBreak = false;
    waveBossSpawned = false;
    waveSpawnCooldown = 0;
  }

  // fade wave flash
  if (waveFlashAlpha > 0) {
    waveFlashAlpha = Math.max(0, waveFlashAlpha - dt * 0.08);
  }

  // mid-wave surprise event (supply drop)
  if (waveEventPlanned && !waveEventDone && waveEventAt && now >= waveEventAt) {
    waveEventDone = true;
    waveEventPlanned = false;
    try {
      __spawnSupplyDropEvent();
    } catch (e) {}
  }


  // between waves â chill break
  if (waveInBreak) {
    // If the next wave does NOT switch to a new map/tileset, we keep it snappy:
    // show a short clear beat then auto-start the next wave (no portal).
    if (!waveBreakRequiresPortal) {
      try { hideZoneSummary && hideZoneSummary(); } catch(e) {}
      try { hidePortalHint && hidePortalHint(); } catch(e) {}
      nextWavePortalActive = false;

      if (bossLabel) bossLabel.textContent = "Wave " + wave + " cleared!";

      if (now >= waveBreakEndTime) {
        waveInBreak = false;
        waveBreakRequiresPortal = false;
        startWave(wave + 1);
        return;
      }

      return;
    }

    // Portal-required break: show the zone summary once (clean progression clarity).
    try { showZoneSummary && showZoneSummary(wave, wave + 1); } catch(e) {}

    // Start a short auto-enter countdown (no key press). This keeps pacing tight.
    if (!wavePortalCountdownActive) {
      wavePortalCountdownActive = true;
      const nextZ = getWaveZone(wave + 1);
      // Special pre-void runway: after wave 31, give a longer 10s "get ready" countdown.
      wavePortalCountdownDurationMs = ((wave === 31) && (nextZ === 'void')) ? 10000 : WAVE_PORTAL_COUNTDOWN_MS;
      wavePortalCountdownEnd = now + wavePortalCountdownDurationMs;
    }
    try { setZoneSummaryCountdown && setZoneSummaryCountdown(wavePortalCountdownEnd - now); } catch(e) {}

    // Spawn/keep the VOID portal at map center.
    if (!nextWavePortalActive) {
      nextWavePortalActive = true;
      nextWavePortalX = WORLD_WIDTH / 2;
      nextWavePortalY = WORLD_HEIGHT / 2;
      nextWavePortalPulse = 0;
    }
    nextWavePortalPulse += dt * 0.06;

    // Warp animation (short + clean)
    if (waveWarpActive) {
      waveWarpT = Math.min(1, waveWarpT + dt * 0.02);
      // When fade completes, advance wave and drop the player near center.
      if (waveWarpT >= 1) {
        waveWarpActive = false;
        waveWarpT = 0;
        nextWavePortalActive = false;
        // Close rift offer if it exists, we're taking the normal path.
        if (riftPortalActive) {
          riftPortalActive = false;
          pendingWaveAfterRift = null;
          hidePortalHint();
        }
        startWave(wave + 1);
        // snap player to center so the new lane art feels intentional
        try {
          player.x = WORLD_WIDTH / 2;
          player.y = WORLD_HEIGHT / 2;
        } catch(e) {}
      }
      return;
    }

    // Countdown UI replaces the old "Press E" prompt; keep gameplay clean.
    try { hidePortalHint && hidePortalHint(); } catch(e) {}
    if (bossLabel) bossLabel.textContent = "VOID GATE OPEN – TRANSITIONING";

    // When timer hits 0, trigger the warp animation to the next wave.
    if (wavePortalCountdownEnd && now >= wavePortalCountdownEnd) {
      wavePortalCountdownActive = false;
      wavePortalCountdownEnd = 0;
      try { hideZoneSummary && hideZoneSummary(); } catch(e) {}
      waveWarpActive = true;
      waveWarpT = 0;
      triggerShake(10);
      try { playRiftEnterSound && playRiftEnterSound(); } catch(e) {}
    }

    return;
  }

  const aliveNonBoss = enemies.filter(e => !e.isBoss).length;
  const maxSimul = Math.min(35 + wave * 2, 70); // how many can be on screen

  // spawn wave enemies in batches
  if (waveEnemiesSpawned < waveEnemiesTarget && aliveNonBoss < maxSimul) {
    waveSpawnCooldown -= dt;
    if (waveSpawnCooldown <= 0) {
      const batch = Math.min(3, waveEnemiesTarget - waveEnemiesSpawned);
      for (let i = 0; i < batch; i++) {
        const t = pickEnemyTypeForWave(currentWaveConfig.mix);
        spawnEnemy(t);           // uses your existing types
        waveEnemiesSpawned++;
      }

      const baseCd = 0.9;
      const minCd  = 0.18;
      const scaled = baseCd - wave * 0.06;
      waveSpawnCooldown = Math.max(minCd, scaled);
    }
  }

  // boss per wave (using your existing boss type)
  if (currentWaveConfig.bossThisWave && !waveBossSpawned) {
    // spawn boss once 60% of wave enemies are dead
    if (!bossAlive && waveEnemiesKilled >= Math.floor(waveEnemiesTarget * 0.6)) {
      spawnEnemy("boss");
      waveBossSpawned = true;
      if (bossLabel)
        bossLabel.textContent = "Wave " + wave + " – BOSS!";
      triggerShake(14);
    }
  }

  const remaining = Math.max(0, waveEnemiesTarget - waveEnemiesKilled);

  // check wave completion
  if (!waveInBreak) {
    if (!bossAlive &&
        waveEnemiesKilled >= waveEnemiesTarget &&
        enemies.length === 0) {
      waveInBreak = true;
      // Only require the VOID transition when we are entering a NEW map/tileset.
      // Example: wave 5 -> 6, wave 10 -> 11, wave 21 -> 22.
      const zNow = getWaveZone(wave);
      const zNext = getWaveZone(wave + 1);
      waveBreakRequiresPortal = (zNow !== zNext);

      // Reset countdown state when entering a new break.
      wavePortalCountdownActive = false;
      wavePortalCountdownEnd = 0;

      // When portal is required: wait for player to enter.
      // Otherwise: short auto-advance beat (feels smooth, no "portal spam").
      waveBreakEndTime = now + (waveBreakRequiresPortal ? 60_000 : 900);
      pendingWaveAfterRift = wave + 1;

      nextWavePortalActive = !!waveBreakRequiresPortal;
      nextWavePortalX = WORLD_WIDTH / 2;
      nextWavePortalY = WORLD_HEIGHT / 2;
      if (bossLabel) bossLabel.textContent = "Wave " + wave + " cleared!";
      showToast("Wave " + wave + " cleared!");

      // VOID POINT: reaching wave 30 awards 1 Void Point (once per run)
      try { if (typeof window.awardVoidPointForWave30 === "function") window.awardVoidPointForWave30(wave); } catch(e) {}

      // Offer a Rift portal after mid-game waves
      if (wave >= 3 && !inRift) {
        openRiftPortal();
      }
    } else if (bossLabel) {
      const bossSuffix =
        currentWaveConfig.bossThisWave && !waveBossSpawned ? " – boss soon" :
        currentWaveConfig.bossThisWave && bossAlive ? " – boss alive" : "";
      bossLabel.textContent =
        "Wave " + wave + " – " + remaining + " left" + bossSuffix;
    }
  }
}


// ===== RIFT DUNGEONS (small challenge rooms) =====
// Moved into /js/world/riftSystem.js with data in /js/world/realms.js.
// We keep thin wrapper functions here so the rest of the code can stay mostly unchanged.

const __rift = (typeof window !== "undefined" && window.createRiftSystem)
  ? window.createRiftSystem({
      realms: (window.ARC_REALMS || []),
      state: {
        get gameOver() { return gameOver; },
        get gameState() { return gameState; },

        get inRift() { return inRift; },
        set inRift(v) { inRift = v; },

        get riftDepth() { return riftDepth; },
        set riftDepth(v) { riftDepth = v; },

        get riftPortalActive() { return riftPortalActive; },
        set riftPortalActive(v) { riftPortalActive = v; },

        get riftPortalX() { return riftPortalX; },
        set riftPortalX(v) { riftPortalX = v; },

        get riftPortalY() { return riftPortalY; },
        set riftPortalY(v) { riftPortalY = v; },

        get riftEnemiesTarget() { return riftEnemiesTarget; },
        set riftEnemiesTarget(v) { riftEnemiesTarget = v; },

        get riftEnemiesSpawned() { return riftEnemiesSpawned; },
        set riftEnemiesSpawned(v) { riftEnemiesSpawned = v; },

        get riftEnemiesKilled() { return riftEnemiesKilled; },
        set riftEnemiesKilled(v) { riftEnemiesKilled = v; },

        get riftSpawnCooldown() { return riftSpawnCooldown; },
        set riftSpawnCooldown(v) { riftSpawnCooldown = v; },

        get pendingWaveAfterRift() { return pendingWaveAfterRift; },
        set pendingWaveAfterRift(v) { pendingWaveAfterRift = v; },

        get riftEnterFlash() { return riftEnterFlash; },
        set riftEnterFlash(v) { riftEnterFlash = v; },

        get waveFlashAlpha() { return waveFlashAlpha; },
        set waveFlashAlpha(v) { waveFlashAlpha = v; },

        get animTime() { return animTime; },
      },
      world: {
        WORLD_WIDTH,
        WORLD_HEIGHT,
        camera,
        canvas,
        ctx
      },
      collections: {
        get enemies() { return enemies; },
        set enemies(v) { enemies = v; },

        get bullets() { return bullets; },
        set bullets(v) { bullets = v; },

        get enemyBullets() { return enemyBullets; },
        set enemyBullets(v) { enemyBullets = v; },

        get powerups() { return powerups; },
        set powerups(v) { powerups = v; },

        get damagePopups() { return damagePopups; },
        set damagePopups(v) { damagePopups = v; },
      },
      api: {
        showToast: (msg) => showToast(msg),
        showPortalHint: () => showPortalHint(),
        hidePortalHint: () => hidePortalHint(),
        triggerShake: (n) => triggerShake(n),
        spawnEnemy: (t) => spawnEnemy(t),
        startWave: (w) => startWave(w),
        addXP: (xp) => addXP(xp),
        spawnArcPopup: (amt, x, y) => spawnArcPopup(amt, x, y),
        showSolanaRealmToast: () => (typeof showSolanaRealmToast === "function" ? showSolanaRealmToast() : showToast("Entered the Rift!")),
        playRiftEnterSound: () => (typeof playRiftEnterSound === "function" ? playRiftEnterSound() : null),
        spawnPowerup: () => (typeof spawnPowerup === "function" ? spawnPowerup() : null),
      }
    })
  : null;

// Wrapper functions (keeps the rest of game.js unchanged)
function openRiftPortal() { __rift && __rift.openPortal(); }
function enterRift() { __rift && __rift.enter(); }
function updateRiftSystem(dt, now) { __rift && __rift.update(dt, now); }
function exitRift(success = true) { __rift && __rift.exit(success); }
function drawRiftOverlay() { __rift && __rift.drawOverlay(); }
function drawRiftPortal() { __rift && __rift.drawPortal(); }
    function tryDash() {
      const now = performance.now();
      if (now - lastDashTime < player.dashCooldown) return;
      const moveX = (keys["d"] ? 1 : 0) - (keys["a"] ? 1 : 0);
      const moveY = (keys["s"] ? 1 : 0) - (keys["w"] ? 1 : 0);
      if (moveX === 0 && moveY === 0) return;
      lastDashTime = now;
      dashEndTime = now + player.dashDuration;
      dashId++;
      perfectDashWindowEnd = now + 420;
      playDashWhoosh();
      try { document.body.classList.add('dash-flash'); setTimeout(()=>document.body.classList.remove('dash-flash'), 120); } catch(e) {}

// Dash VFX: ring + afterimages (makes SHIFT feel incredible)
try {
  // ring burst
  for (let i = 0; i < 22; i++) {
    const ang = (Math.PI * 2 * i) / 22;
    const sp = 2.2 + Math.random() * 1.4;
    particles.push({
      x: player.x,
      y: player.y,
      vx: Math.cos(ang) * sp,
      vy: Math.sin(ang) * sp,
      life: 22 + Math.random() * 10,
      color: getCosColor(cosmetics.aura, 0.95)
    });
  }
  // short trail behind direction
  const dir = Math.atan2(moveY, moveX);
  for (let t = 0; t < 9; t++) {
    particles.push({
      x: player.x - Math.cos(dir) * (t * 8),
      y: player.y - Math.sin(dir) * (t * 8),
      vx: (Math.random() * 2 - 1) * 0.12,
      vy: (Math.random() * 2 - 1) * 0.12,
      life: 14 + t * 2,
      color: getCosColor(cosmetics.trail, 0.85)
    });
  }
  triggerShake(4);
  slowMoTime = Math.max(slowMoTime, 0.035);
} catch (e) {}

// Mutation: Validator Lag — dashes feel "chain-y" with micro slow-mo
if (hasMutation("validator_lag")) {
  slowMoTime = Math.max(slowMoTime, 0.08);
  triggerShake(3);
}
    }

    
function restartGame() {
  // run stats
  runStartTime = performance.now();
  wavesCleared = 0;
  try { if (typeof window.resetVoidPointRunFlag === 'function') window.resetVoidPointRunFlag(); } catch(e) {};
  networkEventsCleared = 0;
  perfectDashCount = 0;
  bestArcStreak = 0;
// core flags
  gameOver = false;
  gameState = "playing";
  setMusicMood("cave");

  // New objective each run
  pickRunGoal();



      // basic counters
      points = 0;
      kills = 0;

      // projectiles / entities
      bullets = [];
      enemyBullets = [];
      enemies = [];
      powerups = [];
      damagePopups = [];
      arcOrbs = [];
      particles = [];

      // boss + combat pacing
      bossAlive = false;
      bossKillsTrigger = 20;

      // timings
      lastShotTime = 0;
      lastDashTime = -9999;
      dashEndTime = -9999;
      lastTime = performance.now();
      animTime = 0;
      shakeTime = 0;
      shakeIntensity = 0;

      // XP / streak / multipliers
      xpMultiplier = 1;
      arcMultiplier = 1;
      arcStreak = 0;
      arcStreakLastKillTime = 0;
      lastKillTime = 0;
      killComboCount = 0;
      lastKillToastTime = 0;

      
// === MUTATIONS + NETWORK EVENTS ===
networkEvent = null;
nextNetworkEventAt = 0;
try { document.body.classList.remove("event-blackout"); } catch(e) {}
// boosts
      xpBoostActive = false;
      xpBoostEndTime = 0;
      speedBoostActive = false;
      speedBoostEndTime = 0;

      // rift state
      inRift = false;
      riftDepth = 0;
      riftEnemiesTarget = 0;
      riftEnemiesSpawned = 0;
      riftEnemiesKilled = 0;
      riftSpawnCooldown = 0;
      riftPortalActive = false;
      riftPortalX = WORLD_WIDTH / 2;
      riftPortalY = WORLD_HEIGHT / 2;
      pendingWaveAfterRift = null;
      riftEnterFlash = 0;
      hidePortalHint();

      // reset player + world
      resetPlayer();
      generateTilemap();
// Roll roguelite run mutations AFTER we have fresh player stats
try {
  rollRunMutations(performance.now());
} catch (e) { console.error("Mutation roll failed", e); }
     // regenerate map on restart
      // initDecorations(); // decorations disabled     // reposition decorative trees on restart

      // wave system
      currentWaveConfig = null;
      wave = 1;
      waveEnemiesTarget = 0;
      waveEnemiesSpawned = 0;
      waveEnemiesKilled = 0;
      waveInBreak = false;
      waveBreakEndTime = 0;
      waveBossSpawned = false;
      waveSpawnCooldown = 0;
      waveFlashAlpha = 0;

      // UI
      gameOverEl.style.display = "none";
      if (bossLabel) bossLabel.textContent = "Wave 1 – starting";
      if (bossbar) bossbar.style.display = "none";


      // start fresh wave 1
      // Force a correct combat spawn/camera for the first few frames.
      // This prevents the "spawn in the top-left / camera parked elsewhere" bug
      // even if some UI/state code briefly overwrites player/camera values.
      __forceCombatSpawnFrames = 8;

      startWave(1);

      // startWave(1) can change mapMode/world bounds. Spawn AFTER it so we don't
      // appear in the corner of the newly selected map.
      placePlayerAtCombatSpawn();
      centerCameraOnPlayer(true);
    }

    // Expose restartGame globally so the HTML button can call it safely
    window.restartGame = restartGame;

    // QoL: jump directly to a wave for testing.
    // This clears combat entities and starts the requested wave without touching leaderboards.
    window.__devJumpToWave = function __devJumpToWave(targetWave){
      const w = Math.max(1, Math.floor(Number(targetWave) || 1));
      try {
        // Make sure we are in gameplay.
        if (typeof gameState !== "undefined") gameState = "playing";
        const mm = document.getElementById("main-menu");
        if (mm) mm.style.display = "none";

        // Clear entities so we don't carry junk across.
        try { bullets = []; } catch(e) {}
        try { enemyBullets = []; } catch(e) {}
        try { enemies = []; } catch(e) {}
        try { powerups = []; } catch(e) {}
        try { damagePopups = []; } catch(e) {}
        try { arcOrbs = []; } catch(e) {}
        try { particles = []; } catch(e) {}

        // Reset transient wave flags.
        try { bossAlive = false; } catch(e) {}
        try { waveInBreak = false; } catch(e) {}
        try { waveBreakRequiresPortal = false; } catch(e) {}
        try { nextWavePortalActive = false; } catch(e) {}
        try { waveWarpActive = false; waveWarpT = 0; } catch(e) {}
        try { wavePortalCountdownActive = false; wavePortalCountdownEnd = 0; } catch(e) {}

        // Spawn player to center so map changes feel intentional.
        try {
          player.x = WORLD_WIDTH / 2;
          player.y = WORLD_HEIGHT / 2;
        } catch(e) {}

        startWave(w);
        showToast("JUMPED TO WAVE " + w);
      } catch (e) {
        console.warn("__devJumpToWave failed", e);
      }
    };

    let toastTimeout = null;
    function showToast(text) {
      centerToast.textContent = text;
      centerToast.style.opacity = "1";
      centerToast.style.transform = "translate(-50%, -50%) scale(1)";
      centerToast.style.transition = "opacity 0.25s ease-out, transform 0.25s ease-out";
      if (toastTimeout) clearTimeout(toastTimeout);
      toastTimeout = setTimeout(() => {
        centerToast.style.opacity = "0";
        centerToast.style.transform = "translate(-50%, -50%) scale(0.98)";
      }, 900);
    }

    // Compat alias: some parts of the code call toastCenter(...)
    // Keep it as a thin wrapper around the existing center toast.
    function toastCenter(text) {
      showToast(text);
    }
    window.toastCenter = toastCenter;

// ============================
// SYSTEM BANNER (separate from kill toasts)
// ============================
let systemBannerEl = null;
let systemBannerTimeout = null;
let systemLog = []; // last few system messages

function initSystemBanner() {
  try {
    systemBannerEl = document.getElementById("system-banner");
  } catch (e) {}
}

function pushSystemLog(line) {
  try {
    systemLog.unshift(line);
    systemLog = systemLog.slice(0, 4);
    const logEl = document.getElementById("system-log");
    if (logEl) logEl.textContent = systemLog.map(x => "• " + x).join("\n");
  } catch (e) {}
}

function showSystemBanner(text, ms = 2600) {
  pushSystemLog(text);

  if (!systemBannerEl) initSystemBanner();
  if (!systemBannerEl) return;

  systemBannerEl.textContent = text;
  systemBannerEl.classList.add("show");

  if (systemBannerTimeout) clearTimeout(systemBannerTimeout);
  systemBannerTimeout = setTimeout(() => {
    systemBannerEl.classList.remove("show");
  }, ms);
}

window.showSystemBanner = showSystemBanner;

// ============================
// ZONE SUMMARY (shown only on NEW map/tileset transitions)
// ============================
let zoneSummaryOpen = false;
let zoneSummaryForWave = -1; // cleared wave number we rendered for

function zoneDisplayName(zone){
  switch (String(zone || '')) {
    case 'level0': return 'FARM FIELDS';
    case 'level2': return 'FARM LANE';
    case 'level3': return 'SNOW FOREST';
    case 'desert': return 'DESERT RUINS';
    default: return String(zone || 'UNKNOWN').toUpperCase();
  }
}

function fmtPct(x){
  const n = Number(x);
  if (!isFinite(n)) return '0%';
  return `${Math.round(n * 100)}%`;
}

function buildZoneSummaryStatsText(){
  try {
    const totalXpMult = (player.xpGearMult || 1) * (player.xpRelicMult || 1);
    const arcKillBonus = player.arcRelicMult || 0;
    const lines = [
      `DMG: ${Math.round(player.damage || 0)}`,
      `MAX HP: ${Math.round(player.maxHp || 0)}`,
      `SPD: ${Number(player.speed || 0).toFixed(2)}`,
      `FIRE: ${Math.round(player.fireRate || 0)}ms`,
      `DASH CD: ${Math.round(player.dashCooldown || 0)}ms`,
      `XP MULT: x${totalXpMult.toFixed(2)}`,
      `ARC (kill): +${fmtPct(arcKillBonus)}`,
    ];
    return lines.join('\n');
  } catch (e) {
    return '';
  }
}

function buildZoneSummaryRelicText(){
  try {
    const name = (window.cosmetics && window.cosmetics.relic) ? window.cosmetics.relic : (cosmetics && cosmetics.relic);
    if (!name || name === 'none' || name === 'NONE') return 'None equipped.';
    const fx = getRelicEffect(name);
    if (!fx) return `${name}`;
    return `${name}\n${fx.desc || ''}`.trim();
  } catch (e) {
    return 'None equipped.';
  }
}

function showZoneSummary(clearedWave, nextWave){
  if (!zoneSummaryOverlay || !zoneSummaryTitle || !zoneSummarySub) return;
  if (!clearedWave || clearedWave <= 0) return;
  if (zoneSummaryForWave === clearedWave && zoneSummaryOpen) return;

  const zNow = getWaveZone(clearedWave);
  const zNext = getWaveZone(nextWave);

  zoneSummaryForWave = clearedWave;
  zoneSummaryOpen = true;

  // Special pre-void overlay (Wave 31 -> Endless Void)
  if ((clearedWave === 31) && (zNext === 'void')) {
    zoneSummaryTitle.textContent = 'CONGRATULATIONS';
    zoneSummarySub.textContent = 'You cleared Wave 31.';
    if (zoneSummaryNext) zoneSummaryNext.textContent = 'ENTERING: ENDLESS VOID';
    if (zoneSummaryRelics) zoneSummaryRelics.textContent = 'Every enemy you\'ve fought can appear in the Void.';
    if (zoneSummaryStats) zoneSummaryStats.textContent = 'Get ready. Survive as long as you can.';
  } else {
    zoneSummaryTitle.textContent = zoneDisplayName(zNow);
    zoneSummarySub.textContent = `Wave ${clearedWave} complete`;
    if (zoneSummaryNext) zoneSummaryNext.textContent = `ENTERING: ${zoneDisplayName(zNext)}`;
    if (zoneSummaryRelics) zoneSummaryRelics.textContent = buildZoneSummaryRelicText();
    if (zoneSummaryStats) zoneSummaryStats.textContent = buildZoneSummaryStatsText();
  }

  zoneSummaryOverlay.classList.remove('hidden');
  zoneSummaryOverlay.setAttribute('aria-hidden', 'false');
  // next tick for transition
  requestAnimationFrame(() => {
    try { zoneSummaryOverlay.classList.add('show'); } catch(e) {}
  });
}

function setZoneSummaryCountdown(remainingMs){
  // remainingMs: time until auto-enter
  if (!zoneSummaryTimerValue || !zoneSummaryTimerFill) return;
  const ms = Math.max(0, Number(remainingMs) || 0);
  const s = Math.ceil(ms / 1000);
  zoneSummaryTimerValue.textContent = String(s);
  const denom = Math.max(1, Number(wavePortalCountdownDurationMs || WAVE_PORTAL_COUNTDOWN_MS));
  const p = Math.max(0, Math.min(1, ms / denom));
  const pct = Math.round(p * 100);
  zoneSummaryTimerFill.style.width = pct + '%';
  // update ARIA on the bar
  try {
    const bar = zoneSummaryTimerFill.parentElement;
    if (bar && bar.getAttribute) bar.setAttribute('aria-valuenow', String(pct));
  } catch(e) {}
}

function hideZoneSummary(){
  if (!zoneSummaryOverlay) return;
  zoneSummaryOpen = false;
  try { zoneSummaryOverlay.classList.remove('show'); } catch(e) {}
  zoneSummaryOverlay.setAttribute('aria-hidden', 'true');
  // allow fade-out
  setTimeout(() => {
    if (!zoneSummaryOpen) zoneSummaryOverlay.classList.add('hidden');
  }, 240);
}

window.__hideZoneSummary = hideZoneSummary;

    // Big, persistent hint specifically for the Solana portal / rift.
    
// =========================
// INVENTORY / CUSTOMIZE UI
// =========================
let inventoryOpen = false;
let invDeniedAt = 0;
let invTab = "auras";

function isInHub() { return gameState === "farmHub"; }

// =========================
// RELICS (what they do)
// =========================
// These are passive run modifiers. Equipping one applies its bonus immediately.
// (We keep the numbers small but noticeable.)
const RELIC_EFFECTS = {
  'Rusty Charm':     { bonus:{ damage: 1 },             desc:'Slight damage boost.' },
  'Farm Token':      { bonus:{ hp: 8 },                 desc:'Max HP +8.' },
  'Old Coin':        { bonus:{ },                       desc:'...It just feels lucky. (+2% ARC from kills)', arcMult:0.02 },
  'Lucky Seed':      { bonus:{ speed: 0.18 },           desc:'Move speed +0.18.' },
  'Copper Sigil':    { bonus:{ fireRate: -6 },          desc:'Slightly faster fire rate.' },

  'Arc Prism':       { bonus:{ damage: 3 },             desc:'Damage +3.' },
  'Wind Rune':       { bonus:{ speed: 0.35 },           desc:'Move speed +0.35.' },
  'Harvest Crest':   { bonus:{ hp: 14 },                desc:'Max HP +14.' },
  'Silver Sigil':    { bonus:{ fireRate: -14 },         desc:'Fire rate faster.' },
  'Star Map':        { bonus:{ },                       desc:'More XP from kills (+10%).', xpMult:0.10 },

  'Void Lens':       { bonus:{ damage: 6 },             desc:'Damage +6.' },
  'Chrono Sprout':   { bonus:{ dashCooldown: -120 },    desc:'Dash cooldown -120ms.' },
  'Royal Emblem':    { bonus:{ hp: 22 },                desc:'Max HP +22.' },
  'Aether Coil':     { bonus:{ fireRate: -26 },         desc:'Fire rate much faster.' },
  'Sol Bloom':       { bonus:{ },                       desc:'XP +18%.', xpMult:0.18 },

  'Rift Heart':      { bonus:{ hp: 32 },                desc:'Max HP +32.' },
  'Golden Circuit':  { bonus:{ damage: 10 },            desc:'Damage +10.' },
  'Eclipse Band':    { bonus:{ },                       desc:'ARC multiplier +5% (from kills).', arcMult:0.05 },
  'Astral Totem':    { bonus:{ dashCooldown: -220 },    desc:'Dash cooldown -220ms.' },
  'Neon Relic':      { bonus:{ speed: 0.6 },            desc:'Move speed +0.6.' },

  'Genesis Relic':   { bonus:{ hp: 55, damage: 12 },    desc:'Big stats. HP +55, Damage +12.' },
  'Dragon Warrant':  { bonus:{ damage: 18 },            desc:'Damage +18.' },
  'Infinity Crest':  { bonus:{ fireRate: -55 },         desc:'Insane fire rate.' },
  'World Key':       { bonus:{ speed: 0.85, dashCooldown: -260 }, desc:'Speed +0.85, Dash cooldown -260ms.' },
  'Solana Crown':    { bonus:{ },                       desc:'XP +25% and ARC +8% (from kills).', xpMult:0.25, arcMult:0.08 },
};

function getRelicEffect(name){
  if (!name || name === 'none' || name === 'NONE') return null;
  return RELIC_EFFECTS[name] || null;
}

function openInventory() {
if (!isInHub()) {
  const now = performance.now();
  if (now - invDeniedAt > 1200) {
    invDeniedAt = now;
    try { toastCenter("INVENTORY: OPEN IT IN FARM HUB (press K)"); } catch(e) {}
  }
  return;
}
const overlay = document.getElementById("inventory-overlay");
if (!overlay) return;
inventoryOpen = true;
// Treat inventory as a modal UI: pause game input and allow DOM interaction.
try { document.body.classList.add('ui-open'); } catch(e) {}
try { if (typeof window.setPaused === 'function') window.setPaused(true); } catch(e) {}
overlay.classList.remove("hidden");
overlay.setAttribute("aria-hidden", "false");
renderInventoryUI();
}

function closeInventory() {
  const overlay = document.getElementById("inventory-overlay");
  if (!overlay) return;
  inventoryOpen = false;
  overlay.classList.add("hidden");
  overlay.setAttribute("aria-hidden", "true");
  try { document.body.classList.remove('ui-open'); } catch(e) {}
  try { if (typeof window.setPaused === 'function') window.setPaused(false); } catch(e) {}
}

function toggleInventory() {
  if (inventoryOpen) closeInventory();
  else openInventory();
}

// ESC should always back out of inventory (hub-only modal).
window.addEventListener('keydown', (e) => {
  try {
    if (!inventoryOpen) return;
    if ((e.key || '').toLowerCase() !== 'escape') return;
    e.preventDefault();
    closeInventory();
  } catch(_) {}
});

function renderInventoryUI() {
  try {
    // --- Gear slots ---
    const slotsEl = document.getElementById("inventory-slots");
    if (slotsEl) {
      const slots = ["helmet", "chest", "boots", "gloves", "accessory"];
      const rows = slots.map(slot => {
        const item = player.gear && player.gear[slot] ? player.gear[slot] : null;
        const itemName = item ? item.name : "Empty";
        const btn = item ? `<button class="inv-unequip" data-unequip="${slot}">UNEQUIP</button>` : "";
        return `<div class="inv-slot"><span class="slot-name">${slot.toUpperCase()}</span><span class="item-name">${itemName}</span>${btn}</div>`;
      });
      slotsEl.innerHTML = rows.join("");
    }

    // --- Tabs ---
    const tabBtns = document.querySelectorAll(".inv-tab");
    tabBtns.forEach(btn => {
      const t = btn.getAttribute("data-tab");
      btn.classList.toggle("active", t === invTab);
    });

    // --- Cosmetic items ---
    const itemsEl = document.getElementById("inv-items");
    if (!itemsEl) return;

    const AURAS = [
      { id: "cyan",   name: "CYAN GLOW",   desc: "Clean neon aura.", swatch: "linear-gradient(135deg, rgba(56,189,248,0.75), rgba(56,189,248,0.10))" },
      { id: "purple", name: "PURPLE VOID", desc: "Arcane shimmer.",  swatch: "linear-gradient(135deg, rgba(168,85,247,0.75), rgba(168,85,247,0.10))" },
      { id: "green",  name: "GREEN LIFE",  desc: "Fresh farm energy.", swatch: "linear-gradient(135deg, rgba(34,197,94,0.75), rgba(34,197,94,0.10))" },
      { id: "gold",   name: "GOLDEN ARC",  desc: "Premium glow.",    swatch: "linear-gradient(135deg, rgba(250,204,21,0.85), rgba(250,204,21,0.10))" },
      { id: "none",   name: "NO AURA",     desc: "Disable aura.",    swatch: "linear-gradient(135deg, rgba(148,163,184,0.35), rgba(148,163,184,0.05))" },
    ];

    const TRAILS = [
      { id: "purple", name: "PURPLE TRAIL", desc: "Dash/ARC trail in purple.", swatch: "linear-gradient(135deg, rgba(168,85,247,0.75), rgba(168,85,247,0.10))" },
      { id: "cyan",   name: "CYAN TRAIL",   desc: "Dash/ARC trail in cyan.",   swatch: "linear-gradient(135deg, rgba(56,189,248,0.75), rgba(56,189,248,0.10))" },
      { id: "green",  name: "GREEN TRAIL",  desc: "Dash/ARC trail in green.",  swatch: "linear-gradient(135deg, rgba(34,197,94,0.75), rgba(34,197,94,0.10))" },
      { id: "gold",   name: "GOLD TRAIL",   desc: "Dash/ARC trail in gold.",   swatch: "linear-gradient(135deg, rgba(250,204,21,0.85), rgba(250,204,21,0.10))" },
      { id: "none",   name: "NO TRAIL",     desc: "Disable trail.",            swatch: "linear-gradient(135deg, rgba(148,163,184,0.35), rgba(148,163,184,0.05))" },
    ];

    const RELICS = [
      { id: "none",   name: "NONE",   desc: "No relic equipped.", swatch: "linear-gradient(135deg, rgba(148,163,184,0.35), rgba(148,163,184,0.05))" },
    ];

    let list = AURAS;
    let selectedKey = "aura";
    if (invTab === "trails") { list = TRAILS; selectedKey = "trail"; }
    if (invTab === "relics") { list = RELICS; selectedKey = "relic"; }

    const shopState = (typeof window !== 'undefined') ? window.ARC_SHOP_STATE : null;
    const selected = (cosmetics && cosmetics[selectedKey]) || "none";

    // Only show what the player OWNS (plus NONE). Ownership is driven by Shop unlocks.
    if (shopState && shopState.ownedCosmetics) {
      if (invTab === "auras") {
        list = AURAS.filter(it => it.id === "none" || !!shopState.ownedCosmetics.aura?.[it.id]);
      }
      if (invTab === "trails") {
        list = TRAILS.filter(it => it.id === "none" || !!shopState.ownedCosmetics.trail?.[it.id]);
      }
    }

    // Relics tab shows your stash from the Shop (name, rarity, qty)
    if (shopState && invTab === "relics") {
      const relicArr = Object.values(shopState.relics || {});
      if (relicArr.length) {
        itemsEl.innerHTML = relicArr.sort((a,b)=> (a.rarity||'').localeCompare(b.rarity||'') || a.name.localeCompare(b.name)).map(r => {
          const cls = (typeof window.rarityClass === 'function') ? window.rarityClass(r.rarity) : '';
          const active = (selected === r.name);
          const fx = getRelicEffect(r.name);
          const fxLine = fx ? fx.desc : 'Unknown relic effect (missing data).';
          const bonusParts = [];
          try {
            const b = fx && fx.bonus ? fx.bonus : {};
            if (b.damage) bonusParts.push('DMG +' + b.damage);
            if (b.hp) bonusParts.push('HP +' + b.hp);
            if (b.speed) bonusParts.push('SPD +' + b.speed);
            if (b.fireRate) bonusParts.push('FIRE ' + (b.fireRate < 0 ? b.fireRate : ('+'+b.fireRate)));
            if (b.dashCooldown) bonusParts.push('DASH ' + b.dashCooldown + 'ms');
            if (fx && typeof fx.xpMult === 'number') bonusParts.push('XP +' + Math.round(fx.xpMult*100) + '%');
            if (fx && typeof fx.arcMult === 'number') bonusParts.push('ARC +' + Math.round(fx.arcMult*100) + '%');
          } catch(e) {}
          return `
            <div class="inv-item ${cls} ${active ? "active" : ""}" style="cursor:pointer;" data-cos-kind="relic" data-cos-id="${r.name}">
              <div class="inv-name"><span class="${cls}">${r.rarity || ''}</span> ${r.name}</div>
              <div class="inv-desc">${fxLine}</div>
              <div class="inv-desc" style="opacity:0.8;">${bonusParts.length ? bonusParts.join(' • ') : ''}</div>
              <div class="inv-desc" style="opacity:0.8;">Owned: ${r.qty || 0}${active ? ' • Equipped' : ''}</div>
            </div>
          `;
        }).join("");
        return;
      }
    }

    itemsEl.innerHTML = list.map(it => {
      const active = (selected === it.id);
      return `
        <div class="inv-item ${active ? "active" : ""}" data-cos-kind="${selectedKey}" data-cos-id="${it.id}">
          <div class="inv-swatch" style="background:${it.swatch}"></div>
          <div class="inv-name">${it.name}</div>
          <div class="inv-desc">${it.desc}</div>
        </div>
      `;
    }).join("");
  } catch (e) {}
}


window.addEventListener("click", (ev) => {
  const t = ev.target;
  if (!t) return;
  // Robust targeting: many buttons contain child spans/divs.
  const closestId = (id) => (t.closest ? t.closest('#' + id) : (t.id === id ? t : null));
  const closestClass = (cls) => (t.closest ? t.closest('.' + cls) : (t.classList && t.classList.contains(cls) ? t : null));

  // Customize panel (event delegation so it works even if load listeners fail)
  if (closestId('customize-btn')) {
    ev.preventDefault();
    try { openCustomizePanel(); } catch(e) {}
    return;
  }
  if (closestId('customize-close')) {
    ev.preventDefault();
    try { closeCustomizePanel(); } catch(e) {}
    return;
  }
  if (closestId('customize-save')) {
    ev.preventDefault();
    try { saveCosmetics(); } catch(e) {}
    try { closeCustomizePanel(); } catch(e) {}
    return;
  }
  const slotAction = closestClass('slot-action');
  if (slotAction) {
    ev.preventDefault();
    const slot = slotAction.getAttribute('data-slot-action');
    try { __cycleCos(slot); } catch(e) {}
    return;
  }

  // top-right button
  if (closestId("inventory-btn")) {
    ev.preventDefault();
    if (isInHub()) toggleInventory();
    else openInventory();
    return;
  }

  // close
  if (closestId("inventory-close")) {
    closeInventory();
    return;
  }

  // tabs
  const tabBtn = closestClass('inv-tab');
  if (tabBtn) {
    const tab = tabBtn.getAttribute("data-tab");
    if (tab) {
      invTab = tab;
      renderInventoryUI();
    }
    return;
  }

  // gear unequip
  const unequip = t.getAttribute && t.getAttribute("data-unequip");
  if (unequip) {
    if (player.gear) player.gear[unequip] = null;
    recomputeStats();
    renderInventoryUI();
    return;
  }

  // click on an item card (or inside it)
  const card = (t.closest && t.closest(".inv-item")) ? t.closest(".inv-item") : null;
  if (card) {
    const kind = card.getAttribute("data-cos-kind"); // aura/trail/relic
    const id = card.getAttribute("data-cos-id");
    if (kind && id) {
      cosmetics[kind] = id;
      saveCosmetics();
      // Relics affect gameplay stats, so apply instantly.
      if (kind === 'relic') {
        try { recomputeStats && recomputeStats(); } catch(e) {}
        try {
          const fx = getRelicEffect(id);
          const msg = fx ? (`RELIC EQUIPPED: ${id} â¢ ${fx.desc}`) : (`RELIC EQUIPPED: ${id}`);
          (typeof showSystemBanner === 'function') ? showSystemBanner(msg, 2200) : showToast(msg);
        } catch(e) {}
      }
      renderInventoryUI();
    }
    return;
  }
});


window.addEventListener("keydown", (ev) => {
  // Inventory toggle (I). We only *open* in the Farm Hub.
  const k = (ev.key || "").toLowerCase();
  if (k === "k") {
    ev.preventDefault();
    if (isInHub()) toggleInventory();
    else openInventory(); // will show a throttled toast
    return;
  }
});


// =========================
// FARM HUB SYSTEM (V1)
// - Safe pre-run zone
// - Lifetime ARC upgrades
// - Door: ENTER THE REALM WAVES [F]
// =========================
let farmUpgrades = (() => {
  try { return JSON.parse(localStorage.getItem("arcUpgrades") || '{"dmg":0,"hp":0,"speed":0}'); }
  catch { return { dmg:0, hp:0, speed:0 }; }
})();

// =========================
// COSMETICS (saved locally)
// =========================
let cosmetics = {
  aura: "cyan",
  trail: "purple",
  accent: "gold",
  shirt: "none",
  hat: "none",
  boots: "none",
  cape: "none",
  relic: "none"
};

function loadCosmetics() {
  try {
    const raw = localStorage.getItem("arc_cosmetics_v1");
    if (raw) {
      const obj = JSON.parse(raw);
      if (obj && typeof obj === "object") cosmetics = { ...cosmetics, ...obj };
    }
  } catch (e) {}

  // Expose the live object for other scripts (e.g., customization.js)
  try { window.cosmetics = cosmetics; } catch (e) {}
}

// Load saved cosmetics once
try { loadCosmetics(); } catch(e) {}

function saveCosmetics() {
  try { localStorage.setItem("arc_cosmetics_v1", JSON.stringify(cosmetics)); } catch (e) {}
  try { window.cosmetics = cosmetics; } catch (e) {}
}

// Expose helpers (safe no-ops if window isn't available)
try {
  window.cosmetics = cosmetics;
  window.saveCosmetics = saveCosmetics;
  window.loadCosmetics = loadCosmetics;
} catch (e) {}

// =========================
// STYLE STUDIO PRESETS (3 slots)
// =========================
const COS_PRESET_KEY = "arc_cosmetic_presets_v1";
let cosmeticPresets = [
  { name: "Void Drip", data: null },
  { name: "Gold Arc", data: null },
  { name: "Neon Runner", data: null },
];

function loadCosmeticPresets(){
  try{
    const raw = localStorage.getItem(COS_PRESET_KEY);
    if (!raw) return;
    const arr = JSON.parse(raw);
    if (Array.isArray(arr)) {
      cosmeticPresets = cosmeticPresets.map((d,i)=>{
        const src = arr[i];
        if (!src || typeof src !== "object") return d;
        return {
          name: (typeof src.name === "string" && src.name.trim()) ? src.name.trim().slice(0,18) : d.name,
          data: (src.data && typeof src.data === "object") ? src.data : null
        };
      });
    }
  }catch(e){}
}

function saveCosmeticPresets(){
  try{ localStorage.setItem(COS_PRESET_KEY, JSON.stringify(cosmeticPresets)); }catch(e){}
}

function __syncPresetInputs(){
  for (let i=0;i<3;i++){
    const inp = document.getElementById(`preset-name-${i}`);
    if (inp && typeof inp.value === "string") {
      // don't overwrite if user is actively typing
      if (document.activeElement !== inp) inp.value = cosmeticPresets[i]?.name || inp.value || `Preset ${i+1}`;
    }
  }
}

function __captureCosmeticsSnapshot(){
  // Keep it explicit so future cosmetics don't accidentally leak into presets.
  const keys = ["hat","boots","cape","trail","aura","accent"];
  const snap = {};
  for (const k of keys) snap[k] = (cosmetics && cosmetics[k] != null) ? cosmetics[k] : "None";
  return snap;
}

function savePreset(slot){
  const i = Math.max(0, Math.min(2, Number(slot)||0));
  const inp = document.getElementById(`preset-name-${i}`);
  const name = (inp && typeof inp.value === "string" && inp.value.trim()) ? inp.value.trim().slice(0,18) : (cosmeticPresets[i]?.name || `Preset ${i+1}`);
  cosmeticPresets[i] = { name, data: __captureCosmeticsSnapshot() };
  saveCosmeticPresets();
  try { if (typeof showToast === "function") showToast(`SAVED: ${name}`); } catch(e){}
}

function loadPreset(slot){
  const i = Math.max(0, Math.min(2, Number(slot)||0));
  const p = cosmeticPresets[i];
  if (!p || !p.data) {
    try { if (typeof showToast === "function") showToast("EMPTY PRESET"); } catch(e){}
    return;
  }
  cosmetics = { ...cosmetics, ...p.data };
  saveCosmetics();
  try { __renderCustomizeUI(); } catch(e){}
  __syncPresetInputs();
  try { if (typeof showToast === "function") showToast(`LOADED: ${p.name || "PRESET"}`); } catch(e){}
}

try { loadCosmeticPresets(); } catch(e) {}
window.savePreset = savePreset;
window.loadPreset = loadPreset;


function getCosColor(key, alpha=0.9) {
  const map = {
    cyan: `rgba(56,189,248,${alpha})`,
    purple: `rgba(168,85,247,${alpha})`,
    green: `rgba(34,197,94,${alpha})`,
    gold: `rgba(250,204,21,${alpha})`,
    none: `rgba(255,255,255,0)`
  };
  return map[key] || map.cyan;
}

// =========================
// CUSTOMIZE UI (Farm Hub)
// =========================
const __COS_CYCLE = {
  hat:   ["none","beanie","ranger","void"],
  boots: ["none","swift","heavy","void"],
  cape:  ["none","short","hero","void"],
  trail: ["none","gold","cyan","purple","green"],
  aura:  ["none","cyan","purple","gold","green"],
  accent:["gold","cyan","purple","green"]
};

function __getSelectedCharCfg(){
  try {
    const cfg = (typeof CHARACTER_CONFIGS !== 'undefined') ? CHARACTER_CONFIGS.find(c=>c.id===selectedCharacterId) : null;
    return cfg || null;
  } catch(_) { return null; }
}

function __renderCustomizeUI(){
  const panel = document.getElementById('customize-panel');
  if (!panel) return;
  const cfg = __getSelectedCharCfg();
  const img = document.getElementById('customize-preview-img');
  if (img) img.src = (cfg && cfg.previewSrc) ? cfg.previewSrc : (cfg && cfg.idleSrc) ? cfg.idleSrc : 'Owlet_Monster.png';

  const setText = (id, v) => {
    const el = document.getElementById(id);
    if (el) el.textContent = (v || 'none').toString().replace(/^none$/,'None');
  };
  setText('slot-hat', cosmetics.hat);
  setText('slot-boots', cosmetics.boots);
  setText('slot-cape', cosmetics.cape);
  setText('slot-trail', cosmetics.trail);
  setText('slot-aura', cosmetics.aura);
  setText('slot-accent', cosmetics.accent);
}

function __cycleCos(slot){
  const list = __COS_CYCLE[slot];
  if (!list || !list.length) return;
  const cur = (cosmetics && cosmetics[slot]) ? String(cosmetics[slot]) : list[0];
  const idx = Math.max(0, list.indexOf(cur));
  cosmetics[slot] = list[(idx + 1) % list.length];
  __renderCustomizeUI();
}

function openCustomizePanel(){
  if (!isInHub || !isInHub()) return;
  const panel = document.getElementById('customize-panel');
  if (!panel) return;
  document.body.classList.add('ui-open');
  try { if (typeof window.setPaused === 'function') window.setPaused(true); } catch(_) {}
  panel.style.display = 'flex';
  panel.setAttribute('aria-hidden','false');
    try { loadCosmeticPresets(); } catch(e) {}
  __syncPresetInputs();
  __renderCustomizeUI();
}

function closeCustomizePanel(){
  const panel = document.getElementById('customize-panel');
  if (!panel) return;
  panel.style.display = 'none';
  panel.setAttribute('aria-hidden','true');
  document.body.classList.remove('ui-open');
  try { if (typeof window.setPaused === 'function') window.setPaused(false); } catch(_) {}
}

window.addEventListener('load', () => {
  const btn = document.getElementById('customize-btn');
  const close = document.getElementById('customize-close');
  const save = document.getElementById('customize-save');
  if (btn) btn.addEventListener('click', (e)=>{ e.preventDefault(); openCustomizePanel(); });
  if (close) close.addEventListener('click', (e)=>{ e.preventDefault(); closeCustomizePanel(); });
  if (save) save.addEventListener('click', (e)=>{ e.preventDefault(); saveCosmetics(); closeCustomizePanel(); });

  // presets
  __syncPresetInputs();
  document.querySelectorAll('[data-preset-save]').forEach(b=>{
    b.addEventListener('click', (e)=>{
      e.preventDefault();
      const slot = b.getAttribute('data-preset-save');
      savePreset(slot);
      __syncPresetInputs();
    });
  });
  document.querySelectorAll('[data-preset-load]').forEach(b=>{
    b.addEventListener('click', (e)=>{
      e.preventDefault();
      const slot = b.getAttribute('data-preset-load');
      loadPreset(slot);
    });
  });
  // keep preset names saved on blur
  for (let i=0;i<3;i++){
    const inp = document.getElementById(`preset-name-${i}`);
    if (inp){
      inp.addEventListener('blur', ()=>{
        const name = (inp.value || '').trim().slice(0,18) || cosmeticPresets[i]?.name || `Preset ${i+1}`;
        cosmeticPresets[i] = { ...(cosmeticPresets[i]||{}), name };
        saveCosmeticPresets();
      });
    }
  }


  // slot cycle buttons
  document.querySelectorAll('.slot-action').forEach(b => {
    b.addEventListener('click', (e)=>{
      e.preventDefault();
      const slot = b.getAttribute('data-slot-action');
      __cycleCos(slot);
    });
  });

  // ESC closes
  window.addEventListener('keydown', (e)=>{
    if ((e.key||'').toLowerCase() === 'escape') {
      const panel = document.getElementById('customize-panel');
      if (panel && panel.style.display === 'flex') {
        e.preventDefault();
        closeCustomizePanel();
      }
    }
  });
});


function saveFarmUpgrades() {
  try { localStorage.setItem("arcUpgrades", JSON.stringify(farmUpgrades)); } catch {}
}

const HUB_UPGRADE_BASE_COST = 100; // lifetime ARC (scales per level, capped)
const HUB_UPGRADE_MAX = { dmg: 25, hp: 30, speed: 20 }; // finite caps (no infinite grind)

function hubUpgradeCost(kind) {
  const lvl = Math.max(0, farmUpgrades[kind] || 0);
  const base = HUB_UPGRADE_BASE_COST;
  // escalating cost curve, but still affordable
  const scale = 1 + lvl * 0.35;
  return Math.round(base * scale);
}

function hubUpgradeProgress(kind) {
  const lvl = Math.max(0, farmUpgrades[kind] || 0);
  const max = HUB_UPGRADE_MAX[kind] || 0;
  return { lvl, max, done: max > 0 && lvl >= max };
}

function hubUpgradeLabel(kind) {
  const prog = hubUpgradeProgress(kind);
  const suffix = (prog && prog.max) ? (" [" + prog.lvl + "/" + prog.max + "]") : "";
  if (kind === "dmg") return "DAMAGE +1" + suffix;
  if (kind === "hp") return "MAX HP +10" + suffix;
  if (kind === "speed") return "MOVE SPEED +0.2" + suffix;
  return kind.toUpperCase() + suffix;
}

function hubUpgradeApplyPreview() {
  // no-op; kept for future UI extensions
}

function hubSpend(kind) {
  if (typeof totalArc !== "number") totalArc = 0;

  const prog = hubUpgradeProgress(kind);
  if (prog.done) {
    toastCenter("MAXED: " + hubUpgradeLabel(kind));
    return;
  }

  const cost = hubUpgradeCost(kind);
  if (totalArc < cost) {
    toastCenter("NOT ENOUGH LIFETIME ARC");
    return;
  }

  spendLifetimeArc(cost);
  farmUpgrades[kind] = (farmUpgrades[kind] || 0) + 1;
  saveFarmUpgrades();

  // update HUD safely (points is per-run; totalArc is lifetime)
  try { updatePostIntroStats && updatePostIntroStats(); } catch {}
  toastCenter("UPGRADED: " + hubUpgradeLabel(kind) + "  (" + (farmUpgrades[kind] || 0) + "/" + (HUB_UPGRADE_MAX[kind] || "?") + ")");
}

function resetCombatArraysForHub() {
  bullets = [];
  enemyBullets = [];
  enemies = [];
  powerups = [];
  particles = [];
  arcOrbs = [];
  damagePopups = [];
  // IMPORTANT: FarmHub is a safe zone. Ensure the run "wave" state is fully reset
  // so hub-only entities (NPCs/animals) don't get hidden and wave banners don't appear.
  try { wave = 0; } catch (_) {}
  inRift = false;
  hidePortalHint();
}

// Hub "rift gate" (kept well inside the visible area so the fixed right-side UI doesn't hide it)
const HUB_DOOR = {
  // Portal placed in the grey courtyard area (farm hub bottom zone)
  x: 820,
  y: 1460,
  w: 120,
  h: 120
};

// Upgrade terminals moved away from the totem so the statue reads clearly on first load.
// Also slightly smaller so the hub feels tighter.
const HUB_TERMINALS = [
  { kind: "dmg",   x: SOLANA_TOTEM_X - 160, y: SOLANA_TOTEM_Y + 74, w: 54, h: 54 },
  { kind: "hp",    x: SOLANA_TOTEM_X -  92, y: SOLANA_TOTEM_Y + 74, w: 54, h: 54 },
  { kind: "speed", x: SOLANA_TOTEM_X -  24, y: SOLANA_TOTEM_Y + 74, w: 54, h: 54 },
];

// Armory / loadout station placed right next to the Realm Door (portal)
// Lets you change character skin + weapon from inside the FarmHub.
const HUB_ARMORY = {
  x: HUB_DOOR.x + HUB_DOOR.w + 22,
  y: HUB_DOOR.y + 18,
  w: 110,
  h: 74
};

// Sprite altar floats above the armory — character selection lives up here.
const HUB_SPRITES = {
  x: HUB_ARMORY.x,
  y: HUB_ARMORY.y - 92,
  w: HUB_ARMORY.w,
  h: 58
};
// --- Farm Hub Tilemap (Cute_Fantasy_Free) ---
// We keep this ONLY for the farmHub state. It does not affect combat maps.
const HUB_TILE = 32; // draw size in-world (pixels)
// Premium FarmHub tileset + props (32x32 tiles)
const HUB_TILESET = (() => { const i = new Image(); i.src = "assets/hub_tiles/hub_tileset.png"; return i; })();
const HUB_PROPS   = (() => { const i = new Image(); i.src = "assets/hub_tiles/hub_props.png"; return i; })();

// Tileset indices (each is a 32x32 frame in hub_tileset.png laid out horizontally)
const HUB_TILE_IDX = {
  grassA: 0,
  grassB: 1,
  grassC: 2,
  stonePath: 3,
  dirt: 4,
  plaza: 5,
  water: 6,
  wood: 7,
};

function hubGrassVariant(c, r) {
  // stable pseudo-random per tile
  const h = (c * 73856093) ^ (r * 19349663);
  const v = Math.abs(h) % 3;
  return v === 0 ? HUB_TILE_IDX.grassA : (v === 1 ? HUB_TILE_IDX.grassB : HUB_TILE_IDX.grassC);
}

function drawHubTileFrame(tileIndex, dx, dy) {
  if (!HUB_TILESET || !HUB_TILESET.complete || HUB_TILESET.naturalWidth === 0) return;
  const sx = tileIndex * 32;
  ctx.drawImage(HUB_TILESET, sx, 0, 32, 32, dx, dy, HUB_TILE, HUB_TILE);
}


// Hub map dimensions in tiles
// Hub map dimensions in tiles (smaller = tighter, more "hub" and less "open field")
const HUB_W = 30;
const HUB_H = 22;

// World-space origin (top-left) of hub map
const HUB_ORIGIN = {
  x: SOLANA_TOTEM_X - Math.floor(HUB_W/2) * HUB_TILE,
  y: SOLANA_TOTEM_Y - Math.floor(HUB_H/2) * HUB_TILE
};

// 0=grass, 1=path, 2=water
let hubMap = null;

function buildHubMap() {
  // Build once; deterministic layout (compact hub).
  hubMap = Array.from({ length: HUB_H }, () => Array.from({ length: HUB_W }, () => 0));

  const midC = Math.floor(HUB_W / 2);
  const midR = Math.floor(HUB_H / 2);

  // Main vertical path (spawn -> plaza)
  const pathCol = midC;
  for (let r = HUB_H - 2; r >= 4; r--) hubMap[r][pathCol] = 1;

  // Plaza: a cozy 11x9 area around the totem, with a small ring path
  const plazaR0 = midR - 5;
  const plazaC0 = midC - 6;
  for (let r = plazaR0; r < plazaR0 + 10; r++) {
    for (let c = plazaC0; c < plazaC0 + 12; c++) {
      if (r < 0 || r >= HUB_H || c < 0 || c >= HUB_W) continue;
      hubMap[r][c] = 3; // plaza cobble base
      const edge = (r === plazaR0 || r === plazaR0 + 9 || c === plazaC0 || c === plazaC0 + 11);
      if (edge) hubMap[r][c] = 1;
    }
  }

  // Side paths from plaza to terminals and the portal gate
  for (let c = midC - 12; c <= midC + 12; c++) {
    if (c >= 0 && c < HUB_W) hubMap[midR][c] = 1;
  }

  // Small pond (top-left) with a tiny shoreline
  const pondR0 = 5, pondC0 = 6;
  for (let r = pondR0; r < pondR0 + 5; r++) {
    for (let c = pondC0; c < pondC0 + 7; c++) {
      if (r >= 0 && r < HUB_H && c >= 0 && c < HUB_W) hubMap[r][c] = 2;
    }
  }
  // Shoreline path around pond
  for (let r = pondR0 - 1; r <= pondR0 + 5; r++) {
    for (let c = pondC0 - 1; c <= pondC0 + 7; c++) {
      if (r < 0 || r >= HUB_H || c < 0 || c >= HUB_W) continue;
      if (hubMap[r][c] === 0) {
        // only some shoreline tiles so it feels organic
        if ((r + c) % 2 === 0) hubMap[r][c] = 1;
      }
    }
  }

  // Little crop plots (right side) to make it feel like a farm hub
  const plots = [
    { r0: midR + 1, c0: midC + 5, h: 4, w: 6 },
    { r0: midR - 4, c0: midC + 5, h: 4, w: 6 },
  ];
  plots.forEach(p => {
    for (let r = p.r0; r < p.r0 + p.h; r++) {
      for (let c = p.c0; c < p.c0 + p.w; c++) {
        if (r < 0 || r >= HUB_H || c < 0 || c >= HUB_W) continue;
        // tilled dirt base, with alternating stone rows for that 'farmed' look
        hubMap[r][c] = 4;
        if ((c - p.c0) % 2 === 0) hubMap[r][c] = 1;
      }
    }
  });


  // Wooden deck in front of the portal gate (gives a premium entrance vibe)
  const doorCol = Math.round((HUB_DOOR.x - HUB_ORIGIN.x) / HUB_TILE);
  const doorRow = Math.round((HUB_DOOR.y - HUB_ORIGIN.y) / HUB_TILE);
  for (let r = doorRow - 1; r <= doorRow + 1; r++) {
    for (let c = doorCol - 2; c <= doorCol + 2; c++) {
      if (r >= 0 && r < HUB_H && c >= 0 && c < HUB_W) {
        if (hubMap[r][c] === 0) hubMap[r][c] = 5;
      }
    }
  }

  // Armory wood platform next to the portal (loadout station area)
  for (let r = doorRow - 1; r <= doorRow + 2; r++) {
    for (let c = doorCol + 3; c <= doorCol + 7; c++) {
      if (r >= 0 && r < HUB_H && c >= 0 && c < HUB_W) {
        hubMap[r][c] = 5;
      }
    }
  }
  // Small stone lip so it reads as a "room" / alcove
  for (let r = doorRow - 2; r <= doorRow + 3; r++) {
    for (let c = doorCol + 2; c <= doorCol + 8; c++) {
      if (r >= 0 && r < HUB_H && c >= 0 && c < HUB_W) {
        const edge = (r === doorRow - 2 || r === doorRow + 3 || c === doorCol + 2 || c === doorCol + 8);
        if (edge) hubMap[r][c] = 1;
      }
    }
  }


}

function hubTileAt(col, row) {
  if (!hubMap) buildHubMap();
  if (row < 0 || row >= HUB_H || col < 0 || col >= HUB_W) return 0;
  return hubMap[row][col] || 0;
}

function drawFarmHubPortalGuidance() {
  if (gameState !== 'farmHub') return;
  if (!player) return;
  const cx = FARMHUB_PORTAL_X;
  const cy = FARMHUB_PORTAL_Y;

  // Dotted line (player -> portal)
  const dx = cx - player.x;
  const dy = cy - player.y;
  const dist = Math.hypot(dx, dy);
  if (dist > 40) {
    const t = performance.now() / 1000;
    const pulse = 0.55 + 0.25 * Math.sin(t * 2.2);
    ctx.save();
    ctx.globalAlpha = pulse;
    ctx.strokeStyle = 'rgba(168,85,247,0.95)';
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 8]);
    // Animate dashes so it feels like it "flows" toward the portal
    ctx.lineDashOffset = -t * 18;
    ctx.beginPath();
    ctx.moveTo(Math.round(player.x - camera.x), Math.round(player.y - camera.y));
    ctx.lineTo(Math.round(cx - camera.x), Math.round(cy - camera.y));
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
  }

  // Big pulsing arrow above the portal (in-world)
  {
    const t = performance.now() / 1000;
    const bob = Math.sin(t * 3.0) * 6;
    const a = 0.75 + 0.2 * Math.sin(t * 2.0);
    const px = Math.round(cx - camera.x);
    const py = Math.round(cy - camera.y - 84 + bob);
    ctx.save();
    ctx.globalAlpha = a;
    ctx.fillStyle = 'rgba(34,211,238,0.95)';
    ctx.strokeStyle = 'rgba(2,6,23,0.95)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(px - 16, py + 22);
    ctx.lineTo(px + 16, py + 22);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.restore();
  }
}

function drawFarmHubGround() {
  if (gameState !== "farmHub") return;

  // Preferred: render the authored FarmHub map image (farmhub.png) aligned to world coords.
  const farmhubReady =
    (typeof FARMHUB_IMG !== "undefined") &&
    FARMHUB_IMG &&
    FARMHUB_IMG.complete &&
    FARMHUB_IMG.naturalWidth > 0;
  if (farmhubReady) {
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(FARMHUB_IMG, Math.round(-camera.x), Math.round(-camera.y));

    
// Animated rift portal in the center of the FarmHub
// We render from a decoded sprite-sheet (portal_sheet.png) for consistent animation across browsers.
if (FARMHUB_PORTAL_SHEET && FARMHUB_PORTAL_SHEET.complete && FARMHUB_PORTAL_SHEET.naturalWidth > 0) {
  const cx = FARMHUB_PORTAL_X;
  const cy = FARMHUB_PORTAL_Y;
  const px = Math.round(cx - camera.x);
  const py = Math.round(cy - camera.y);
  const size = 110; // cute + not huge

  const fw = Math.floor(FARMHUB_PORTAL_SHEET.naturalWidth / FARMHUB_PORTAL_FRAMES);
  const fh = FARMHUB_PORTAL_SHEET.naturalHeight;
  const t = performance.now();
  const frame = Math.floor((t / 1000) * FARMHUB_PORTAL_FPS) % FARMHUB_PORTAL_FRAMES;

  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(
    FARMHUB_PORTAL_SHEET,
    frame * fw, 0, fw, fh,
    px - size / 2, py - size / 2, size, size
  );
} else if (FARMHUB_PORTAL_GIF && FARMHUB_PORTAL_GIF.complete && FARMHUB_PORTAL_GIF.naturalWidth > 0) {
  // Fallback: draw GIF first-frame if sheet isn't ready.
  const cx = FARMHUB_PORTAL_X;
  const cy = FARMHUB_PORTAL_Y;
  const px = Math.round(cx - camera.x);
  const py = Math.round(cy - camera.y);
  const size = 110;
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(FARMHUB_PORTAL_GIF, px - size / 2, py - size / 2, size, size);
}

// Portal guidance: a subtle dotted line from player -> portal + a pulsing arrow above the portal.
try { drawFarmHubPortalGuidance(); } catch(_) {}

    ctx.restore();
    return;
  }

  if (!hubMap) buildHubMap();

  const startCol = Math.floor((camera.x - HUB_ORIGIN.x) / HUB_TILE) - 1;
  const startRow = Math.floor((camera.y - HUB_ORIGIN.y) / HUB_TILE) - 1;
  const endCol = Math.ceil((camera.x + canvas.width - HUB_ORIGIN.x) / HUB_TILE) + 1;
  const endRow = Math.ceil((camera.y + canvas.height - HUB_ORIGIN.y) / HUB_TILE) + 1;

  for (let r = startRow; r <= endRow; r++) {
    for (let c = startCol; c <= endCol; c++) {
      const t = hubTileAt(c, r);
      // 0=grass, 1=stone path, 2=water, 3=plaza, 4=dirt, 5=wood
      let tileIndex = HUB_TILE_IDX.grassA;
      if (t === 1) tileIndex = HUB_TILE_IDX.stonePath;
      else if (t === 2) tileIndex = HUB_TILE_IDX.water;
      else if (t === 3) tileIndex = HUB_TILE_IDX.plaza;
      else if (t === 4) tileIndex = HUB_TILE_IDX.dirt;
      else if (t === 5) tileIndex = HUB_TILE_IDX.wood;
      else tileIndex = hubGrassVariant(c, r);


      const wx = HUB_ORIGIN.x + c * HUB_TILE;
      const wy = HUB_ORIGIN.y + r * HUB_TILE;

      const sx = wx - camera.x;
      const sy = wy - camera.y;
      // Draw tile from premium tileset
      drawHubTileFrame(tileIndex, sx, sy);
    }
  }
}


function distToRect(px, py, rect) {
  const cx = Math.max(rect.x, Math.min(px, rect.x + rect.w));
  const cy = Math.max(rect.y, Math.min(py, rect.y + rect.h));
  const dx = px - cx;
  const dy = py - cy;
  return Math.hypot(dx, dy);
}

// Small helper used in a few systems (enemy spawns, pickups, etc.)
// This existed implicitly in earlier revisions; keep it explicit so refactors don't break.
function distance(x1, y1, x2, y2) {
  return Math.hypot(x1 - x2, y1 - y2);
}

function chromaKeyToCanvas(img, opts = {}) {
  // Convert a non-transparent spritesheet (often screenshots) into a transparent canvas by removing
  // the background color sampled from the top-left pixel.
  const w = img.naturalWidth || img.width || 0;
  const h = img.naturalHeight || img.height || 0;
  if (!w || !h) return null;

  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const g = c.getContext("2d", { willReadFrequently: true });
  g.imageSmoothingEnabled = false;
  g.drawImage(img, 0, 0);

  const d = g.getImageData(0, 0, w, h);
  const data = d.data;

  // Sample background from a few pixels in the corner (more robust than a single pixel).
  const sample = (sx, sy) => {
    const i = (sy * w + sx) * 4;
    return [data[i], data[i + 1], data[i + 2]];
  };
  const s0 = sample(0, 0);
  const s1 = sample(Math.min(2, w - 1), 0);
  const s2 = sample(0, Math.min(2, h - 1));
  const bg = [
    Math.round((s0[0] + s1[0] + s2[0]) / 3),
    Math.round((s0[1] + s1[1] + s2[1]) / 3),
    Math.round((s0[2] + s1[2] + s2[2]) / 3),
  ];

  const thr = opts.threshold ?? 55; // distance threshold
  const thr2 = thr * thr;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g2 = data[i + 1], b = data[i + 2], a = data[i + 3];
    if (a === 0) continue;

    const dr = r - bg[0];
    const dg = g2 - bg[1];
    const db = b - bg[2];
    const dist2 = dr * dr + dg * dg + db * db;

    // Only key out pixels very close to the sampled background.
    if (dist2 <= thr2) {
      data[i + 3] = 0;
    }
  }

  g.putImageData(d, 0, 0);
  return c;
}


// Dash shockwave: during dash, bump + damage nearby enemies once per dash.
// Balanced: small damage + small ARC trickle, feels amazing.
function updateDashShockwave(now) {
  if (!dashEndTime || now > dashEndTime) return;
  const r = 44;
  for (const e of enemies) {
    if (!e || e.isBoss) continue;
    if (e.__dashHitId === dashId) continue;
    const d = distance(player.x, player.y, e.x, e.y);
    if (d <= r) {
      e.__dashHitId = dashId;
      e.hp -= 8 + Math.min(6, Math.floor(wave / 3));
        const __tHit = performance.now();
        e.__hitFlashUntil = __tHit + 80;
        e.__hpBarFlashUntil = __tHit + 140;
        // tiny knock
      const ang = Math.atan2(e.y - player.y, e.x - player.x);
      e.vx = (e.vx || 0) + Math.cos(ang) * 0.9;
      e.vy = (e.vy || 0) + Math.sin(ang) * 0.9;

      // micro ARC drip (not a weapon, just dopamine)
      const drip = 6;
      points += drip;
      addLifetimeArc(drip);
      spawnArcPopup(drip, e.x, e.y - 10);

      // vfx pop
      particles.push({ x: e.x, y: e.y, vx: 0, vy: -0.2, life: 18, color: "rgba(250,204,21,0.95)" });
      if (Math.random() < 0.25) slowMoTime = Math.max(slowMoTime, 0.02);
    }
  }
}

function showHubHint(msg) {
  if (!portalHint) return;
  portalHint.textContent = msg;
  portalHint.style.opacity = "1";
  portalHint.style.transform = "translate(-50%, 0) scale(1)";
}

function enterFarmHub() {
  gameState = "farmHub";
  // Cancel any pending combat spawn forcing.
  __forceCombatSpawnFrames = 0;
  // Make sure we're truly out of combat when we enter the hub.
  // Some UI systems key off `wave`, so keep it at 0 in the hub.
  try { wave = 0; } catch (_) {}
  // Hub uses the larger sandbox world.
  setWorldBounds(FARMHUB_MAP_W, FARMHUB_MAP_H, FARMHUB_MAP_W);
  setMusicMood("farmhub"); // dedicated hub song
  try { setBiomeVibe && setBiomeVibe("farmhub"); } catch(e) {}
  resetCombatArraysForHub();
  // Spawn the player dead-center in the hub so both player + camera are centered
  // immediately (avoids the common "top-left" clamp issue on load / returns).
  player.x = (FARMHUB_MAP_W / 2);
  player.y = (FARMHUB_MAP_H / 2);

  // Snap camera to the player immediately.
  try { centerCameraOnPlayer(true); } catch(_) {
    const __z = (typeof ARC_CAMERA_ZOOM === 'number' && isFinite(ARC_CAMERA_ZOOM)) ? ARC_CAMERA_ZOOM : 1;
    const __vw = canvas.width / __z;
    const __vh = canvas.height / __z;
    camera.x = Math.round(player.x - __vw / 2);
    camera.y = Math.round(player.y - __vh / 2);
  }
  toastCenter("FARM HUB: SPEND LIFETIME ARC • ENTER THE PURPLE PORTAL [E]");
  const rp = document.getElementById("enter-realm-prompt");
  if (rp) rp.style.display = "none";

  // Ensure hub NPCs re-appear after returning from a run/death.
  try { ensureHubNpcDom(); } catch(_) {}
  try { showHubNpcDom(); } catch(_) {}
}

// ---- CAMERA + SPAWN HELPERS ----
function __getZoomViewport() {
  const __z = (typeof ARC_CAMERA_ZOOM === 'number' && isFinite(ARC_CAMERA_ZOOM)) ? ARC_CAMERA_ZOOM : 1;
  const __vw = (canvas && canvas.width ? canvas.width : 1) / __z;
  const __vh = (canvas && canvas.height ? canvas.height : 1) / __z;
  return { z: __z, vw: __vw, vh: __vh };
}

function centerCameraOnPlayer(immediate = true) {
  if (!camera || !player) return;
  const { vw, vh } = __getZoomViewport();
  const tx = player.x - vw / 2;
  const ty = player.y - vh / 2;
  // Snap to pixels to avoid the "black band" feel from subpixel rounding.

  // If the world is smaller than the visible viewport (common with close-up zoom
  // + some of your PNG maps), a normal 0..(WORLD-vw) clamp collapses to 0 and the
  // camera looks "stuck" (player never centers). In that case we allow negative
  // camera values so the world can be centered on-screen.
  let cx = Math.round(tx);
  let cy = Math.round(ty);

  if (isFinite(WORLD_WIDTH) && WORLD_WIDTH > 0 && isFinite(vw) && vw > 0) {
    if (WORLD_WIDTH <= vw) {
      cx = Math.round((WORLD_WIDTH - vw) / 2);
    } else {
      cx = Math.max(0, Math.min(WORLD_WIDTH - vw, cx));
    }
  }
  if (isFinite(WORLD_HEIGHT) && WORLD_HEIGHT > 0 && isFinite(vh) && vh > 0) {
    if (WORLD_HEIGHT <= vh) {
      cy = Math.round((WORLD_HEIGHT - vh) / 2);
    } else {
      cy = Math.max(0, Math.min(WORLD_HEIGHT - vh, cy));
    }
  }

  camera.x = cx;
  camera.y = cy;
}

function placePlayerAtCombatSpawn() {
  // When transitioning from FarmHub -> Waves, resetPlayer() does not set position.
  // So we explicitly place the player at a consistent combat spawn.
  // (Center of the active combat map works well across your zone PNGs/tilesets.)
  try {
    player.x = WORLD_WIDTH / 2;
    player.y = WORLD_HEIGHT / 2;
  } catch(_) {}
}

function startRunFromHub() {
  const rp = document.getElementById('enter-realm-prompt');
  if (rp) rp.style.display = 'none';
  // Combat waves use the exact map PNG size (no side bands).
  setWorldBounds(LEVEL0_MAP_W, LEVEL0_MAP_H, LEVEL0_MAP_W);

  // start clean
  resetCombatArraysForHub();
  // reset core run stats
  points = 0;
  kills = 0;
  level = 1;
  xp = 0;

  // Reset player to base then apply upgrades
  resetPlayer();

  const dmgLv   = Math.min(farmUpgrades.dmg || 0, HUB_UPGRADE_MAX.dmg || 999);
  const hpLv    = Math.min(farmUpgrades.hp || 0, HUB_UPGRADE_MAX.hp || 999);
  const speedLv = Math.min(farmUpgrades.speed || 0, HUB_UPGRADE_MAX.speed || 999);

  player.damage += dmgLv;
  player.maxHp += hpLv * 10;
  player.hp = Math.min(player.hp, player.maxHp);
  player.speed += speedLv * 0.2;

  // start waves
  // (Run Goal) initialize run tracking when entering waves
  runStartTime = performance.now();
  wavesCleared = 0;
  networkEventsCleared = 0;
  perfectDashCount = 0;
  bestArcStreak = 0;
  pickRunGoal();
  // Force a correct combat spawn/camera for the first few frames.
  // Entering waves from the hub is the most common place where stale coords
  // leave the player/camera parked at an old location.
  __forceCombatSpawnFrames = 8;

  startWave(1);
  // IMPORTANT: startWave(1) can change mapMode/world bounds. Spawn AFTER it so
  // we always land in the correct world and the camera centers correctly.
  placePlayerAtCombatSpawn();
  centerCameraOnPlayer(true);
  startItsRainingArc();
  setMusicMood("cave");
  initAudio();
  gameState = "playing";
  renderRunGoalHUD();
  toastCenter("ENTERED THE REALM WAVES");
}

// Hub key interactions
window.addEventListener("keydown", (e) => {
  const k = e.key.toLowerCase();
  if (gameState !== "farmHub") return;

  // interact: Purple Portal (start run), Weapon Armory, Sprite Altar, or upgrade terminals
  if (k === "e") {
    // 0) Shops/Stations (BLACKSMITH / SHOP / UPGRADES) — highest priority so it feels instant.
    try {
      const near = (typeof hubFindNearestInteract === 'function') ? hubFindNearestInteract() : null;
      if (near && typeof near.onEnter === 'function') {
        e.preventDefault();
        near.onEnter();
        return;
      }
    } catch(_) {}

    // 0) Purple portal in the center starts the run
    const cx = FARMHUB_PORTAL_X;
    const cy = FARMHUB_PORTAL_Y;
    if (Math.hypot(player.x - cx, player.y - cy) < 90) {
      startRunFromHub();
      return;
    }
    // 1) Sprite altar (character selection)
    const dSpr = distToRect(player.x, player.y, HUB_SPRITES);
    if (dSpr < 58) {
      // NEW: No selection screen. Walk up and TAKE / cycle your sprite.
      try { hubTakeNextSprite(); } catch(e) {}
      return;
    }

    // 2) Armory (weapon-only)
    const dArm = distToRect(player.x, player.y, HUB_ARMORY);
    if (dArm < 52) {
      // NEW: No selection screen. Walk up and TAKE / cycle your weapon.
      try { hubTakeNextWeapon(); } catch(e) {}
      return;
    }

    // 3) otherwise: nearest upgrade terminal
    let best = null;
    let bestD = 1e9;
    for (const t of HUB_TERMINALS) {
      const d = distToRect(player.x, player.y, t);
      if (d < bestD) { bestD = d; best = t; }
    }
    if (best && bestD < 44) {
      hubSpend(best.kind);
    } else {
      toastCenter("MOVE CLOSER TO A TERMINAL, ARMORY, OR SPRITES");
    }
  }
  // Yellow door portal removed; use the purple center portal (press E) to start.
});

// =============================================================
// HUB "TAKE" INTERACTIONS (no selection screens)
// - Press E near SPRITES: cycles to next available sprite
// - Press E near WEAPONS: cycles to next available weapon
// =============================================================
function hubTakeNextSprite() {
  try {
    const list = (typeof CHARACTER_CONFIGS !== "undefined" && Array.isArray(CHARACTER_CONFIGS)) ? CHARACTER_CONFIGS : [];
    if (!list.length) { if (typeof toastCenter === "function") toastCenter("NO SPRITES"); return; }

    const curId =
      (typeof selectedCharacterId === "string" && selectedCharacterId)
        ? selectedCharacterId
        : (localStorage.getItem("arc_selected_character") || "");

    let idx = list.findIndex(c => c && c.id === curId);
    if (idx < 0) idx = 0;
    idx = (idx + 1) % list.length;

    selectedCharacterId = list[idx].id;

    // Apply immediately (previously only persisted to storage, so you had to reload).
    try {
      const cfg = list[idx];
      if (cfg && cfg.idleSrc && cfg.walkSrc) {
        playerIdleImg.src = cfg.idleSrc;
        playerWalkImg.src = cfg.walkSrc;
      }
      // Keep the boot sync in one place (also updates both storage keys).
      if (typeof window.__syncSelectedCharacterSprites === 'function') {
        window.__syncSelectedCharacterSprites();
      }
    } catch(_) {}

    // persist using your existing saver if available
    try { if (typeof saveSelectedLoadout === "function") saveSelectedLoadout(); } catch(_) {}
    try { localStorage.setItem("arc_selected_character", selectedCharacterId); } catch(_) {}

    if (typeof toastCenter === "function") toastCenter("SPRITE TAKEN: " + (list[idx].name || list[idx].id));
  } catch (e) {
    console.warn("hubTakeNextSprite failed", e);
  }
}

function hubTakeNextWeapon() {
  try {
    // Prefer the same list used by the armory visuals (if present)
    const cards =
      (typeof HUB_ARMORY_WEAPON_CARDS !== "undefined" && Array.isArray(HUB_ARMORY_WEAPON_CARDS) && HUB_ARMORY_WEAPON_CARDS.length)
        ? HUB_ARMORY_WEAPON_CARDS
        : [];

    let weaponIds = [];
    if (cards.length) {
      weaponIds = cards.map(x => x && x.cfg && x.cfg.weaponId).filter(Boolean);
    } else if (typeof WEAPON_CONFIGS !== "undefined" && Array.isArray(WEAPON_CONFIGS)) {
      weaponIds = WEAPON_CONFIGS.map(w => w && (w.weaponId || w.id)).filter(Boolean);
    }

    weaponIds = Array.from(new Set(weaponIds));
    if (!weaponIds.length) { if (typeof toastCenter === "function") toastCenter("NO WEAPONS"); return; }

    const cur =
      (typeof selectedWeaponId === "string" && selectedWeaponId)
        ? selectedWeaponId
        : (localStorage.getItem("arc_selected_weapon") || "");

    let idx = weaponIds.indexOf(cur);
    if (idx < 0) idx = 0;
    idx = (idx + 1) % weaponIds.length;

    selectedWeaponId = weaponIds[idx];

    // Apply to player immediately (so hub reflects what you took)
    try { if (typeof player === "object" && player) player.weapon = getWeaponTemplateById(selectedWeaponId); } catch(_) {}

    // Update gun sprite image if we can resolve it
    try {
      const card = cards.find(c => c && c.cfg && c.cfg.weaponId === selectedWeaponId);
      if (card && card.cfg && card.cfg.spriteSrc && typeof gunSpriteImg !== "undefined") {
        gunSpriteImg.src = card.cfg.spriteSrc;
      }
    } catch(_) {}

    try { if (typeof saveSelectedLoadout === "function") saveSelectedLoadout(); } catch(_) {}
    try { localStorage.setItem("arc_selected_weapon", selectedWeaponId); } catch(_) {}

    if (typeof toastCenter === "function") toastCenter("WEAPON TAKEN: " + String(selectedWeaponId).toUpperCase());
  } catch (e) {
    console.warn("hubTakeNextWeapon failed", e);
  }
}

function updateFarmHubHints() {
  if (gameState !== "farmHub") return;

  // sprite altar hint
  const dSpr = distToRect(player.x, player.y, HUB_SPRITES);
  if (dSpr < 78) {
    showHubHint("SPRITES — press E");
    return;
  }

  // armory hint (weapon station)
  const dArm = distToRect(player.x, player.y, HUB_ARMORY);
  if (dArm < 70) {
    showHubHint("WEAPONS — press E");
    return;
  }

  // portal hint (center purple portal)
  {
    const cx = FARMHUB_PORTAL_X;
    const cy = FARMHUB_PORTAL_Y;
    const dPortal = Math.hypot(player.x - cx, player.y - cy);
    if (dPortal < 90) {
      showHubHint("ENTER PORTAL — press E");
      return;
    }
  }

  // terminal hint
  let nearest = null, bestD = 1e9;
  for (const t of HUB_TERMINALS) {
    const d = distToRect(player.x, player.y, t);
    if (d < bestD) { bestD = d; nearest = t; }
  }
  if (nearest && bestD < 62) {
    showHubHint(hubUpgradeLabel(nearest.kind) + " — press E (Cost " + hubUpgradeCost(nearest.kind) + " ARC)");
    return;
  }

  hidePortalHint();
}



// --- FarmHub makeover (decor, compact layout, real portal) ---
let hubDecor = null;

function buildHubDecor() {
  if (hubDecor) return;
  hubDecor = [];

  // Lanterns along the main path
  for (let i = 0; i < 7; i++) {
    const y = HUB_ORIGIN.y + (HUB_H - 4 - i * 4) * HUB_TILE + 10;
    hubDecor.push({ t: "lantern", x: HUB_ORIGIN.x + Math.floor(HUB_W/2) * HUB_TILE - 42, y });
    hubDecor.push({ t: "lantern", x: HUB_ORIGIN.x + Math.floor(HUB_W/2) * HUB_TILE + 42, y: y + 6 });
  }

  // Pond extras
  hubDecor.push({ t: "reeds", x: HUB_ORIGIN.x + 7 * HUB_TILE, y: HUB_ORIGIN.y + 6 * HUB_TILE });
  hubDecor.push({ t: "reeds", x: HUB_ORIGIN.x + 10 * HUB_TILE, y: HUB_ORIGIN.y + 8 * HUB_TILE });

  // Cozy plaza items near the totem
  hubDecor.push({ t: "bench", x: SOLANA_TOTEM_X - 40, y: SOLANA_TOTEM_Y + 120 });
  hubDecor.push({ t: "bench", x: SOLANA_TOTEM_X + 25, y: SOLANA_TOTEM_Y + 120 });
  hubDecor.push({ t: "crate", x: SOLANA_TOTEM_X - 110, y: SOLANA_TOTEM_Y - 20 });
  hubDecor.push({ t: "crate", x: SOLANA_TOTEM_X - 115, y: SOLANA_TOTEM_Y + 15 });

  // Crop plot markers (right side) — keep close so the hub feels compact
  hubDecor.push({ t: "scarecrow", x: SOLANA_TOTEM_X + 170, y: SOLANA_TOTEM_Y + 18 });
  hubDecor.push({ t: "hay", x: SOLANA_TOTEM_X + 150, y: SOLANA_TOTEM_Y + 120 });

  // Flowers sprinkled (fewer, slightly larger clusters = less "noise")
  for (let i = 0; i < 10; i++) {
    const rx = HUB_ORIGIN.x + (4 + Math.random() * (HUB_W - 8)) * HUB_TILE;
    const ry = HUB_ORIGIN.y + (4 + Math.random() * (HUB_H - 8)) * HUB_TILE;
    hubDecor.push({ t: "flowers", x: rx, y: ry, s: 0.8 + Math.random() * 0.6 });
  }
}


// ===============================
// ARC PULSE ALTAR (FarmHub vibe)
// ===============================
const ENABLE_ARC_PULSE = false; // user requested: remove the pulse feature
const ARC_PULSE_ALTAR = { x: 1040, y: 560, r: 86 };
let __arcPulseUntil = 0;
let __arcPulseCooldownUntil = 0;

function maybeTriggerArcPulse() {
  if (!ENABLE_ARC_PULSE) return;
  if (gameState !== 'farmHub') return;
  try { if (typeof wave === 'number' && wave >= 1) return; } catch(_) {}
  const now = performance.now();
  if (now < __arcPulseCooldownUntil) return;
  const d = Math.hypot(player.x - ARC_PULSE_ALTAR.x, player.y - ARC_PULSE_ALTAR.y);
  if (d <= ARC_PULSE_ALTAR.r) {
    __arcPulseUntil = now + 1200;
    __arcPulseCooldownUntil = now + 3500;
    try { toastCenter && toastCenter('ARC PULSE'); } catch(_) {}
    try {
      for (let i = 0; i < 32; i++) {
        const a = (Math.PI * 2) * (i / 32) + Math.random()*0.18;
        const sp = 1.4 + Math.random()*2.0;
        particles.push({
          x: ARC_PULSE_ALTAR.x + Math.cos(a)*8,
          y: ARC_PULSE_ALTAR.y + Math.sin(a)*8 - 10,
          vx: Math.cos(a)*sp,
          vy: Math.sin(a)*sp - 0.9,
          life: 26 + Math.random()*10,
          color: (Math.random()<0.5) ? 'rgba(56,189,248,0.95)' : 'rgba(168,85,247,0.95)'
        });
      }
    } catch(_) {}
  }
}

function drawArcPulseAltar() {
  // Feature removed: keep the hub clean (no altar / glow / prompt).
  if (!ENABLE_ARC_PULSE) return;
  if (gameState !== 'farmHub') return;
  const sx = Math.round(ARC_PULSE_ALTAR.x - camera.x);
  const sy = Math.round(ARC_PULSE_ALTAR.y - camera.y);
  const t = performance.now() * 0.001;
  const pulse = 0.72 + 0.28 * Math.sin(t * 2.6);

  ctx.save();
  ctx.imageSmoothingEnabled = false;
  ctx.globalAlpha = 0.55;
  ctx.fillStyle = 'rgba(2,6,23,0.95)';
  ctx.beginPath();
  ctx.ellipse(sx, sy + 18, 26, 9, 0, 0, Math.PI*2);
  ctx.fill();

  ctx.globalAlpha = 1;
  ctx.fillStyle = 'rgba(15,23,42,0.95)';
  ctx.strokeStyle = 'rgba(56,189,248,0.65)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(sx - 18, sy - 18, 36, 28, 6);
  ctx.fill();
  ctx.stroke();

  ctx.globalAlpha = 0.95;
  ctx.fillStyle = 'rgba(168,85,247,0.95)';
  ctx.fillRect(sx - 5, sy - 10, 10, 10);

  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = 0.28 * pulse;
  const g = ctx.createRadialGradient(sx, sy - 4, 4, sx, sy - 4, 64);
  g.addColorStop(0, 'rgba(56,189,248,0.55)');
  g.addColorStop(0.55, 'rgba(168,85,247,0.22)');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(sx, sy - 4, 64, 0, Math.PI*2);
  ctx.fill();

  const d = Math.hypot(player.x - ARC_PULSE_ALTAR.x, player.y - ARC_PULSE_ALTAR.y);
  if (d < ARC_PULSE_ALTAR.r) {
    ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = 0.9;
    ctx.font = "9px 'Press Start 2P', monospace";
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(250,204,21,0.95)';
    ctx.fillText('ARC PULSE', sx, sy - 34);
  }

  ctx.restore();
}

function drawArcPulseOverlay() {
  // Feature removed.
  if (!ENABLE_ARC_PULSE) return;
  const now = performance.now();
  if (now > __arcPulseUntil) return;
  const k = 1 - ((__arcPulseUntil - now) / 1200);
  const a = 0.22 * Math.sin(k * Math.PI);
  if (a <= 0) return;

  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = a;
  const cx = canvas.width/2, cy = canvas.height/2;
  const r = Math.max(canvas.width, canvas.height) * (0.55 + 0.10*k);
  const g = ctx.createRadialGradient(cx, cy, r*0.10, cx, cy, r);
  g.addColorStop(0, 'rgba(56,189,248,0.55)');
  g.addColorStop(0.5, 'rgba(168,85,247,0.22)');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI*2);
  ctx.fill();
  ctx.restore();
}

function drawHubDecor() {
  if (!hubDecor) buildHubDecor();

  const HUB_PROP_FRAME = { crate: 0, hay: 1, lantern: 3, flowers: 4 };
  for (const d of hubDecor) {
    const sx = d.x - camera.x;
    const sy = d.y - camera.y;

    // Prefer sprite props if available (premium look); fallback to procedural drawing below.
    const frame = HUB_PROP_FRAME[d.t];
    if (frame !== undefined && HUB_PROPS && HUB_PROPS.complete && HUB_PROPS.naturalWidth) {
      const s = d.s || 1;
      const sw = 32, sh = 32;
      const dx = sx - (sw/2)*s;
      const dy = sy - sh*s;
      ctx.drawImage(HUB_PROPS, frame*32, 0, 32, 32, dx, dy, sw*s, sh*s);
      continue;
    }
    if (sx < -420 || sy < -420 || sx > canvas.width + 420 || sy > canvas.height + 420) continue;

    ctx.save();
    if (d.t === "lantern") {
      // post
      ctx.globalAlpha = 0.95;
      ctx.fillStyle = "rgba(15,23,42,0.9)";
      ctx.fillRect(sx - 3, sy - 18, 6, 22);
      // lantern body
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = "rgba(2,6,23,0.95)";
      ctx.strokeStyle = "rgba(250,204,21,0.9)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(sx - 8, sy - 30, 16, 16, 4);
      ctx.fill();
      ctx.stroke();
    } else if (d.t === "bench") {
      ctx.globalAlpha = 0.95;
      ctx.fillStyle = "rgba(120,53,15,0.9)";
      ctx.fillRect(sx - 26, sy - 6, 52, 10);
      ctx.fillStyle = "rgba(51,65,85,0.7)";
      ctx.fillRect(sx - 24, sy + 4, 6, 10);
      ctx.fillRect(sx + 18, sy + 4, 6, 10);
    } else if (d.t === "crate") {
      ctx.globalAlpha = 0.95;
      ctx.fillStyle = "rgba(101,67,33,0.95)";
      ctx.strokeStyle = "rgba(250,204,21,0.25)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(sx - 14, sy - 14, 28, 28, 6);
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = "rgba(2,6,23,0.25)";
      ctx.beginPath();
      ctx.moveTo(sx - 12, sy);
      ctx.lineTo(sx + 12, sy);
      ctx.moveTo(sx, sy - 12);
      ctx.lineTo(sx, sy + 12);
      ctx.stroke();
    } else if (d.t === "reeds") {
      ctx.globalAlpha = 0.9;
      ctx.strokeStyle = "rgba(34,197,94,0.8)";
      ctx.lineWidth = 2;
      for (let i = 0; i < 6; i++) {
        ctx.beginPath();
        ctx.moveTo(sx + i * 3, sy + 10);
        ctx.quadraticCurveTo(sx + i * 3 - 5, sy, sx + i * 3 + 1, sy - 14);
        ctx.stroke();
      }
    } else if (d.t === "scarecrow") {
      ctx.globalAlpha = 0.95;
      ctx.strokeStyle = "rgba(71,85,105,0.9)";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(sx, sy - 40);
      ctx.lineTo(sx, sy + 20);
      ctx.stroke();
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(sx - 22, sy - 18);
      ctx.lineTo(sx + 22, sy - 18);
      ctx.stroke();
      ctx.fillStyle = "rgba(250,204,21,0.9)";
      ctx.beginPath();
      ctx.arc(sx, sy - 34, 8, 0, Math.PI * 2);
      ctx.fill();
    } else if (d.t === "hay") {
      ctx.globalAlpha = 0.95;
      ctx.fillStyle = "rgba(234,179,8,0.9)";
      ctx.strokeStyle = "rgba(120,53,15,0.4)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(sx - 18, sy - 12, 36, 24, 10);
      ctx.fill();
      ctx.stroke();
    } else if (d.t === "flowers") {
      ctx.globalAlpha = 0.7;
      const s = d.s || 1;
      ctx.save();
      ctx.translate(sx, sy);
      ctx.scale(s, s);
      for (let i = 0; i < 5; i++) {
        const ax = Math.cos(i * (Math.PI * 2 / 5)) * 8;
        const ay = Math.sin(i * (Math.PI * 2 / 5)) * 8;
        ctx.fillStyle = "rgba(248,113,113,0.65)";
        ctx.beginPath();
        ctx.arc(ax, ay, 4.2, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = "rgba(250,204,21,0.9)";
      ctx.beginPath();
      ctx.arc(0, 0, 3.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
    ctx.restore();
  }

  // ARC Pulse altar (vibe)
  try { drawArcPulseAltar(); } catch(_) {}
}

function drawHubPortal(){ /* disabled */ }

// --- UI helper: draw an image contained within a box (preserves aspect ratio) ---
function drawImageContain(img, dx, dy, dw, dh, pixelated=true) {
  if (!img || !img.complete || img.naturalWidth <= 0 || img.naturalHeight <= 0) return false;
  const iw = img.naturalWidth, ih = img.naturalHeight;
  const s = Math.min(dw / iw, dh / ih);
  const w = Math.max(1, Math.round(iw * s));
  const h = Math.max(1, Math.round(ih * s));
  const x = dx + (dw - w) / 2;
  const y = dy + (dh - h) / 2;
  ctx.imageSmoothingEnabled = !pixelated ? true : false;
  ctx.drawImage(img, x, y, w, h);
  return true;
}

// --- Hub Armory visuals (loadout station) ---
const HUB_ARMORY_ICONS = (() => {
  const icons = {};
  try {
    // Use the same spriteSrc files as the weapon picker where possible.
    (typeof WEAPON_SELECT_CONFIGS !== "undefined" ? WEAPON_SELECT_CONFIGS : []).forEach(w => {
      if (!w || !w.weaponId || !w.spriteSrc) return;
      const img = new Image();
      img.src = w.spriteSrc;
      icons[w.weaponId] = img;
    });
  } catch {}
  // Fallbacks
  const fallbackAK = new Image(); fallbackAK.src = "ak.png";
  const fallbackSword = new Image(); fallbackSword.src = "sword.png";
  if (!icons.ak47) icons.ak47 = fallbackAK;
  if (!icons.rifle) icons.rifle = fallbackAK;
  if (!icons.sniper) icons.sniper = fallbackAK;
  if (!icons.shotgun) icons.shotgun = fallbackSword;
  if (!icons.pistol) icons.pistol = fallbackAK;
  if (!icons.smg) icons.smg = fallbackAK;
  return icons;
})();

// Preload weapon card images (AK + other selectable weapons)
const HUB_ARMORY_WEAPON_CARDS = (() => {
  const arr = [];
  try {
    (typeof WEAPON_SELECT_CONFIGS !== "undefined" ? WEAPON_SELECT_CONFIGS : []).forEach(cfg => {
      if (!cfg || !cfg.spriteSrc) return;
      const img = new Image();
      img.src = cfg.spriteSrc;
      arr.push({ cfg, img });
    });
  } catch {}
  return arr;
})();

function drawHubArmory() {
  const ax = HUB_ARMORY.x - camera.x;
  const ay = HUB_ARMORY.y - camera.y;

  ctx.save();

  // soft shadow
  ctx.globalAlpha = 0.35;
  ctx.fillStyle = "rgba(2,6,23,1)";
  ctx.beginPath();
  ctx.ellipse(ax + HUB_ARMORY.w/2, ay + HUB_ARMORY.h + 12, HUB_ARMORY.w*0.52, 12, 0, 0, Math.PI*2);
  ctx.fill();

  // base "workbench" panel
  ctx.globalAlpha = 0.98;
  ctx.fillStyle = "rgba(24,24,27,0.78)";
  ctx.strokeStyle = "rgba(250,204,21,0.75)";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.roundRect(ax, ay, HUB_ARMORY.w, HUB_ARMORY.h, 16);
  ctx.fill();
  ctx.stroke();

  // glow strip
  ctx.globalCompositeOperation = "lighter";
  const g = ctx.createLinearGradient(ax, ay, ax + HUB_ARMORY.w, ay);
  g.addColorStop(0, "rgba(56,189,248,0.0)");
  g.addColorStop(0.5, "rgba(56,189,248,0.22)");
  g.addColorStop(1, "rgba(56,189,248,0.0)");
  ctx.fillStyle = g;
  ctx.fillRect(ax + 10, ay + 10, HUB_ARMORY.w - 20, 10);

  ctx.globalCompositeOperation = "source-over";

  // label
  ctx.fillStyle = "rgba(255,248,220,0.95)";
  ctx.font = "9px 'Press Start 2P', monospace";
  ctx.textAlign = "center";
  ctx.fillText("WEAPONS", ax + HUB_ARMORY.w/2, ay + 26);

  // weapon rack (shows the same choices as the weapon picker; AK first)
const rackY = ay + 34;
const rackX0 = ax + 12;
const cards = HUB_ARMORY_WEAPON_CARDS.slice();

// ensure the AK shows first if present
cards.sort((a, b) => {
  const aw = (a.cfg && a.cfg.weaponId) ? String(a.cfg.weaponId) : "";
  const bw = (b.cfg && b.cfg.weaponId) ? String(b.cfg.weaponId) : "";
  const aAK = /ak|ak47|rifle/i.test(aw) ? 0 : 1;
  const bAK = /ak|ak47|rifle/i.test(bw) ? 0 : 1;
  return aAK - bAK;
});

const count = Math.min(3, cards.length || 0);
const slotW = 32;
const slotH = 32;
const gap = 6;

for (let i = 0; i < count; i++) {
  const { cfg, img } = cards[i];
  const x = rackX0 + i * (slotW + gap);
  const y = rackY;

  const isSel = cfg && cfg.weaponId && (cfg.weaponId === (selectedWeaponId || ""));

  // card bg
  ctx.save();
  ctx.globalAlpha = 0.95;
  ctx.fillStyle = "rgba(2,6,23,0.62)";
  ctx.strokeStyle = isSel ? "rgba(250,204,21,0.95)" : "rgba(56,189,248,0.55)";
  ctx.lineWidth = isSel ? 2.5 : 2;
  ctx.beginPath();
  ctx.roundRect(x, y, slotW, slotH, 10);
  ctx.fill();
  ctx.stroke();

  // inner gloss
  ctx.globalCompositeOperation = "lighter";
  const gg = ctx.createLinearGradient(x, y, x + slotW, y + slotH);
  gg.addColorStop(0, "rgba(255,255,255,0.08)");
  gg.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = gg;
  ctx.beginPath();
  ctx.roundRect(x + 2, y + 2, slotW - 4, (slotH - 4) * 0.55, 8);
  ctx.fill();
  ctx.globalCompositeOperation = "source-over";

  // weapon sprite (contained, no stretching)
  let drawn = false;
  if (img) drawn = drawImageContain(img, x + 4, y + 6, slotW - 8, slotH - 12, true);
  if (!drawn && cfg && cfg.weaponId && HUB_ARMORY_ICONS[cfg.weaponId]) {
    drawn = drawImageContain(HUB_ARMORY_ICONS[cfg.weaponId], x + 4, y + 6, slotW - 8, slotH - 12, true);
  }
  if (!drawn) {
    ctx.fillStyle = "rgba(250,204,21,0.9)";
    ctx.fillRect(x + 10, y + 14, 12, 6);
  }

  // subtle glow ring (like portal vibe)
  ctx.globalCompositeOperation = "lighter";
  const rg = ctx.createRadialGradient(x + slotW/2, y + slotH/2, 2, x + slotW/2, y + slotH/2, 26);
  rg.addColorStop(0, isSel ? "rgba(250,204,21,0.22)" : "rgba(56,189,248,0.18)");
  rg.addColorStop(1, "rgba(56,189,248,0)");
  ctx.fillStyle = rg;
  ctx.beginPath();
  ctx.arc(x + slotW/2, y + slotH/2, 26, 0, Math.PI*2);
  ctx.fill();
  ctx.restore();
}

  // prompt when close
  const d = distToRect(player.x, player.y, HUB_ARMORY);
  if (d < 70) {
    ctx.fillStyle = "rgba(250,204,21,0.95)";
    ctx.font = "8px 'Press Start 2P', monospace";
    ctx.fillText("[LOCKED] WEAPONS", ax + HUB_ARMORY.w/2, ay + HUB_ARMORY.h + 18);
  }

  ctx.restore();
}


// --- Hub Sprite Altar visuals (floating sprites with aura) ---
const HUB_SPRITE_IMAGES = (() => {
  const arr = [];
  try {
    (typeof CHARACTER_CONFIGS !== "undefined" ? CHARACTER_CONFIGS : []).forEach(cfg => {
      if (!cfg || !cfg.previewSrc) return;
      const img = new Image();
      img.src = cfg.previewSrc;
      arr.push({ cfg, img });
    });
  } catch {}
  return arr;
})();

function drawHubSpriteAltar() {
  const sx = HUB_SPRITES.x - camera.x;
  const sy = HUB_SPRITES.y - camera.y;
  const t = performance.now() * 0.001;

  ctx.save();

  // subtle shadow plate
  ctx.globalAlpha = 0.20;
  ctx.fillStyle = "rgba(2,6,23,1)";
  ctx.beginPath();
  ctx.ellipse(sx + HUB_SPRITES.w/2, sy + HUB_SPRITES.h + 14, HUB_SPRITES.w*0.46, 10, 0, 0, Math.PI*2);
  ctx.fill();

  // label
  ctx.globalAlpha = 0.95;
  ctx.fillStyle = "rgba(255,248,220,0.95)";
  ctx.font = "9px 'Press Start 2P', monospace";
  ctx.textAlign = "center";
  ctx.fillText("SPRITES", sx + HUB_SPRITES.w/2, sy + 14);

  // floating sprites with aura
  const cards = HUB_SPRITE_IMAGES;
  const count = Math.min(3, cards.length || 0);
  const gap = 34;
  const x0 = sx + 10;
  const baseY = sy + 34;

  for (let i = 0; i < count; i++) {
    const { cfg, img } = cards[i];
    const x = x0 + i * gap + 14;
    const bob = Math.sin(t*2.2 + i*1.1) * 3.5;

    // aura
    const rgb = (cfg && cfg.trailColor) ? cfg.trailColor : "56, 189, 248";
    ctx.globalCompositeOperation = "lighter";
    const g = ctx.createRadialGradient(x, baseY + bob, 2, x, baseY + bob, 26);
    g.addColorStop(0, `rgba(${rgb},0.55)`);
    g.addColorStop(0.55, `rgba(${rgb},0.18)`);
    g.addColorStop(1, `rgba(${rgb},0)`);
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, baseY + bob, 26, 0, Math.PI*2);
    ctx.fill();

    // sprite image (contained, no stretching)
ctx.globalCompositeOperation = "source-over";
const box = 30;
const bx = x - box/2;
const by = (baseY - 18 + bob);

// tiny "air frame" so it looks intentional
ctx.save();
ctx.globalAlpha = 0.9;
ctx.fillStyle = "rgba(2,6,23,0.45)";
ctx.strokeStyle = (cfg && cfg.id && cfg.id === selectedCharacterId)
  ? "rgba(250,204,21,0.95)"
  : `rgba(${rgb},0.55)`;
ctx.lineWidth = 2;
ctx.beginPath();
ctx.roundRect(bx - 1, by - 1, box + 2, box + 2, 10);
ctx.fill();
ctx.stroke();
ctx.restore();

let drawn = false;
if (img) drawn = drawImageContain(img, bx + 3, by + 3, box - 6, box - 6, true);
if (!drawn) {
  ctx.fillStyle = "rgba(250,204,21,0.9)";
  ctx.fillRect(bx + 6, by + 6, box - 12, box - 12);
}

    // selected highlight
    if (cfg && cfg.id && cfg.id === selectedCharacterId) {
      ctx.strokeStyle = "rgba(250,204,21,0.9)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x, baseY + bob, 18, 0, Math.PI*2);
      ctx.stroke();
    }
  }

  // prompt when close
  const d = distToRect(player.x, player.y, HUB_SPRITES);
  if (d < 78) {
    ctx.fillStyle = "rgba(250,204,21,0.95)";
    ctx.font = "8px 'Press Start 2P', monospace";
    ctx.fillText("[LOCKED] SPRITES", sx + HUB_SPRITES.w/2, sy + HUB_SPRITES.h + 18);
  }

  ctx.restore();
}

function drawFarmHubStructures() {
  if (gameState !== "farmHub") return;

  // Extra farm vibe
  drawHubDecor();

  // Terminals (refreshed style)
  if (false) {

    HUB_TERMINALS.forEach(t => {
    const sx = t.x - camera.x;
    const sy = t.y - camera.y;

    ctx.save();
    // shadow
    ctx.globalAlpha = 0.35;
    ctx.fillStyle = "rgba(2,6,23,1)";
    ctx.beginPath();
    ctx.ellipse(sx + t.w/2, sy + t.h + 8, t.w*0.55, 10, 0, 0, Math.PI*2);
    ctx.fill();

// terminal body (farm hub, but with clear stat colors)
const kind = t.kind;
const kCol =
  kind === "dmg"   ? "239, 68, 68"  :   // red
  kind === "hp"    ? "34, 197, 94"  :   // green
  kind === "speed" ? "56, 189, 248" :   // cyan
                    "234, 179, 8";      // gold fallback

ctx.globalAlpha = 0.98;
ctx.fillStyle = "rgba(69,40,16,0.88)";
ctx.strokeStyle = `rgba(${kCol},0.85)`;
ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.roundRect(sx, sy, t.w, t.h, 14);
    ctx.fill();
    ctx.stroke();

    // screen glow
    ctx.globalCompositeOperation = "lighter";
    const g = ctx.createRadialGradient(sx + t.w/2, sy + t.h/2, 2, sx + t.w/2, sy + t.h/2, 42);
    g.addColorStop(0, `rgba(${kCol},0.38)`);
    g.addColorStop(1, `rgba(${kCol},0)`);
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.roundRect(sx + 10, sy + 12, t.w - 20, t.h - 24, 10);
    ctx.fill();

    // label
    ctx.globalCompositeOperation = "source-over";
    ctx.fillStyle = "rgba(255,248,220,0.95)";
    ctx.font = "10px 'Press Start 2P', monospace";
    ctx.textAlign = "center";
    const label = (kind === "speed") ? "SPD" : kind.toUpperCase();
    ctx.fillText(label, sx + t.w/2, sy + t.h/2 + 4);

    // subtle prompt when close
    const d = distToRect(player.x, player.y, t);
    if (d < 62) {
      ctx.fillStyle = "rgba(250,204,21,0.95)";
      ctx.font = "8px 'Press Start 2P', monospace";
      ctx.fillText("[E]", sx + t.w/2, sy + t.h + 18);
    }
    ctx.restore();
    });

  }

  // Sprite altar floats above the armory
  drawHubSpriteAltar();

  // Armory station next to the portal
  drawHubArmory();
  // Portal gate removed (yellow door portal disabled). Wave entry uses the purple center portal.

  // ===== NEW: World labels + idle NPCs for key locations =====
  drawHubSigns();
  drawHubNPCs();
  drawHubInteractPrompts();
  // (center callout removed)
}

// Wooden sign boards (world-space, farm hub only)
function drawHubSigns() {
  if (gameState !== 'farmHub') return;
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = "11px 'Press Start 2P', monospace";

  HUB_SIGNS.forEach(s => {
    const sx = Math.round(s.x - camera.x);
    const sy = Math.round(s.y - camera.y);

    const w = (s.text.length >= 10) ? 176 : 140;
    const h = 34;
    const x = sx - (w >> 1);
    const y = sy - (h >> 1);

    // ground shadow
    ctx.globalAlpha = 0.35;
    ctx.fillStyle = 'rgba(0,0,0,0.85)';
    ctx.beginPath();
    ctx.ellipse(sx, sy + 20, w * 0.34, 10, 0, 0, Math.PI * 2);
    ctx.fill();

    // posts
    ctx.globalAlpha = 0.95;
    ctx.fillStyle = 'rgba(60,36,16,0.95)';
    ctx.fillRect(x + 10, y + h - 2, 10, 26);
    ctx.fillRect(x + w - 20, y + h - 2, 10, 26);

    // plank body
    ctx.fillStyle = 'rgba(92,58,28,0.92)';
    ctx.strokeStyle = 'rgba(22,12,6,0.95)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    (ctx.roundRect ? ctx.roundRect(x, y, w, h, 10) : ctx.rect(x, y, w, h));
    ctx.fill();
    ctx.stroke();

    // grain lines
    ctx.globalAlpha = 0.22;
    ctx.strokeStyle = 'rgba(255,220,160,0.35)';
    ctx.lineWidth = 1;
    for (let i=0;i<4;i++){
      const gy = y + 7 + i*7;
      ctx.beginPath();
      ctx.moveTo(x+10, gy);
      ctx.lineTo(x+w-10, gy);
      ctx.stroke();
    }

    // inner bevel
    ctx.globalAlpha = 0.35;
    ctx.strokeStyle = 'rgba(255,255,255,0.35)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    (ctx.roundRect ? ctx.roundRect(x + 4, y + 4, w - 8, h - 8, 8) : ctx.rect(x + 4, y + 4, w - 8, h - 8));
    ctx.stroke();

    // text
    ctx.globalAlpha = 1;
    ctx.fillStyle = 'rgba(255,211,106,0.98)';
    ctx.shadowColor = 'rgba(0,0,0,0.85)';
    ctx.shadowBlur = 6;
    ctx.fillText(s.text, sx, sy + 1);
    ctx.shadowBlur = 0;
  });

  ctx.restore();
}


// Idle animated NPCs (GIFs) next to each location
function drawHubNPCs() {
  // Hub NPCs must NEVER appear once a combat run starts.
  // Some flows keep the player on the farmhub map while waves run,
  // so we also gate on the wave counter / combat presence.
  let inCombat = false;
  try {
    inCombat = (typeof wave === 'number' && wave >= 1);
  } catch(_) { inCombat = false; }
  if (gameState !== 'farmHub' || inCombat) { hideHubNpcDom(); return; }

  // Ensure an animated DOM layer exists (canvas drawing of GIFs is not reliably animated across browsers).
  ensureHubNpcDom();

  // Draw only the soft ground shadow in-canvas (keeps it "in-world").
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  HUB_NPCS.forEach(n => {
    const sx = Math.round(n.x - camera.x);
    const sy = Math.round(n.y - camera.y);
    ctx.globalAlpha = 0.55;
    ctx.fillStyle = 'rgba(2,6,23,0.95)';
    ctx.beginPath();
    ctx.ellipse(sx, sy + 18, 18, 7, 0, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.restore();

  // Update DOM sprite positions (animated GIFs)
  updateHubNpcDom();
}

let __hubNpcDom = null;
function ensureHubNpcDom(){
  // If the layer existed but got detached (some overlays rebuild DOM), recreate it.
  try { if (__hubNpcDom && !document.body.contains(__hubNpcDom)) __hubNpcDom = null; } catch(_) {}
  if (__hubNpcDom) return __hubNpcDom;

  const wrap = document.getElementById('game-wrap') || document.body;
  const layer = document.createElement('div');
  layer.id = 'npc-layer';
  layer.style.position = 'absolute';
  layer.style.left = '0';
  layer.style.top = '0';
  layer.style.width = '100%';
  layer.style.height = '100%';
  layer.style.pointerEvents = 'none';
  layer.style.zIndex = '6';

  // Create an <img> per NPC
  HUB_NPCS.forEach(n => {
    const im = document.createElement('img');
    im.className = 'hub-npc';
    im.alt = n.key;
    im.src = `assets/npcs/${n.key}.gif`;
    im.style.position = 'absolute';
    im.style.width = '64px';
    im.style.height = '64px';
    im.style.imageRendering = 'pixelated';
    im.style.filter = 'drop-shadow(0 6px 6px rgba(0,0,0,0.55))';
    layer.appendChild(im);
    n.__dom = im;
  });

  wrap.appendChild(layer);
  __hubNpcDom = layer;
  return layer;
}
function hideHubNpcDom(){
  if (!__hubNpcDom) return;
  try { __hubNpcDom.style.display = 'none'; } catch(e){}
}
function showHubNpcDom(){
  if (!__hubNpcDom) return;
  // NPCs should ONLY appear in FarmHub when NOT in combat (wave 0 / no enemies).
  let ok = false;
  try{
    const w = (typeof wave === 'number') ? wave : (typeof window.wave === 'number' ? window.wave : 0);
    const enemyCount = (typeof enemies !== 'undefined' && enemies && enemies.length) ? enemies.length : 0;
    ok = (gameState === 'farmHub') && (w <= 0);
  } catch(e){ ok = (gameState === 'farmHub'); }

  try { __hubNpcDom.style.display = ok ? 'block' : 'none'; } catch(e){}
}
function updateHubNpcDom(){
  if (!__hubNpcDom) return;
  showHubNpcDom();

  const rect = canvas.getBoundingClientRect();
  const scaleX = rect.width  ? (rect.width / canvas.width)  : 1;
  const scaleY = rect.height ? (rect.height / canvas.height) : 1;

  // IMPORTANT: when we zoom the world (ARC_CAMERA_ZOOM), the canvas draws world pixels scaled up.
  // The DOM NPC layer must match that zoom or it will "swim" with the camera.
  const __z = (typeof ARC_CAMERA_ZOOM === 'number' && isFinite(ARC_CAMERA_ZOOM)) ? ARC_CAMERA_ZOOM : 1;

  HUB_NPCS.forEach(n => {
    const im = n.__dom;
    if (!im) return;

    // World -> screen (canvas pixels), then canvas pixels -> CSS pixels
    const sx = (n.x - camera.x - 32) * __z;
    const sy = (n.y - camera.y - 48) * __z;

    im.style.left = (rect.left + sx * scaleX) + 'px';
    im.style.top  = (rect.top  + sy * scaleY) + 'px';

    // Scale the DOM image to match both CSS scaling and world zoom.
    im.style.transform = `scale(${scaleX * __z}, ${scaleY * __z})`;
    im.style.transformOrigin = 'top left';
  });
}

// ---- HUB INTERACTION (Press E + chat bubble) ----
const HUB_INTERACTS = [
  { key:'blacksmith', label:'BLACKSMITH', prompt:'PRESS E TO ENTER BLACKSMITH', x: 470, y: 500, r: 92, onEnter: () => { try { if (window.__forge && window.__forge.open) window.__forge.open(); } catch(e){} } },
  { key:'shop',       label:'SHOP',       prompt:'PRESS E TO ENTER SHOP',       x: 1180, y: 545, r: 92, onEnter: () => { try { if (window.__shop && window.__shop.openShopWithTab) window.__shop.openShopWithTab('cosmetics'); else if (window.__shop && window.__shop.openShop) window.__shop.openShop(); } catch(e){} } },
  { key:'upgrades',   label:'UPGRADES',   prompt:'PRESS E TO OPEN UPGRADES',    x: 900,  y: 700, r: 92, onEnter: () => { try { if (window.__shop && window.__shop.openShopWithTab) window.__shop.openShopWithTab('upgrades'); else if (window.__shop && window.__shop.openShop) window.__shop.openShop(); } catch(e){} } },
];

let __hubInteractNear = null;

function hubFindNearestInteract(){
  if (gameState !== 'farmHub') return null;
  let best = null;
  let bestD = 1e9;
  for (const it of HUB_INTERACTS){
    const d = Math.hypot(player.x - it.x, player.y - it.y);
    if (d < it.r && d < bestD){
      bestD = d;
      best = it;
    }
  }
  return best;
}

function drawHubInteractPrompts(){
  if (gameState !== 'farmHub') return;
  const near = hubFindNearestInteract();
  __hubInteractNear = near;

  // Bottom center prompt
  if (near){
    const txt = near.prompt;
    const cx = Math.round(canvas.width/2);
    const cy = Math.round(canvas.height - 90);

    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = "12px 'Press Start 2P', monospace";

    // pixel panel
    const padX = 16, padY = 10;
    const w = Math.min(560, ctx.measureText(txt).width + padX*2);
    const h = 38;
    const x = cx - w/2;
    const y = cy - h/2;

    ctx.globalAlpha = 0.85;
    ctx.fillStyle = 'rgba(2,6,23,0.85)';
    ctx.fillRect(x, y, w, h);
    ctx.globalAlpha = 1;
    ctx.strokeStyle = 'rgba(96,165,250,0.75)';
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, w, h);

    ctx.fillStyle = 'rgba(255,211,106,0.98)';
    ctx.fillText(txt, cx, cy+1);
    ctx.restore();

    // Speech bubble above NPC: "E: TALK"
    const bx = Math.round(near.x - camera.x);
    const by = Math.round(near.y - camera.y - 70);
    const btxt = 'E: TALK';
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = "10px 'Press Start 2P', monospace";
    const tw = ctx.measureText(btxt).width;
    const bw = tw + 18;
    const bh = 24;
    const bx0 = bx - bw/2;
    const by0 = by - bh/2;

    ctx.globalAlpha = 0.92;
    ctx.fillStyle = 'rgba(2,6,23,0.90)';
    ctx.fillRect(bx0, by0, bw, bh);
    ctx.globalAlpha = 1;
    ctx.strokeStyle = 'rgba(255,211,106,0.85)';
    ctx.lineWidth = 2;
    ctx.strokeRect(bx0, by0, bw, bh);
    ctx.fillStyle = 'rgba(255,255,255,0.95)';
    ctx.fillText(btxt, bx, by+1);
    ctx.restore();
  }
}

function showPortalHint() { /* disabled */ if (!portalHint) return; portalHint.style.opacity="0"; portalHint.style.transform="translate(-50%,0) scale(0.98)"; }
function hidePortalHint() {
      if (!portalHint) return;
      portalHint.style.opacity = "0";
      portalHint.style.transform = "translate(-50%, 8px) scale(0.98)";
    }

    function showSolanaRealmToast() {
      centerToast.textContent = "SOLANA REALM";
      centerToast.style.opacity = "1";
      centerToast.style.transform = "translate(-50%, -50%) scale(1)";
      centerToast.style.transition = "opacity 0.5s ease-out, transform 0.5s ease-out";
      if (toastTimeout) clearTimeout(toastTimeout);
      toastTimeout = setTimeout(() => {
        centerToast.style.opacity = "0";
        centerToast.style.transform = "translate(-50%, -50%) scale(0.9)";
      }, 1400);
    }

    function isPlayerNearUpgradeStation() {
      if (!upgradeStationPos) return false;
      return distance(player.x, player.y, upgradeStationPos.x, upgradeStationPos.y) < 90;
    }

    function spawnDamagePopup(value, x, y, isHeadshot) {
  damagePopups.push({ x, y, value, isHeadshot, ttl: 600, vy: 0.05, isArc: false });
}

// When player gets hit, ARC streak is lost
function resetArcStreakOnHit() {
  if (arcStreak > 0) {
    arcStreak = 0;
    arcMultiplier = 1;
    arcStreakLastKillTime = 0;
    if (arcMultLabel) {
      arcMultLabel.textContent = "ARC x1.0";
    }
  }
}


    // draw damage popups (handles ARC and headshot visuals)
function drawDamagePopups() {
  damagePopups.forEach(p => {
    const sx = p.x - camera.x;
    const sy = p.y - camera.y;

    const baseTtl = p.baseTtl || 600;
    const lifeRatio = Math.max(0, p.ttl / baseTtl);
    const alpha = lifeRatio;

    ctx.save();
    ctx.textAlign = "center";

    if (p.isArc) {
      // === GOD-TIER ARC POPUP ===
      const tier = p.tier || "small";
      const extraScale =
        tier === "mega" ? 0.7 :
        tier === "big"  ? 0.4 :
                          0.25;

      const scale = 1 + extraScale * (1 - lifeRatio);
      const fontSize = 11 * scale;

      ctx.font = fontSize.toFixed(1) +
        "px 'Press Start 2P', system-ui, sans-serif";

      ctx.shadowColor = "rgba(250,204,21," + alpha + ")";
      ctx.shadowBlur = 10 * scale;

      const text = p.text || ("+" + p.value + " ARC");

      ctx.fillStyle = "rgba(250,204,21," + alpha + ")";
      ctx.strokeStyle = "rgba(15,23,42," + alpha + ")";
      ctx.lineWidth = 2.2 * scale;

      // subtle wobble
      const wobble = Math.sin((1 - lifeRatio) * Math.PI * 2) * 2 * scale;
      ctx.translate(0, wobble);

      ctx.strokeText(text, sx, sy);
      ctx.fillText(text, sx, sy);
    } else {
      // normal damage numbers stay simple
      ctx.font = "8px 'Press Start 2P', system-ui, sans-serif";
      ctx.fillStyle = p.isHeadshot
        ? "rgba(250,204,21," + alpha + ")"
        : "rgba(248,250,252," + alpha + ")";
      // subtle outline for readability on any tile
      ctx.shadowColor = 'rgba(0,0,0,0.55)';
      ctx.shadowBlur = 0;
      ctx.shadowOffsetX = 1;
      ctx.shadowOffsetY = 1;

      const text = p.isHeadshot ? "☠ " + p.value : p.value;

      ctx.fillText(text, sx, sy);
    }

    ctx.restore();
  });
}

    // updateAchievements (already used in many places)
    function updateAchievements() {
      // Achievements UI was removed; keep logic safe if elements are missing.
      if (!ach1Fill || !ach2Fill || !ach3Fill || !ach1Meta || !ach2Meta || !ach3Meta) return;

      const p = points;
      const a1 = Math.min(1, p / 10000);
      const a2 = Math.min(1, p / 25000);
      const a3 = Math.min(1, p / 50000);

      ach1Fill.style.transform = "scaleX(" + a1 + ")";
      ach2Fill.style.transform = "scaleX(" + a2 + ")";
      ach3Fill.style.transform = "scaleX(" + a3 + ")";

      ach1Meta.textContent = Math.floor(a1 * 100) + "%";
      ach2Meta.textContent = Math.floor(a2 * 100) + "%";
      ach3Meta.textContent = Math.floor(a3 * 100) + "%";
    }
function addPlayerTrailSample() {
  const maxTrailPoints = 40;
  const minDist = 4;

  const last = playerTrail[playerTrail.length - 1];
  if (last) {
    const dx = player.x - last.x;
    const dy = player.y - last.y;
    if (dx * dx + dy * dy < minDist * minDist) {
      return; // too close to last point; skip
    }
  }

  playerTrail.push({
    x: player.x,
    y: player.y,
    life: 1
  });

  if (playerTrail.length > maxTrailPoints) {
    playerTrail.shift();
  }
}

    // main update/draw loop (kept logic intact, ensured drawDamagePopups is used)
function update(dt, now) {
  // cinematic slow-mo (boss spawns / phase shifts)
  if (slowMoTime > 0) {
    slowMoTime = Math.max(0, slowMoTime - dt);
    dt *= 0.35;
  }

  // Pause menu (ESC): freeze gameplay updates while paused.
  if (typeof window !== "undefined" && window.isPaused) {
    return;
  }

  // ambient farmer NPC
  // (Farmer NPC removed)

  animTime += dt;

  // Safety: if the player's coords ever become invalid (NaN/Infinity),
  // the camera/enemy AI can "explode" (enemies sprinting/straying, camera clamping to 0,0).
  // Snap the player back to the world center and re-center the camera.
  if (!player || !isFinite(player.x) || !isFinite(player.y)) {
    try {
      if (!player) player = {};
      player.x = (WORLD_WIDTH || 0) / 2;
      player.y = (WORLD_HEIGHT || 0) / 2;
      centerCameraOnPlayer(true);
    } catch(_) {}
  }

  // HARD FIX: when a run begins, keep forcing a valid combat spawn + camera
  // for a handful of frames. This guarantees the player starts centered and
  // the camera tracks them, even if another state/UI path briefly stomps values.
  if (__forceCombatSpawnFrames > 0 && gameState === 'playing') {
    try {
      player.x = WORLD_WIDTH / 2;
      player.y = WORLD_HEIGHT / 2;
    } catch(_) {}
    try { centerCameraOnPlayer(true); } catch(_) {}
    __forceCombatSpawnFrames--;
  }

  // FarmHub decorative animals
  if (gameState === "farmHub") {
    updateFarmAnimals(dt);
  }

  // VOID FX update (stars + shooting stars)
  if (mapMode === 'void') {
    // Spawn a shooting star occasionally
    if (Math.random() < 0.015 * dt) {
      const edge = Math.random();
      let x = 0, y = 0, vx = 0, vy = 0;
      // Spawn near top-left -> drift down-right by default
      if (edge < 0.5) {
        x = camera.x + Math.random() * (canvas.width + 200) - 100;
        y = camera.y - 120;
      } else {
        x = camera.x - 120;
        y = camera.y + Math.random() * (canvas.height + 200) - 100;
      }
      const spd = 12 + Math.random() * 10;
      vx = spd;
      vy = spd * (0.55 + Math.random() * 0.35);
      voidShootingStars.push({ x, y, vx, vy, life: 55 + Math.random() * 35 });
    }
    for (let i = voidShootingStars.length - 1; i >= 0; i--) {
      const st = voidShootingStars[i];
      st.x += st.vx * dt * 2.2;
      st.y += st.vy * dt * 2.2;
      st.life -= dt * 60;
      if (st.life <= 0) voidShootingStars.splice(i, 1);
    }
  }

  // SNOW FX update (screen-space flakes)
  if (mapMode === 'snow' && snowFlakes && snowFlakes.length) {
    const w = canvas.width, h = canvas.height;
    for (const f of snowFlakes) {
      f.wob += 0.012 * dt * 60;
      f.x += (f.vx + Math.sin(f.wob) * 0.25) * dt * 60;
      f.y += f.vy * dt * 60;
      if (f.y > h + 12) { f.y = -12; f.x = Math.random() * w; }
      if (f.x < -20) f.x = w + 20;
      if (f.x > w + 20) f.x = -20;
    }
  }

  // DESERT FX update (dust streaks)
  if ((mapMode === 'desert' || mapMode === 'desertPNG') && sandDust && sandDust.length) {
    const w = canvas.width, h = canvas.height;
    for (const d of sandDust) {
      d.wob = (d.wob || 0) + 0.01 * dt * 60;
      d.x += d.vx * dt * 60;
      d.y += (d.vy || 0) * dt * 60;
      // tiny vertical wander
      d.y += Math.sin(d.wob) * 0.06 * dt * 60;
      if (d.x > w + 120) { d.x = -120; d.y = Math.random() * h; }
      if (d.y < -40) d.y = h + 40;
      if (d.y > h + 40) d.y = -40;
    }
  }

  // === PLAYER TRAIL FADE ===
  for (let i = playerTrail.length - 1; i >= 0; i--) {
    playerTrail[i].life -= dt * 0.06;
    if (playerTrail[i].life <= 0) {
      playerTrail.splice(i, 1);
    }
  }

  // === PLAYER WALK / DUST ANIMATION UPDATE ===
  if (playerIsMoving) {
    playerWalkTimer += dt * 16.67;
    if (playerWalkTimer >= PLAYER_WALK_FRAME_DURATION) {
      playerWalkTimer = 0;
      playerWalkFrame = (playerWalkFrame + 1) % PLAYER_WALK_FRAMES;
    }

    playerDustTimer += dt * 16.67;
    if (playerDustTimer >= PLAYER_DUST_FRAME_DURATION) {
      playerDustTimer = 0;
      playerDustFrame = (playerDustFrame + 1) % PLAYER_DUST_FRAMES;
    }
  } else {
    playerWalkFrame = 0;
    playerDustFrame = 0;
    playerWalkTimer = 0;
    playerDustTimer = 0;
  }


      if (gameState !== "playing" && gameState !== "farmHub") {
        updateAchievements();
        return;
      }
      if (gameOver) return;
    // If the leaderboard overlay is open, freeze gameplay (no movement / damage)
    const lb = document.getElementById("leaderboard-overlay");
    if (lb && lb.style.display === "flex") {
      return;
    }

      if ((window.arcShakeEnabled !== false) && shakeTime > 0) {
        shakeTime -= dt * 16.67;
        if (shakeTime < 0) shakeTime = 0;
      }

      if (xpBoostActive) {
        if (now >= xpBoostEndTime) {
          xpBoostActive = false;
          xpMultiplier = 1;
          xpBoostWrapper.style.display = "none";
        } else {
          const ratio = (xpBoostEndTime - now) / xpBoostDuration;
          xpBoostFill.style.transform = "scaleX(" + Math.max(0, ratio) + ")";
          xpBoostFill.style.background = "linear-gradient(90deg,#22c55e,#a855f7)";
        }
      }
      if (speedBoostActive) {
        if (now >= speedBoostEndTime) {
          speedBoostActive = false;
          player.speed = baseMoveSpeed;
          speedBoostWrapper.style.display = "none";
        } else {
          const ratio = (speedBoostEndTime - now) / speedBoostDuration;
          speedBoostFill.style.transform = "scaleX(" + Math.max(0, ratio) + ")";
          speedBoostFill.style.background = "linear-gradient(90deg,#38bdf8,#22c55e)";
        }
      }

            let moveX = (keys["d"] ? 1 : 0) - (keys["a"] ? 1 : 0);
      let moveY = (keys["s"] ? 1 : 0) - (keys["w"] ? 1 : 0);
      let length = Math.hypot(moveX, moveY);
      let speed = player.speed;

      if (now < dashEndTime) {
        speed = player.dashSpeed;
      }

      playerIsMoving = length > 0;

      if (length > 0) {
        if (Math.abs(moveX) > Math.abs(moveY)) {
          playerFacing = moveX > 0 ? 'east' : 'west';
        } else {
          playerFacing = moveY > 0 ? 'south' : 'north';
        }
      }


      if (length > 0) {
        moveX /= length;
        moveY /= length;
        const stepX = moveX * speed * dt;
        const stepY = moveY * speed * dt;

        const newX = player.x + stepX;
        if (!isSolidAt(newX - player.r, player.y) &&
            !isSolidAt(newX + player.r, player.y) &&
            !isSolidAt(newX, player.y - player.r) &&
            !isSolidAt(newX, player.y + player.r)) {
          player.x = newX;
        }

        const newY = player.y + stepY;
        if (!isSolidAt(player.x - player.r, newY) &&
            !isSolidAt(player.x + player.r, newY) &&
            !isSolidAt(player.x, newY - player.r) &&
            !isSolidAt(player.x, newY + player.r)) {
          player.y = newY;
        }

        // leave a trail point after movement
        addPlayerTrailSample();
      }

      // Keep the player inside the actual playable combat lane.
      // If the player slips outside the lane (side-bands), enemies are clamped to the lane
      // and will appear to "break" or wander away when you leave their sight.
      if (gameState === "playing" && mapMode !== 'desertPNG') {
        const minPX = (typeof PLAY_MIN_X === 'number' ? PLAY_MIN_X : 0) + (player.r || 0);
        const maxPX = (typeof PLAY_MAX_X === 'number' ? PLAY_MAX_X : WORLD_WIDTH) - (player.r || 0);
        if (isFinite(minPX) && isFinite(maxPX) && maxPX > minPX) {
          if (player.x < minPX) player.x = minPX;
          if (player.x > maxPX) player.x = maxPX;
        }
      }

      // Keep camera locked to the player every frame (hub + waves).
      // Previously we only centered on transitions, which left the camera "stuck"
      // and made it look like you spawned off-screen / enemies behaved oddly.
      if (gameState === "playing" || gameState === "farmHub") {
        centerCameraOnPlayer(false);
      }

      

      const timeSinceDash = now - lastDashTime;
      if (timeSinceDash >= player.dashCooldown) {
        dashLabel.textContent = "Dash: ready";
      } else {
        const t = Math.max(0, (player.dashCooldown - timeSinceDash) / 1000).toFixed(1);
        dashLabel.textContent = "Dash: " + t + "s";
      }

      // With ARC_CAMERA_ZOOM, the world layer is scaled. Convert screen mouse coords -> world coords.
      const __zAim = (typeof ARC_CAMERA_ZOOM === 'number' && isFinite(ARC_CAMERA_ZOOM)) ? ARC_CAMERA_ZOOM : 1;
      const worldMouseX = camera.x + (mouseX / __zAim);
      const worldMouseY = camera.y + (mouseY / __zAim);
      playerFacingAngle = Math.atan2(worldMouseY - player.y, worldMouseX - player.x) || 0;
      window.__lastWorldMouseX = worldMouseX; window.__lastWorldMouseY = worldMouseY;

      // Make the character face where you're aiming (not just where you're walking).
      // Choose the dominant axis so 4-direction sheets look correct.
      {
        const ax = Math.cos(playerFacingAngle);
        const ay = Math.sin(playerFacingAngle);
        if (Math.abs(ax) >= Math.abs(ay)) {
          playerFacing = (ax >= 0) ? 'east' : 'west';
        } else {
          playerFacing = (ay >= 0) ? 'south' : 'north';
        }
      }

      if (gameState === "playing" && mouseDown) {
        const timeSinceLast = now - lastShotTime;
        if (timeSinceLast >= player.fireRate) {
          shootWeapon();
          lastShotTime = now;
        }
      }

      if (gameState === "playing") {
        bullets.forEach(b => {
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        b.life -= dt;
      });
        bullets = bullets.filter(b =>
        b.life > 0 &&
        b.x > 0 && b.y > 0 &&
        b.x < WORLD_WIDTH && b.y < WORLD_HEIGHT
      );
      } else { bullets = []; }

      enemyBullets.forEach(b => {
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        b.life -= dt;
      });
      enemyBullets = enemyBullets.filter(b =>
        b.life > 0 &&
        b.x > 0 && b.y > 0 &&
        b.x < WORLD_WIDTH && b.y < WORLD_HEIGHT
      );

      enemies.forEach(e => {
        // === Wave 26–31: hard-lock enemy visuals to the late roster (rats/bats/slimes only)
        // This prevents any legacy sprite assignment paths from leaking older wave enemies into 26–31.
        if (!e.isBoss && wave >= 26 && wave <= 31 && !inRift) {
          if (e.skin !== 'rat' && e.skin !== 'bat' && e.skin !== 'slime') {
            if (!e.__lateSkinAssigned) {
              // Deterministic roll per enemy so it doesn't change frame-to-frame.
              const sid = (e.spawnId != null) ? e.spawnId : ((e.__animSeed != null) ? e.__animSeed : 0);
              const roll = ((sid * 9301 + wave * 1013) % 1000) / 1000;
              if (roll < 0.45) {
                e.skin = 'rat';
                e.r = 11;
                e.hitYOffset = 24;
                e.contactDamageMult = 0.55;
              } else if (roll < 0.80) {
                e.skin = 'bat';
                e.r = 12;
                e.hitYOffset = 0;
                e.contactDamageMult = 0.80;
              } else {
                e.skin = 'slime';
                e.r = 12;
                e.hitYOffset = 28;
                e.contactDamageMult = 0.85;
                if (e.__slimeVariant == null) {
                  const seed = ((sid || 0) + wave * 1337 + Math.floor(e.x * 10) + Math.floor(e.y * 10)) >>> 0;
                  e.__slimeVariant = (seed % 3) + 1;
                }
              }
              e.__lateSkinAssigned = true;
            } else {
              // If previously assigned but somehow lost, default to rat.
              e.skin = 'rat';
              e.r = 11;
              e.hitYOffset = 24;
              e.contactDamageMult = 0.55;
            }
          }
        }
        const dx = (player.x - e.x);
        const dy = (player.y - e.y);
        let dist = Math.hypot(dx, dy);
        if (!isFinite(dist) || dist <= 0.0001) dist = 1;
        let targetDist = 0; // all enemies chase (ranged hold-distance disabled)
        let dirX = dx / dist;
        let dirY = dy / dist;
        // Defensive: keep speeds finite + within a sane range.
        // If any code path ever corrupts e.speed, enemies can appear to "teleport" or sprint.
        let speedE = (typeof e.speed === 'number' && isFinite(e.speed)) ? e.speed : 1.6;
        speedE = Math.max(0.15, Math.min(3.25, speedE));

        // ===== BOSS PHASES + SUMMONS (keeps core loop, adds hype) =====
        if (e.isBoss) {
          const hpRatio = e.hp / (e.maxHp || 1);
          let phase = 0;
          if (hpRatio <= 0.25) phase = 2;
          else if (hpRatio <= 0.55) phase = 1;

          if (phase > (e.bossPhase || 0)) {
            e.bossPhase = phase;
            slowMoTime = Math.max(slowMoTime, 0.22);
            bossPulseAlpha = 1;
            triggerShake(16);
            playBossPhaseShift();
            showToast(phase === 1 ? "BOSS PHASE 2" : "FINAL PHASE");
          }

          // Speed ramps per phase
          speedE *= (phase === 2 ? 1.38 : phase === 1 ? 1.18 : 1.0);

          // Summon pressure: little mobs pop in near the boss
          const summonCd = (phase === 2 ? 1900 : phase === 1 ? 2600 : 3600);
          if (now - (e.bossLastSummon || 0) > summonCd) {
            e.bossLastSummon = now;
            const n = (phase === 2 ? 5 : phase === 1 ? 3 : 2);
            for (let i = 0; i < n; i++) {
              const ox = (Math.random() * 2 - 1) * 60;
              const oy = (Math.random() * 2 - 1) * 60;
              spawnEnemy(Math.random() < 0.7 ? "swarm" : "fast", e.x + ox, e.y + oy);
            }
            triggerShake(10);
          }
        }


        if (targetDist > 0.0001) {
          if (dist > targetDist + 25) {
          } else if (dist < targetDist - 25) {
            dirX *= -1;
            dirY *= -1;
          } else {
            speedE = 0;
          }
        }

        // Mark movement state for rendering (TinyRPG walk/idle readability)
        e.isMoving = speedE > 0.1;

        // Evil Wizard boss: smoother hover/orbit movement (no jitter wobble)
        if (e.isBoss && e.bossKind === 'evilWizard') {
          const d = Math.max(0.001, dist);
          const desired = 320;
          const band = 48;
          // radial intent: keep distance band
          let rx = 0, ry = 0;
          if (d > desired + band) { rx = dx / d; ry = dy / d; }
          else if (d < desired - band) { rx = -dx / d; ry = -dy / d; }
          // strafe around player
          const px = -dy / d;
          const py = dx / d;
          let sx2 = rx + px * 0.85;
          let sy2 = ry + py * 0.85;
          const n = Math.hypot(sx2, sy2) || 1;
          dirX = sx2 / n;
          dirY = sy2 / n;
          // keep him moving a bit so run anim reads well
          speedE = Math.max(e.speed * 0.85, 1.6);
          e.isMoving = true;
        }

        // Keep enemy motion stable and player-focused (no random sideways drift).
        // This fixes enemies 'running around by themselves' and odd speed spikes when the camera/player moves far.
        const stepX = (dirX * (isFinite(speedE) ? speedE : 1.6)) * dt;
        const stepY = (dirY * (isFinite(speedE) ? speedE : 1.6)) * dt;

        const newX = e.x + stepX;
        const newY = e.y + stepY;

        if (!isSolidAt(newX - e.r, e.y) &&
            !isSolidAt(newX + e.r, e.y) &&
            !isSolidAt(newX, e.y - e.r) &&
            !isSolidAt(newX, e.y + e.r)) {
          e.x = newX;
        }
        if (!isSolidAt(e.x - e.r, newY) &&
            !isSolidAt(e.x + e.r, newY) &&
            !isSolidAt(e.x, newY - e.r) &&
            !isSolidAt(e.x, newY + e.r)) {
          e.y = newY;
        }
                
       
       // keep enemies inside full world horizontally & vertically
if (e.x < e.r)               e.x = e.r;
if (e.x > WORLD_WIDTH - e.r) e.x = WORLD_WIDTH - e.r;
if (e.y < e.r)               e.y = e.r;
if (e.y > WORLD_HEIGHT - e.r) e.y = WORLD_HEIGHT - e.r;

// keep enemies inside the playable lane so none get stuck "hovering"
// NOTE: Some maps (like the open desert PNG map) are not lane-based.
// Clamping X into the lane on those maps causes enemies to stack into a
// dark "shadow blob" and look broken. Only clamp on lane maps.
if (mapMode !== 'desertPNG') {
  if (e.x < PLAY_MIN_X + e.r) e.x = PLAY_MIN_X + e.r;
  if (e.x > PLAY_MAX_X - e.r) e.x = PLAY_MAX_X - e.r;
}

        // Enemy facing (for sprite flip)
        e.facing = (dx >= 0) ? 1 : -1;

        // Enemy ranged attacks + intent telegraph (tiny wind-up so fights feel readable)
        if ((e.type === "ranged" || e.isBoss) && dist < 520) {
          const cd = Math.max(260, e.fireCooldown || 900);
          const windup = e.isBoss ? 220 : 170;

          // Start a pending shot when off cooldown.
          if (!e.__pendingShotAt) {
            if ((now - (e.lastShot || 0)) >= cd) {
              e.__pendingShotAt = now + windup;
              e.__intentType = 'shoot';
              e.__intentUntil = e.__pendingShotAt;
            }
          } else {
            // Fire when wind-up completes.
            if (now >= e.__pendingShotAt) {
              e.lastShot = now;
              e.__pendingShotAt = 0;

              const ang = Math.atan2(dy, dx);
              const spd = e.isBoss ? 5.4 : 4.6;
              const vx = Math.cos(ang) * spd;
              const vy = Math.sin(ang) * spd;

              enemyBullets.push({
                x: e.x + Math.cos(ang) * (e.r + 6),
                y: e.y + Math.sin(ang) * (e.r + 6),
                vx, vy,
                life: e.isBoss ? 1900 : 1500,
                r: e.skin === 'soldier' ? 6 : 5,
                kind: e.skin === 'soldier' ? 'arrow' : 'orb',
                angle: ang
              });
            }
          }
        } else {
          // If the player leaves range, cancel a pending shot so enemies don't
          // "buffer" a shot and fire instantly when you re-enter.
          if (e.__pendingShotAt) e.__pendingShotAt = 0;
        }

        // Tiny RPG melee swing: only when genuinely in melee range,
        // and keep it short so it never looks "stuck".
        if (e.skin === 'orc') {
          // Only swing when truly in contact range (prevents "hitting the air").
          const meleeRange = (e.r + player.r + 2);
          const canSwing = (now - (e.lastMeleeSwing || 0)) > 380;
          if (dist <= meleeRange && canSwing) {
            e.lastMeleeSwing = now;
            e.__intentType = 'melee';
            e.__intentUntil = now + 120;
            e.attackStart = now;
            e.attackUntil = now + 160;
          }
        }

        // Slimes: only play an attack when close enough to actually threaten the player.
        // (Prevents "air swipes" and keeps them from looking stuck.)
        if (e.skin === 'slime') {
          const slimeRange = (e.r + player.r + 6);
          const canSlimeAtk = (now - (e.lastSlimeAtk || 0)) > 520;
          if (dist <= slimeRange && canSlimeAtk) {
            e.lastSlimeAtk = now;
            e.__intentType = 'melee';
            e.__intentUntil = now + 140;
            e.attackStart = now;
            e.attackUntil = now + 260;
          }
        }

      });

      powerups.forEach(p => p.ttl -= dt * 16.67);
      powerups = powerups.filter(p => p.ttl > 0);

      // PLAYER BULLETS â ENEMIES
      bullets.forEach((b) => {
        enemies.forEach((e) => {
          // Many enemies are rendered feet-anchored at (e.x, e.y). Use a lifted
          // hit-center so bullets register on the visible body.
          const hitCY = e.y - (e.hitYOffset || 0);
          const d = distance(b.x, b.y, e.x, hitCY);
          if (d < 4 + e.r) {
            const relY = b.y - hitCY;
            const isHeadshot = relY < -4;
            const baseDmg = (player.bodyDamage ?? player.damage);
            const multiplier = isHeadshot ? (player.headshotMultiplier || 2) : 1;
            const dmg = baseDmg * multiplier;

            e.hp -= dmg;
            // tiny damage number (headshots get a small icon)
            spawnDamageNumber(dmg, e.x, hitCY - e.r, isHeadshot);


            const __tHit = performance.now();


            e.__hitFlashUntil = __tHit + 80;


            e.__hpBarFlashUntil = __tHit + 140;


            spawnDamagePopup(Math.round(dmg), b.x, b.y - 8, isHeadshot);

            if (b.pierce && b.pierce > 0) {
              b.pierce--;
            } else {
              b.life = 0;
            }
          }
        });
      });
      bullets = bullets.filter(b => b.life > 0);

     enemies = enemies.filter(e => {
  if (e.hp <= 0) {

// softer enemy death sound (rate-limited)
try {
  const t = performance.now();
  if (t - lastEnemyDeathSfxAt > 55) {
    lastEnemyDeathSfxAt = t;
    playEnemyDeathSoft();
  }
} catch (e2) {}


// Bounty target reward (from Bounty Protocol event)
if (e && e.__isBounty) {
  const bonusArc = Math.round((e.__bountyValue || 420) * (overdriveActive ? 1.15 : 1));
  points += bonusArc;
  addLifetimeArc(bonusArc);
  const heal = e.__bountyHeal || 14;
  player.hp = Math.min(player.maxHp, player.hp + heal);
  showSystemBanner("ð¯ BOUNTY +" + bonusArc.toLocaleString() + " ARC  •  +" + heal + " HP", 3200);
  try { playRewardChime(); } catch(e2) {}
  try { triggerShake(5); } catch(e2) {}
  try { if (networkEvent && networkEvent.type === "bounty_protocol") networkEvent.data.bountyAlive = false; } catch(e2) {}
}


    // Splitter mob: when killed, it pops into a mini-swarm (classic roguelite juice)
    if (e.type === "splitter" && !e.isBoss) {
      for (let i = 0; i < 3; i++) {
        const ox = (Math.random() * 2 - 1) * 18;
        const oy = (Math.random() * 2 - 1) * 18;
        spawnEnemy("swarm", e.x + ox, e.y + oy);
      }
    }

    const nowKill = performance.now();

// PERFECT DASH: kill shortly after dashing = bonus ARC + banner (dopamine)
if (nowKill <= perfectDashWindowEnd) {
  const bonus = 18 + Math.min(18, wave * 2);
  points += bonus;
  addLifetimeArc(bonus);
  spawnArcPopup(bonus, e.x, e.y - 18);
  perfectDashCount += 1;
  renderRunGoalHUD();
  showSystemBanner("â¡ PERFECT DASH +" + bonus + " ARC", 1600);
  triggerShake(3);
  perfectDashWindowEnd = 0; // one proc per dash
}



    // Combo window for fun multikill callouts
    if (nowKill - lastKillTime <= DOUBLE_KILL_WINDOW) {
      killComboCount = (killComboCount || 1) + 1;
    } else {
      killComboCount = 1;
    }
    lastKillTime = nowKill;

    const KILL_TOAST_COOLDOWN = 6500;
// Reduce noisy multi-kill spam: only fire an occasional simple hype banner.
if (killComboCount >= 3 && nowKill - lastKillToastTime >= KILL_TOAST_COOLDOWN) {
  lastKillToastTime = nowKill;
  try {
    if (typeof showSystemBanner === "function") showSystemBanner("⚡ DOUBLE ARC MODE!", 1400);
    else if (typeof showToast === "function") showToast("⚡ DOUBLE ARC MODE!");
  } catch(e) {}
  try { playRewardChime(); } catch(e) {}
}

// === ARC STREAK / MULTIPLIER UPDATE ===
    if (nowKill - arcStreakLastKillTime <= ARC_STREAK_WINDOW) {
      arcStreak += 1;
    } else {
      arcStreak = 1;
    }
    arcStreakLastKillTime = nowKill;
    if (arcStreak > bestArcStreak) bestArcStreak = arcStreak;
    renderRunGoalHUD();

    // multiplier grows with streak but is capped.
    // Economy balance: keep streak rewards fun without letting ARC explode into 100k+ early.
    const streakBonusSteps = Math.min(arcStreak - 1, 9); // 0..9
    arcMultiplier = 1 + streakBonusSteps * 0.08;        // 1.0 -> 1.72 max

    // ARC gain uses multiplier (Blood Moon boosts rewards)

// ARC gain uses multiplier (Blood Moon boosts rewards + Mutations + Network Events)
const baseArcRaw = e.pointsReward;
const baseArc = bloodMoonActive
  ? Math.round(baseArcRaw * 1.25)   // +25% ARC during Blood Moon (keep it hype, not broken)
  : baseArcRaw;

let arcGainMult = 1;

// Mutation: Corrupted Yield = more ARC, but spawns extra mini-swarms sometimes
if (hasMutation("corrupted_yield") && !e.isBoss) {
  arcGainMult *= 1.2;
  if (Math.random() < 0.22) {
    // extra swarm pop (doesn't count as a "splitter" chain)
    const ox = (Math.random() * 2 - 1) * 22;
    const oy = (Math.random() * 2 - 1) * 22;
    spawnEnemy("swarm", e.x + ox, e.y + oy);
  }
}

// Network events: small universal bonus, big ARC Storm bonus
if (networkEvent) arcGainMult *= 1.08;
if (overdriveActive) arcGainMult *= 1.10;
if (networkEvent && networkEvent.type === "arc_storm_DISABLED") {
  arcGainMult *= 1.25;
} else if (networkEvent && networkEvent.type === "portal_breach") {
  arcGainMult *= 1.12;
} else if (networkEvent && networkEvent.type === "bounty_protocol") {
  arcGainMult *= 1.08;
} else if (networkEvent && networkEvent.type === "packet_rush") {
  arcGainMult *= 1.12;
}

// Relic passive: some relics boost ARC from kills.
try {
  if (player && typeof player.arcRelicMult === 'number') {
    arcGainMult *= (1 + Math.max(0, player.arcRelicMult));
  }
} catch(e) {}
const arcGain = Math.round(baseArc * arcMultiplier * arcGainMult);
// Drop ARC as a pickup crate instead of awarding instantly.
spawnArcCrate(e.x, e.y, arcGain);

// Small heart chance if you are missing HP (higher chance when lower).
try {
  const maxHp = (player && typeof player.maxHp === "number") ? player.maxHp : 100;
  const curHp = (player && typeof player.hp === "number") ? player.hp : maxHp;
  const missing = Math.max(0, maxHp - curHp);
  if (missing > 0) {
    const missingRatio = Math.min(1, missing / Math.max(1, maxHp));
    const heartChance = 0.06 + (missingRatio * 0.16); // 6% .. 22%
    if (Math.random() < heartChance) {
      const healAmt = Math.max(10, Math.round(maxHp * 0.04)); // ~4% max HP
      spawnSmallHeart(e.x + (Math.random()*10-5), e.y + (Math.random()*10-5), healAmt);
    }
  }
} catch(_){}

kills += 1;

// crunchy kill confirm tick (pitch climbs with combo)
playKillTick(1, 1 + Math.min(0.8, (killComboCount||1) * 0.07));


const baseXpRaw = e.xpReward;
const xpGain = bloodMoonActive
  ? Math.round(baseXpRaw * 1.4)    // +40% XP during Blood Moon
  : baseXpRaw;
let finalXpGain = xpGain;
try {
  if (player && typeof player.xpRelicMult === 'number') {
    finalXpGain = Math.round(finalXpGain * Math.max(0.1, player.xpRelicMult));
  }
} catch(e) {}
addXP(finalXpGain);


    // wave / rift kill tracking: only count non-boss enemies
    if (!e.isBoss) {
      if (inRift) {
        riftEnemiesKilled++;
      } else {
        waveEnemiesKilled++;
      }
    }

    if (Math.random() < 0.25 || e.isBoss) {
      spawnPowerup(e.x, e.y);
    }
    if (e.isBoss) bossAlive = false;

    if (e.isBoss) {
      // boss defeat dopamine dump
      slowMoTime = Math.max(slowMoTime, 0.45);
      bossPulseAlpha = 1;
      triggerShake(22);
      showToast("BOSS LIQUIDATED");
      playBossPhaseShift();
      // little victory ARC burst
      let bonus = 140 + (wave || 1) * 20;
      if (hasMutation("mev_predator")) bonus = Math.round(bonus * 1.45);
      points += bonus;
      spawnArcPopup(bonus, e.x, e.y);
    }

    return false;
  }
  return true;
});


      enemyBullets.forEach(b => {
  const d = distance(b.x, b.y, player.x, player.y);
  if (!isFinite(d)) return;
  if (d < b.r + player.r) {
    const bulletDamage = bloodMoonActive ? 16 : 10; // +60% during Blood Moon
    player.hp -= bulletDamage;
    resetArcStreakOnHit();
    b.life = 0;
    shakeTime = 180;
    shakeIntensity = 7;
    playGlassBreak();
  }
});

      enemyBullets = enemyBullets.filter(b => b.life > 0);

      enemies.forEach(e => {
  const d = distance(e.x, e.y, player.x, player.y);
  if (!isFinite(d)) return;
  if (d < e.r + player.r) {
    const contactMult = bloodMoonActive ? 1.5 : 1.0; // +50% contact damage
    const base = e.isBoss ? 0.45 * dt : 0.25 * dt;
    player.hp -= base * contactMult * (e.contactDamageMult || 1);
    resetArcStreakOnHit();
    shakeTime = 120;
    shakeIntensity = 6;
  }
});


      if (player.hp <= 0) {
        player.hp = 0;
        handleGameOver();
      }

      powerups = powerups.filter(p => {
        const d = distance(p.x, p.y, player.x, player.y);
        if (d < p.r + player.r + 4) {
          if (p.kind === "health") {
            player.hp = Math.min(player.maxHp, player.hp + 30);
          } else if (p.kind === "heart_small") {
            const heal = (typeof p.heal === "number") ? p.heal : 14;
            player.hp = Math.min(player.maxHp, player.hp + heal);
          } else if (p.kind === "damage") {
            player.damage += 5;
            player.bodyDamage = player.damage;
          } else if (p.kind === "speed") {
            baseMoveSpeed += 0.2;
            player.speed = baseMoveSpeed;
          } else if (p.kind === "xp") {
            xpMultiplier = 2;
            xpBoostActive = true;
            xpBoostEndTime = performance.now() + xpBoostDuration;
            xpBoostWrapper.style.display = "block";
            showToast("DOUBLE XP!");
          } else if (p.kind === "speed2x") {
            speedBoostActive = true;
            speedBoostEndTime = performance.now() + speedBoostDuration;
            player.speed = baseMoveSpeed * 2.1;
            speedBoostWrapper.style.display = "block";
            showToast("SPEED BOOST!");
                    } else if (p.kind === "gear_or_weapon") {
            // Loot boxes no longer swap weapons mid-run.
            // They now act like ARC caches only (clean, readable, dopamine).
            // (Keeps gear/weapon progression in the hub / select screens.)
          }

          // ARC from pickups also respects multiplier
          // Pickup ARC is a small top-up; main ARC should come from kills/clears.
          // (Economy balance: prevents huge spikes when many pickups spawn.)
          // ARC crate pickup: awards stored ARC.
          if (p.kind === "arc_crate") {
            const gain = Math.max(1, Math.round(Number(p.arcValue) || 0));
            points += gain;
            spawnArcPopup(gain, p.x, p.y);
            return false;
          }

          let basePickupArc = 6;
          if (p.kind === "gear_or_weapon") basePickupArc = 18; // ARC cache box
          let pickupArcMult = 1;
          if (networkEvent) pickupArcMult *= 1.10;
          if (overdriveActive) pickupArcMult *= 1.15;
          if (networkEvent && networkEvent.type === "arc_storm_DISABLED") pickupArcMult *= 1.35;
          if (networkEvent && networkEvent.type === "packet_rush") pickupArcMult *= 1.10;
          const pickupArcGain = Math.round(basePickupArc * arcMultiplier * pickupArcMult);
          points += pickupArcGain;
          spawnArcPopup(pickupArcGain, p.x, p.y);

          return false;
        }
        return true;
      });


      // wave- or rift-based enemy spawning & bosses
      if (gameState === "playing") {
        // mid-run chaos events (ARC STORM etc.)
        updateNetworkEvents(dt, now);
        updateDashShockwave(now);
        if (inRift) {
          updateRiftSystem(dt, now);
        } else {
          updateWaveSystem(dt, now);
          // __updateChaosStorm(dt, now); // removed
        }
      }
        // --- Solana portal prompt (works in combat too) ---
        (function syncSolanaPortalPrompt(){
          const rp = document.getElementById('enter-realm-prompt');
          if (!rp) return;
          // Show only when the rift portal is open, player is not already in the rift,
          // and the player is near the portal gate.
          if (riftPortalActive && !inRift) {
            const dDoor = distToRect(player.x, player.y, HUB_DOOR);
            if (dDoor < 120) {
              rp.style.display = 'block';
              return;
            }
          }
          rp.style.display = 'none';
        })();


      // floating damage popups
damagePopups.forEach(p => {
  p.ttl -= dt * 16.67;
  p.y -= (p.vy || 0.05) * dt * 60;
  if (p.vx) {
    p.x += p.vx * dt * 60;
  }
});
damagePopups = damagePopups.filter(p => p.ttl > 0);

// ARC magnet orbs (visual only; ARC already added to points elsewhere)
arcOrbs.forEach(o => {
  o.life -= dt * 16.67;
  if (o.life <= 0) return;

  const toPx = player.x - o.x;
  const toPy = player.y - o.y;
  const dist = Math.hypot(toPx, toPy) || 1;

  // pull strength increases as orb gets closer to player
  const pull = 0.08 + (1 - Math.min(dist / 320, 1)) * 0.18;
  const ax = (toPx / dist) * pull * dt * 60;
  const ay = (toPy / dist) * pull * dt * 60;

  o.vx = (o.vx + ax) * 0.9;
  o.vy = (o.vy + ay) * 0.9;

  o.x += o.vx;
  o.y += o.vy;

  // collected if close to player
  if (dist < 22) {
    o.life = 0;

    // tiny gold spark burst on collect
    for (let i = 0; i < 6; i++) {
      const ang = Math.random() * Math.PI * 2;
      const spd = 1 + Math.random() * 1.6;
      particles.push({
        x: player.x,
        y: player.y,
        vx: Math.cos(ang) * spd,
        vy: Math.sin(ang) * spd,
        life: 14 + Math.random() * 10,
        size: 1.4 + Math.random() * 1.6,
        color: ["#facc15", "#fde68a"][Math.floor(Math.random() * 2)],
        fadeType: "spark"
      });
    }
  }
});
arcOrbs = arcOrbs.filter(o => o.life > 0);

      // move wind lines (Weather FX toggle)
      if (window.arcWeatherEnabled !== false) {
        windLines.forEach(w => {
          w.x += w.vx * dt * 60;
          if (w.x > WORLD_WIDTH / 2 + 520) {
            w.x = WORLD_WIDTH / 2 - 520;
            w.y = WORLD_WIDTH / 2 - 500 + Math.random() * 1000;
          }
        });
      }

      // Close-up camera: adjust camera window by zoom.
      const __z = (typeof ARC_CAMERA_ZOOM === 'number' && isFinite(ARC_CAMERA_ZOOM)) ? ARC_CAMERA_ZOOM : 1;
      const __vw = canvas.width / __z;
      const __vh = canvas.height / __z;
      camera.x = Math.round(player.x - __vw / 2);
      camera.y = Math.round(player.y - __vh / 2);
      camera.x = Math.max(0, Math.min(WORLD_WIDTH - __vw, camera.x));
      camera.y = Math.max(0, Math.min(WORLD_HEIGHT - __vh, camera.y));
// === ARC STREAK TIMER (for the bar) ===
let streakRatio = 0;
if (arcStreak > 0) {
  const elapsed = now - arcStreakLastKillTime;
  const t = 1 - elapsed / ARC_STREAK_WINDOW;
  if (t <= 0) {
    // timer ran out â lose streak & reset multiplier
    arcStreak = 0;
    arcMultiplier = 1;
    streakRatio = 0;
  } else {
    streakRatio = Math.max(0, Math.min(1, t));
  }
}
      levelLabel.textContent = "LVL " + player.level;
pointsLabel.textContent = "ARC: " + points.toLocaleString();
killsLabel.textContent = "Kills: " + kills;
updateBossHUD();
  updateFarmHubHints();


if (arcMultLabel) {
  if (arcStreak <= 1) {
    arcMultLabel.textContent = "ARC x" + arcMultiplier.toFixed(1);
  } else {
    arcMultLabel.textContent =
      "ARC x" + arcMultiplier.toFixed(1) + " (" + arcStreak + ")";
  }
}


      const hpRatio = player.hp / player.maxHp;
      hpBar.style.background = "linear-gradient(90deg, #f97373, #facc15)";
      hpBar.style.transform = "scaleX(" + Math.max(0, hpRatio) + ")";
      hpLabel.textContent = "HP " + Math.round(player.hp) + " / " + player.maxHp;

      const xpRatio = player.xp / player.nextLevelXp;
      xpBar.style.background = "linear-gradient(90deg, #22c55e, #38bdf8)";
      xpBar.style.transform = "scaleX(" + xpRatio + ")";
      xpLabel.textContent = "XP " + player.xp + " / " + player.nextLevelXp;
// ARC streak bar (shows time left to keep multiplier)
if (arcStreakBar && arcStreakLabel) {
  // color: green â yellow as it drains
  if (streakRatio > 0) {
    arcStreakBar.style.background =
      "linear-gradient(90deg, #22c55e, #eab308)";
  } else {
    arcStreakBar.style.background =
      "linear-gradient(90deg, #4b5563, #020617)";
  }

  arcStreakBar.style.transform = "scaleX(" + streakRatio + ")";

  if (arcStreak <= 0 || arcMultiplier <= 1) {
    arcStreakLabel.textContent = "STREAK x1.0";
  } else {
    arcStreakLabel.textContent =
      "STREAK x" + arcMultiplier.toFixed(1) + " (" + arcStreak + ")";
  }
}


      updateAchievements();

      // Removed farm animals; no update needed

      // === CAMERA FOLLOW (HARD GUARANTEE) ===
      // Keep the player centered every frame in both FarmHub and Waves.
      // We do this at the end of update() so no other system can overwrite it.
      // (Fixes: camera not following / player not centered on spawn.)
      try {
        if (camera && player && (gameState === 'playing' || gameState === 'farmHub')) {
          const __z = (typeof ARC_CAMERA_ZOOM === 'number' && isFinite(ARC_CAMERA_ZOOM)) ? ARC_CAMERA_ZOOM : 1;
          const __vw = canvas.width / __z;
          const __vh = canvas.height / __z;
          camera.x = Math.round(player.x - __vw / 2);
          camera.y = Math.round(player.y - __vh / 2);
          camera.x = Math.max(0, Math.min(WORLD_WIDTH - __vw, camera.x));
          camera.y = Math.max(0, Math.min(WORLD_HEIGHT - __vh, camera.y));
        }
      } catch (_) {}
    }

    // Helper to draw the battlefield tiles. We tile the loaded textures across the visible
// portion of the canvas based on the camera. If an image hasn't loaded yet, we skip.
function drawGround() {
  // When camera zoom is active, the canvas is scaled but our world-space math should use
  // the *visible* viewport size in world units (canvas pixels / zoom).
  const __z = (typeof ARC_CAMERA_ZOOM === 'number' && isFinite(ARC_CAMERA_ZOOM)) ? ARC_CAMERA_ZOOM : 1;
  const __vw = canvas.width / __z;
  const __vh = canvas.height / __z;
  // Base fill to avoid blank bands on wide screens
  ctx.fillStyle = "#020617";
  ctx.fillRect(0, 0, __vw, __vh);


  // FARM HUB: override ground tiles ONLY while in farmHub
  if (gameState === "farmHub") {
    drawFarmHubGround();
    return;
  }

  // VOID MAP: deep space floor + twinkling stars + occasional shooting stars.
  if (mapMode === "void") {
    // Background (dark violet)
    ctx.fillStyle = "#02010a";
    ctx.fillRect(0, 0, __vw, __vh);
    // Soft vignette
    ctx.save();
    const grad = ctx.createRadialGradient(canvas.width * 0.5, canvas.height * 0.45, Math.min(canvas.width, canvas.height) * 0.15,
                                          canvas.width * 0.5, canvas.height * 0.5, Math.min(canvas.width, canvas.height) * 0.75);
    grad.addColorStop(0, "rgba(120,58,237,0.10)");
    grad.addColorStop(1, "rgba(0,0,0,0.55)");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, __vw, __vh);
    ctx.restore();

    const t = (performance.now() || 0) / 1000;
    // Stars
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < voidStars.length; i++) {
      const s = voidStars[i];
      const sx = (s.x - camera.x);
      const sy = (s.y - camera.y);
      if (sx < -20 || sy < -20 || sx > canvas.width + 20 || sy > canvas.height + 20) continue;
      const tw = 0.6 + 0.4 * Math.sin(t * 1.2 + s.tw);
      ctx.globalAlpha = s.a * tw;
      ctx.fillStyle = "#e9d5ff";
      ctx.fillRect(sx, sy, s.r, s.r);
    }
    // Shooting stars
    ctx.globalAlpha = 0.85;
    ctx.strokeStyle = "rgba(125,211,252,0.85)";
    ctx.lineWidth = 2;
    for (let i = 0; i < voidShootingStars.length; i++) {
      const st = voidShootingStars[i];
      const x1 = st.x - camera.x;
      const y1 = st.y - camera.y;
      const x2 = (st.x - st.vx * 8) - camera.x;
      const y2 = (st.y - st.vy * 8) - camera.y;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    }
    ctx.restore();
    return;
  }


// DESERT RUINS MAP (after Wave 5): fully tile-rendered (no PNG, no stretching).
if (mapMode === "desert" && desertGround) {
  // draw only visible tiles
  const startCol = Math.floor(camera.x / TILE_SIZE);
  const startRow = Math.floor(camera.y / TILE_SIZE);
  const endCol   = Math.ceil((camera.x + __vw)  / TILE_SIZE);
  const endRow   = Math.ceil((camera.y + __vh) / TILE_SIZE);

  // Choose a few âniceâ tile coords from each sheet.
  // (These are safe defaults for common 10x15 16px tilesheets.)
  const sandChoices = [
    // full, non-edge sand tiles (16px coords in sand.png)
    {c:3,r:13},{c:0,r:14},{c:8,r:12},{c:5,r:12},{c:4,r:14},{c:3,r:14}
  ];
  const sandstoneChoices = [
    // full, non-edge sandstone tiles
    {c:2,r:13},{c:8,r:12},{c:6,r:12},{c:5,r:12},{c:3,r:13},{c:2,r:14}
  ];
  const cobbledChoices = [
    // full, non-edge cobbled sandstone tiles
    {c:1,r:13},{c:7,r:13},{c:2,r:14},{c:8,r:13},{c:0,r:12},{c:3,r:14}
  ];

  for (let row = startRow; row <= endRow; row++) {
    if (row < 0 || row >= DESERT_ROWS) continue;
    for (let col = startCol; col <= endCol; col++) {
      if (col < 0 || col >= DESERT_COLS) continue;

      const worldX = col * TILE_SIZE;
      const worldY = row * TILE_SIZE;
      const sx = worldX - camera.x;
      const sy = worldY - camera.y;

      const t = desertGround[row][col];

      if (t === 1) {
        const pick = sandstoneChoices[(row * 7 + col * 13) % sandstoneChoices.length];
        drawDesertWorldTile(DESERT_SANDSTONE_IMG, pick.c, pick.r, sx, sy);
      } else if (t === 2) {
        const pick = cobbledChoices[(row * 11 + col * 5) % cobbledChoices.length];
        drawDesertWorldTile(DESERT_COBBLED_IMG, pick.c, pick.r, sx, sy);
      } else {
        const pick = sandChoices[(row * 3 + col * 17) % sandChoices.length];
        drawDesertWorldTile(DESERT_SAND_IMG, pick.c, pick.r, sx, sy);
      }
    }
  }

  return;
}

  // WAVE MAP (level_0.png): render ONLY the map art (no side tiles / filler).
  const level0Ready =
    (typeof LEVEL0_IMG !== "undefined") &&
    LEVEL0_IMG &&
    LEVEL0_IMG.complete &&
    LEVEL0_IMG.naturalWidth > 0;

  const level2Ready =
    (typeof LEVEL2_IMG !== "undefined") &&
    LEVEL2_IMG &&
    LEVEL2_IMG.complete &&
    LEVEL2_IMG.naturalWidth > 0;

  const level3Ready =
    (typeof LEVEL3_IMG !== "undefined") &&
    LEVEL3_IMG &&
    LEVEL3_IMG.complete &&
    LEVEL3_IMG.naturalWidth > 0;


  const level5Ready =
    (typeof LEVEL5_IMG !== "undefined") &&
    LEVEL5_IMG &&
    LEVEL5_IMG.complete &&
    LEVEL5_IMG.naturalWidth > 0;

  const level6Ready =
    (typeof LEVEL6_IMG !== "undefined") &&
    LEVEL6_IMG && LEVEL6_IMG.complete && LEVEL6_IMG.naturalWidth > 0;

  const level8Ready =
    (typeof LEVEL8_IMG !== "undefined") &&
    LEVEL8_IMG && LEVEL8_IMG.complete && LEVEL8_IMG.naturalWidth > 0;
  // Select which full-map PNG to render by wave zone.
  const zone = getWaveZone(wave);
  const useLevel8 = (zone === 'level8');
    const useLevel6 = (zone === 'level6');
    const useLevel5 = (zone === 'level5');
const useLevel2 = (zone === 'level2');
  const useLevel3 = (zone === 'level3');

  const ACTIVE_LANE_IMG =
    (useLevel8 && level8Ready) ? LEVEL8_IMG :
    (useLevel6 && level6Ready) ? LEVEL6_IMG :
    (useLevel5 && level5Ready) ? LEVEL5_IMG :
    (useLevel3 && level3Ready) ? LEVEL3_IMG :
    (useLevel2 && level2Ready) ? LEVEL2_IMG :
    LEVEL0_IMG;

  const activeReady =
    useLevel8 ? level8Ready :
    useLevel6 ? level6Ready :
    useLevel5 ? level5Ready :
    useLevel3 ? level3Ready :
    useLevel2 ? level2Ready :
    level0Ready;

  if (gameState === "playing" && activeReady) {
    const sx = Math.max(0, Math.min(ACTIVE_LANE_IMG.naturalWidth, Math.floor(camera.x)));
    const sy = Math.max(0, Math.min(ACTIVE_LANE_IMG.naturalHeight, Math.floor(camera.y)));
    const sw = Math.min(__vw, ACTIVE_LANE_IMG.naturalWidth - sx);
    const sh = Math.min(__vh, ACTIVE_LANE_IMG.naturalHeight - sy);

    // Clear to black for letterboxing (when canvas > map)
    ctx.fillStyle = "#020617";
    ctx.fillRect(0, 0, __vw, __vh);

    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(ACTIVE_LANE_IMG, sx, sy, sw, sh, 0, 0, sw, sh);
    return;
  }

  // Determine visible tile range based on the camera position
  const startCol = Math.floor(camera.x / TILE_SIZE);
  const startRow = Math.floor(camera.y / TILE_SIZE);
  const endCol   = Math.ceil((camera.x + __vw)  / TILE_SIZE);
  const endRow   = Math.ceil((camera.y + __vh) / TILE_SIZE);

  // Precompute tileset source rect for the farm lane
  const middleSrcX = MIDDLE_TILE_COL * TILESET_TILE_SIZE;
  const middleSrcY = MIDDLE_TILE_ROW * TILESET_TILE_SIZE;
  const tilesetReady =
    TILESET_IMG.complete && TILESET_IMG.naturalWidth > 0;

  const useRiftTiles = inRift && riftTiles.length > 0;

  // Use worldRows/worldCols as a repeating pattern, so the field never âruns outâ
  for (let row = startRow; row <= endRow; row++) {
    for (let col = startCol; col <= endCol; col++) {
      // wrap indices into the valid groundMap range
      const wrappedRow = ((row % worldRows) + worldRows) % worldRows;
      const wrappedCol = ((col % worldCols) + worldCols) % worldCols;

      const worldX = col * TILE_SIZE;
      const worldY = row * TILE_SIZE;

      const sx = worldX - camera.x;
      const sy = worldY - camera.y;

      // Decide if this tile is inside the playable middle lane
      const inMiddleLane =
        (worldX + TILE_SIZE > PLAY_MIN_X) &&
        (worldX < PLAY_MAX_X);

      if (useRiftTiles) {
        // Inside SOLANA REALM: repaint everything with Dark Castle tiles
        const tileIndex = groundMap[wrappedRow][wrappedCol];
        const safeIndex = tileIndex % riftTiles.length;
        const img = riftTiles[safeIndex];
        if (!img || !img.complete || img.naturalWidth === 0) continue;

        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(img, sx, sy, TILE_SIZE, TILE_SIZE);
        continue;
      }

      // Normal world: in the middle lane, use the uniform darkâgreen grass tile from grass.png
      const grassReady =
        GRASS_IMG.complete && GRASS_IMG.naturalWidth > 0;

      if (inMiddleLane && grassReady) {
        ctx.imageSmoothingEnabled = false;

        // Wave 1–5: replace the old bridge tiles with the new lane art (level_0.png).
        // level_0.png is aligned to world coords: x=PLAY_MIN_X..PLAY_MAX_X, y=0..WORLD_HEIGHT.
        const level0Ready =
          (typeof LEVEL0_IMG !== "undefined") &&
          LEVEL0_IMG &&
          LEVEL0_IMG.complete &&
          LEVEL0_IMG.naturalWidth > 0;

        if (mapMode !== "desert" && level0Ready) {
          // Sample the correct 32x32 slice from the level art.
          let srcX = Math.floor(worldX - PLAY_MIN_X);
          let srcY = Math.floor(worldY);

          // Clamp to avoid reading outside the image bounds.
          const maxSX = Math.max(0, LEVEL0_IMG.naturalWidth - TILE_SIZE);
          const maxSY = Math.max(0, LEVEL0_IMG.naturalHeight - TILE_SIZE);
          srcX = Math.max(0, Math.min(maxSX, srcX));
          srcY = Math.max(0, Math.min(maxSY, srcY));

          ctx.drawImage(
            LEVEL0_IMG,
            srcX, srcY, TILE_SIZE, TILE_SIZE,
            sx, sy, TILE_SIZE, TILE_SIZE
          );
          continue;
        }

        // Fallback: keep the old bridge-over-water lane if the PNG hasn't loaded yet.
        const h = ((wrappedRow * 73856093) ^ (wrappedCol * 19349663)) >>> 0;
        const pick = h % 4;
        const tile = pick === 0 ? FARM_BRIDGE_A : pick === 1 ? FARM_BRIDGE_B : pick === 2 ? FARM_BRIDGE_C : FARM_BRIDGE_D;

        if (tile && tile.complete && tile.naturalWidth) {
          ctx.drawImage(tile, sx, sy, TILE_SIZE, TILE_SIZE);

          // Rare crop decoration on the bridge edges (visual only)
          if (FARM_CROPS && FARM_CROPS.complete && FARM_CROPS.naturalWidth && (h % 29 === 0)) {
            ctx.globalAlpha = 0.95;
            ctx.drawImage(FARM_CROPS, sx, sy - 8, TILE_SIZE, TILE_SIZE);
            ctx.globalAlpha = 1;
          }
        } else {
          // Fallback to grass if bridge tiles haven't loaded yet
          const srcX = GRASS_FLOOR_COL * GRASS_TILE_SIZE;
          const srcY = GRASS_FLOOR_ROW * GRASS_TILE_SIZE;
          ctx.drawImage(GRASS_IMG, srcX, srcY, GRASS_TILE_SIZE, GRASS_TILE_SIZE, sx, sy, TILE_SIZE, TILE_SIZE);
        }
        continue;
      }


      // Otherwise: use the normal field tiles (existing behaviour)
      const tileIndex = groundMap[wrappedRow][wrappedCol];
      const img = fieldTiles[tileIndex];
      if (!img || !img.complete || img.naturalWidth === 0) continue;

      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(img, sx, sy, TILE_SIZE, TILE_SIZE);
    }
  }
}
// Draw stone walls along the left & right edge of the playable lane.
// Purely visual: collision is still handled via PLAY_MIN_X / PLAY_MAX_X.
// Draw stone walls along the left & right edge of the playable lane.
// Purely visual: collision is still handled via PLAY_MIN_X / PLAY_MAX_X.


    // Render the wandering animals within the farmHub (sprite-based).
    function drawFarmAnimals() {
  // FarmHub animals: sprite-based renderer
  if (typeof drawFarmAnimalsSprites === "function") {
    return drawFarmAnimalsSprites();
  }
}


    // Helper to draw the farm overlay.  We draw the farm image at its world position
    // offset by the camera.  The farm is drawn after the ground but before entities.
    function drawFarm() {
      if (!farmImg || !farmImg.complete || farmImg.naturalWidth === 0) return;
      const sx = farmX - camera.x;
      const sy = farmY - camera.y;
      const drawW = farmWidth;
      const drawH = farmHeight;
      ctx.drawImage(farmImg, sx, sy, drawW, drawH);
    }

        function handleGameOver() {
      if (gameOver) return;
      gameOver = true;
// Add this run into lifetime totals (ARC Terminal uses these)
      addLifetimeArc(points);
      addLifetimeKills(kills);
            gameOverStatsEl.innerHTML =
  'You reached <span style="color:#22d3ee; text-shadow:0 0 12px #22d3ee;">Level ' + player.level + '</span>' +
  ', earned <span style="color:#facc15; text-shadow:0 0 12px #facc15;">' + points.toLocaleString() + ' ARC</span> and ' +
  '<span style="color:#fb923c; text-shadow:0 0 6px #fb923c;">' + kills + ' kills</span>.';
      gameOverEl.style.display = "flex";

      // Fill run summary
      const rs = document.getElementById('run-summary');
      if (rs) rs.innerHTML = buildRunSummaryHTML();


      // Save to leaderboard
      addScoreToLeaderboard({
        wallet: getCurrentWalletLabel(),
        points,
        kills,
        level: player.level
      });
    }


    try { showMutationsHUD(false); } catch(e) {}



    function shootWeapon() {
      // Convert screen mouse coords -> world coords when zoom is active.
      const __zAim = (typeof ARC_CAMERA_ZOOM === 'number' && isFinite(ARC_CAMERA_ZOOM)) ? ARC_CAMERA_ZOOM : 1;
      const worldMouseX = camera.x + (mouseX / __zAim);
      const worldMouseY = camera.y + (mouseY / __zAim);
      const dx = worldMouseX - player.x;
      const dy = worldMouseY - player.y;
      const baseAngle = Math.atan2(dy, dx) || 0;

      const w = player.weapon || getDefaultWeapon();
      const pellets = w.pellets || 1;
      const spread = w.spread || 0;

      for (let i = 0; i < pellets; i++) {
        const offset = (pellets === 1) ? 0 : (i - (pellets - 1) / 2) * spread;
        const angle = baseAngle + offset;
        const vx = Math.cos(angle) * player.bulletSpeed;
        const vy = Math.sin(angle) * player.bulletSpeed;

        bullets.push({
          x: player.x,
          y: player.y,
          vx,
          vy,
          angle,
          life: 600,
          pierce: w.pierce || 0
        });
      }
      playGunshot(1 + (pellets - 1) * 0.1, (w && w.id) || selectedWeaponId);
    }

    // DRAW all
    function draw() {
  // Safety: always reset transform before clearing.
  // If any helper forgets to restore(), a stale transform can leave
  // un-cleared bands (often seen as a black strip at the top).
  try { ctx.setTransform(1, 0, 0, 1, 0, 0); } catch (_) {}
  ctx.clearRect(0, 0, canvas.width, canvas.height);

	  // Close-up camera: zoom the world layer (HUD is HTML, unaffected).
	  const __z = (typeof ARC_CAMERA_ZOOM === 'number' && isFinite(ARC_CAMERA_ZOOM)) ? ARC_CAMERA_ZOOM : 1;
	  // Update global world-unit viewport so helpers can use it safely.
	  __vw = canvas.width / __z;
	  __vh = canvas.height / __z;
  ctx.save();
  ctx.scale(__z, __z);

  // When the camera is allowed to go negative (to keep small maps centered),
  // parts of the viewport can fall outside the world and would otherwise show
  // the page background (often perceived as a "black strip").
  // Paint a base grass tone under everything so the viewport is always filled.
  ctx.fillStyle = "rgb(22, 90, 34)";
  ctx.fillRect(0, 0, __vw + 2, __vh + 2);

  // Draw the battlefield tiles across the entire viewport
  drawGround();

  // Scatter decorative objects on top of the ground
  drawDecorations();

  // Glowing Solana totem statue (farm only)
  if (mapMode !== "desert") drawSolanaTotem();

  // Rift portal (if one is active)
  drawRiftPortal();

  // Next-wave VOID portal (manual transition)
  (function drawNextWaveVoidPortal(){
    if (gameState === "farmHub") return; // FarmHub uses animated portal.gif

    if (!nextWavePortalActive) return;
    const sx = nextWavePortalX - camera.x;
    const sy = nextWavePortalY - camera.y;
    if (sx < -220 || sy < -220 || sx > canvas.width + 220 || sy > canvas.height + 220) return;

    const t = (nextWavePortalPulse || 0);
    const r1 = 56 + Math.sin(t) * 4;
    const r2 = 86 + Math.sin(t * 0.72 + 1.4) * 6;

    ctx.save();
    ctx.globalCompositeOperation = 'lighter';

    // Outer haze
    const g = ctx.createRadialGradient(sx, sy, 10, sx, sy, r2);
    g.addColorStop(0, 'rgba(0,0,0,0)');
    g.addColorStop(0.35, 'rgba(168,85,247,0.18)');
    g.addColorStop(0.7, 'rgba(34,211,238,0.14)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(sx, sy, r2, 0, Math.PI * 2);
    ctx.fill();

    // Ring
    ctx.globalAlpha = 0.9;
    ctx.strokeStyle = 'rgba(168,85,247,0.65)';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(sx, sy, r1, 0, Math.PI * 2);
    ctx.stroke();

    // Inner swirl lines
    ctx.globalAlpha = 0.85;
    ctx.lineWidth = 2;
    for (let i = 0; i < 14; i++) {
      const a = t * 0.7 + (i / 14) * Math.PI * 2;
      const rr = 18 + i * 2.2;
      ctx.strokeStyle = i % 2 ? 'rgba(34,211,238,0.55)' : 'rgba(168,85,247,0.55)';
      ctx.beginPath();
      ctx.arc(sx, sy, rr, a, a + 1.3);
      ctx.stroke();
    }

    ctx.restore();
  })();

  // Farm Hub structures (terminals + Realm Door)
  drawFarmHubStructures();

  // FarmHub: wandering animals (decor only)
  if (gameState === "farmHub") {
    drawFarmAnimals();
  }

  ctx.save();
  if (shakeTime > 0) {
    const s = shakeIntensity * (shakeTime / 180);
    const dx = (Math.random() - 0.5) * s;
    const dy = (Math.random() - 0.5) * s;
    // shake is tuned in screen pixels; divide by zoom so it doesn't become overpowered.
    ctx.translate(dx / __z, dy / __z);
  }
  // wind streaks (Weather FX toggle)
      if (window.arcWeatherEnabled !== false) {
        ctx.strokeStyle = "rgba(209,213,219,0.35)";
        ctx.lineWidth = 1;
        windLines.forEach(w => {
          const sx = w.x - camera.x;
          const sy = w.y - camera.y;
          if (sx < -20 || sy < -20 || sx > canvas.width + 20 || sy > canvas.height + 20) return;
          ctx.beginPath();
          ctx.moveTo(sx, sy);
          ctx.lineTo(sx + 10, sy - 2);
          ctx.stroke();
        });
      }

      // powerups
      powerups.forEach(p => {
        const sx = p.x - camera.x;
        const sy = p.y - camera.y;

        // shadow under the item
        ctx.fillStyle = "rgba(15,23,42,0.85)";
        ctx.beginPath();
        ctx.ellipse(sx, sy + 5, 8, 3, 0, 0, Math.PI * 2);
        ctx.fill();

        // Custom render for ARC crates + small hearts (so they always show even if Treasure.png is blank)
        if (p.kind === "arc_crate") {
          ctx.save();
          ctx.imageSmoothingEnabled = false;
          const s = 18;
          const x0 = sx - s / 2;
          const y0 = sy - s / 2;

          // crate body
          ctx.fillStyle = "rgba(120, 82, 45, 0.95)";
          ctx.fillRect(x0, y0 + 2, s, s - 2);

          // lid
          ctx.fillStyle = "rgba(155, 110, 62, 0.95)";
          ctx.fillRect(x0, y0, s, 6);

          // bands
          ctx.fillStyle = "rgba(25, 25, 25, 0.75)";
          ctx.fillRect(x0 + 3, y0 + 8, s - 6, 2);
          ctx.fillRect(x0 + 3, y0 + 13, s - 6, 2);

          // outline
          ctx.strokeStyle = "rgba(0,0,0,0.75)";
          ctx.strokeRect(x0 + 0.5, y0 + 0.5, s - 1, s - 1);

          ctx.restore();
          return;
        }

        if (p.kind === "heart_small") {
          ctx.save();
          ctx.imageSmoothingEnabled = false;

          const x0 = Math.round(sx);
          const y0 = Math.round(sy) - 2;

          ctx.fillStyle = "rgba(248,113,113,0.95)";
          // lobes
          ctx.fillRect(x0 - 7, y0 - 7, 5, 5);
          ctx.fillRect(x0 + 2, y0 - 7, 5, 5);
          // middle block
          ctx.fillRect(x0 - 8, y0 - 3, 16, 5);
          // taper
          ctx.fillRect(x0 - 6, y0 + 2, 12, 4);
          ctx.fillRect(x0 - 4, y0 + 6, 8, 3);

          ctx.strokeStyle = "rgba(0,0,0,0.55)";
          ctx.strokeRect(x0 - 9 + 0.5, y0 - 8 + 0.5, 18 - 1, 18 - 1);

          ctx.restore();
          return;
        }

        // pick which tile from Treasure.png to use
        // (grid is 16x16 tiles, each 16x16 pixels)
        let tileCol = 0;
        let tileRow = 0;

        // HEALTH: cyan heart (col 9, row 12)
        if (p.kind === "health") {
          tileCol = 9;
          tileRow = 12;

        // XP: white diamond (col 12, row 9)
        } else if (p.kind === "xp") {
          tileCol = 12;
          tileRow = 9;

        // DAMAGE: golden sword (col 8, row 5)
        } else if (p.kind === "damage") {
          tileCol = 8;
          tileRow = 5;

        // SPEED / 2x SPEED: arrow (col 7, row 5)
        } else if (p.kind === "speed" || p.kind === "speed2x") {
          tileCol = 7;
          tileRow = 5;

        // gear_or_weapon or anything else: treasure chest (col 10, row 10)
        } else {
          tileCol = 10;
          tileRow = 10;
        }

        // draw the tile as a crisp pixel icon
        const iconSize = 30; // how big on screen
        const srcX = tileCol * POWERUP_TILE_SIZE;
        const srcY = tileRow * POWERUP_TILE_SIZE;

        ctx.save();
        ctx.imageSmoothingEnabled = false; // keep it pixel-sharp

        // Guard: Treasure.png may be missing; drawing a broken image hard-crashes the frame.
        if (powerupSheetImg && powerupSheetImg.complete && powerupSheetImg.naturalWidth > 0 && powerupSheetImg.naturalHeight > 0) {
          try {
            ctx.drawImage(
              powerupSheetImg,
              srcX, srcY,
              POWERUP_TILE_SIZE, POWERUP_TILE_SIZE,
              sx - iconSize / 2, sy - iconSize / 2,
              iconSize, iconSize
            );
          } catch (e) {
            // If the image is in a broken state, just fall back to a simple icon.
            ctx.fillStyle = "rgba(255,255,255,0.9)";
            ctx.fillRect(sx - iconSize / 2, sy - iconSize / 2, iconSize, iconSize);
            ctx.strokeStyle = "rgba(0,0,0,0.6)";
            ctx.strokeRect(sx - iconSize / 2, sy - iconSize / 2, iconSize, iconSize);
          }
        } else {
          // Fallback icon when spritesheet isn't available
          ctx.fillStyle = "rgba(255,255,255,0.9)";
          ctx.fillRect(sx - iconSize / 2, sy - iconSize / 2, iconSize, iconSize);
          ctx.strokeStyle = "rgba(0,0,0,0.6)";
          ctx.strokeRect(sx - iconSize / 2, sy - iconSize / 2, iconSize, iconSize);
        }

        ctx.restore();
      });
// ARC magnet orbs
      arcOrbs.forEach(o => {
        const sx = o.x - camera.x;
        const sy = o.y - camera.y;
        if (sx < -20 || sy < -20 || sx > canvas.width + 20 || sy > canvas.height + 20) return;

        const t = Math.max(0, o.life / o.maxLife);
        const radius = 4 + o.size * (0.4 + 0.6 * t);

        const grad = ctx.createRadialGradient(sx, sy, 0, sx, sy, radius);
        grad.addColorStop(0, "rgba(250,250,210,0.95)");
        grad.addColorStop(0.4, "rgba(250,204,21,0.9)");
        grad.addColorStop(1, "rgba(250,204,21,0.0)");

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(sx, sy, radius, 0, Math.PI * 2);
        ctx.fill();
      });


      // enemy bullets
      enemyBullets.forEach(b => {
        const sx = b.x - camera.x;
        const sy = b.y - camera.y;

        // Soldier arrows (Tiny RPG pack)
        if (b.kind === 'arrow' && enemyArrowImg && enemyArrowImg.complete && enemyArrowImg.naturalWidth > 0) {
          ctx.save();
          ctx.translate(sx, sy);
          ctx.rotate(b.angle || 0);
          ctx.imageSmoothingEnabled = false;
          const sc = 1.2;
          const w = enemyArrowImg.naturalWidth * sc;
          const h = enemyArrowImg.naturalHeight * sc;
          ctx.drawImage(enemyArrowImg, -w/2, -h/2, w, h);
          ctx.restore();
          return;
        }

        // Default enemy orb
        ctx.fillStyle = "#fecaca";
        ctx.beginPath();
        ctx.arc(sx, sy, (b.r || 4) + 1, 0, Math.PI*2);
        ctx.fill();
      });
      // chaos storm telegraphs (warning circles)
      // __drawChaosStormTelegraphs(); // removed

// enemies
      enemies.forEach(e => {
        const sx = e.x - camera.x;
        const sy = e.y - camera.y;

        // Reset per-frame HUD positioning so old values can't linger when an enemy
        // switches render paths (e.g., different skin/asset states).
        e.__hudBarOffset = undefined;
        e.__hudBarY = undefined;
        e.__didDrawSprite = false;

        // Animate through all frames in the mushroom strip
        // Guard against ENEMY_TOTAL not being declared in certain wave configs.
        const frames = (typeof ENEMY_TOTAL !== 'undefined' ? ENEMY_TOTAL : 0) || 1;
        const animSpeed = 6; // higher = faster animation
        const t = animTime * animSpeed + (e.wobblePhase || 0);
        const frameIndex = Math.floor(t) % frames;

        drawEnemySprite(sx, sy, e, frameIndex);
        // `forEach` callbacks can't use `continue`; just skip the rest of this
        // enemy's HUD/HP bar draw if we didn't actually render a sprite.
        if (!e.__didDrawSprite) { return; }

        const ratio = Math.max(0, Math.min(1, e.hp / (e.maxHp || 1)));

        const nowMs = performance.now();

        // Tiny intent telegraph: a soft pulse + micro icon right before an attack/shot.
        if (e.__intentUntil && nowMs < e.__intentUntil) {
          const frac = Math.max(0, Math.min(1, 1 - (e.__intentUntil - nowMs) / 220));
          const pulse = (Math.sin(frac * Math.PI) * 0.55 + 0.15);
          const rr = (e.r + 10) * (1.0 + frac * 0.18);
          ctx.save();
          ctx.globalAlpha = 0.20 * pulse;
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(Math.round(sx), Math.round(sy), rr, 0, Math.PI * 2);
          ctx.stroke();
          // micro icon above the head
          ctx.globalAlpha = 0.65 * pulse;
          ctx.fillStyle = '#ffffff';
          ctx.font = '10px "Press Start 2P", monospace';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          const icon = (e.__intentType === 'shoot') ? '•' : '!' ;
          ctx.fillText(icon, Math.round(sx), Math.round(sy - (e.__hudBarOffset || (e.r + 20)) - 16));
          ctx.restore();
        }

        // Light "hit flash" ring (very subtle, readable on all maps)
        if (e.__hitFlashUntil && nowMs < e.__hitFlashUntil) {
          const tHit = 1 - (e.__hitFlashUntil - nowMs) / 90;
          ctx.save();
          ctx.globalAlpha = 0.35 * (1 - tHit);
          ctx.strokeStyle = "#ffffff";
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(Math.round(sx), Math.round(sy), (e.r + 6) * (1 + tHit * 0.35), 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();
        }

        // Cleaner enemy HP bar: small, rounded, unobtrusive, and doesn't sit on faces.
        const barW = e.isBoss ? 78 : 26;
        const barH = e.isBoss ? 7 : 4;

        const baseOffset = e.isBoss ? (e.r + 62) : (e.r + 20);
        const barOffset = Math.max(baseOffset, (typeof e.__hudBarOffset === 'number' ? e.__hudBarOffset : 0));
        const barX = Math.round(sx - barW / 2);
        const barY = Math.round(sy - barOffset - 6);

        // fade a bit when full HP so the screen isn't filled with bars
        const fullHpFade = (ratio >= 0.999) ? 0.65 : 0.95;

        // tiny flash on the bar itself
        const barFlash = (e.__hpBarFlashUntil && nowMs < e.__hpBarFlashUntil)
          ? (1 - (e.__hpBarFlashUntil - nowMs) / 140)
          : 0;

        // small rounded-rect helper (fallback if roundRect isn't available)
        function rr(x, y, w, h, r) {
          ctx.beginPath();
          if (ctx.roundRect) {
            ctx.roundRect(x, y, w, h, r);
          } else {
            const r2 = Math.min(r, w / 2, h / 2);
            ctx.moveTo(x + r2, y);
            ctx.arcTo(x + w, y, x + w, y + h, r2);
            ctx.arcTo(x + w, y + h, x, y + h, r2);
            ctx.arcTo(x, y + h, x, y, r2);
            ctx.arcTo(x, y, x + w, y, r2);
            ctx.closePath();
          }
        }

        ctx.save();
        ctx.globalAlpha = fullHpFade;

        // background "pill"
        ctx.fillStyle = "rgba(2,6,23,0.62)";
        ctx.strokeStyle = barFlash ? `rgba(255,255,255,${0.42 * (1 - barFlash)})` : "rgba(255,255,255,0.18)";
        ctx.lineWidth = 1;
        rr(barX, barY, barW, barH, 3);
        ctx.fill();
        ctx.stroke();

        // fill
        const pad = 1;
        const innerW = Math.max(0, Math.round((barW - pad * 2) * ratio));
        if (innerW > 0) {
          const ix = barX + pad;
          const iy = barY + pad;
          const ih = barH - pad * 2;

          // color from red -> green based on HP
          const hue = Math.round(ratio * 120); // 0=red, 120=green
          ctx.fillStyle = `hsl(${hue}, 78%, 48%)`;
          rr(ix, iy, innerW, ih, 2);
          ctx.fill();

          // subtle top shine
          ctx.globalAlpha = fullHpFade * (0.16 + (barFlash ? 0.12 : 0));
          ctx.fillStyle = "#ffffff";
          rr(ix, iy, innerW, Math.max(1, Math.round(ih * 0.45)), 2);
          ctx.fill();
          ctx.globalAlpha = fullHpFade;
        }

        // very light flash overlay
        if (barFlash) {
          ctx.globalAlpha = fullHpFade * 0.26 * (1 - barFlash);
          ctx.fillStyle = "#ffffff";
          rr(barX, barY, barW, barH, 3);
          ctx.fill();
        }

        ctx.restore();
ctx.restore();
      });

      // player bullets
      bullets.forEach(b => {
        const sx = b.x - camera.x;
        const sy = b.y - camera.y;

        ctx.save();
        ctx.translate(sx, sy);
        ctx.rotate(b.angle);

        if (bulletImg.complete && bulletImg.naturalWidth > 0) {
          const scale = 1.2; // tweak this if the bullet looks too big/small
          const w = bulletImg.naturalWidth * scale;
          const h = bulletImg.naturalHeight * scale;

          // draw bullet centered on its position, pointing along b.angle
          ctx.drawImage(
            bulletImg,
            -w / 2,
            -h / 2,
            w,
            h
          );
        } else {
          // fallback: simple line if image isn't loaded yet
          const len = 10;
          ctx.fillStyle = "#e5e7eb";
          ctx.fillRect(-len / 2, -1, len, 2);
        }

        ctx.restore();
      });


      // floating damage numbers
      drawDamagePopups();

      // ambient farmer NPC
      // (Farmer NPC removed)

      // player
            const px = player.x - camera.x;
      const py = player.y - camera.y;
      const moving = (keys["w"] || keys["a"] || keys["s"] || keys["d"]);
      let frameIndex = 0;
      if (moving && gameState === "playing") {
        const t = (animTime * 16.67 / 150) % 2;
        frameIndex = t < 1 ? 1 : 2;
      }

      // draw trail first
      drawPlayerTrail();
      drawPlayerAura(px, py);

      // then player
      drawPlayerSprite(px, py, frameIndex);

      // cinematic leaf overlay
      // drawLeaves(); // Removed as per request
      // biome overlays (vibe)
      drawSnowOverlay();
      drawSandOverlay();

      // slight global darkening so the map is less bright (but UI stays crisp)
      if (!inRift) {
        ctx.save();
        // Dark, spicy film-grade (world only; HUD is HTML so it stays crisp)
        ctx.globalAlpha = 0.20;
        ctx.fillStyle = "#000000";
        ctx.fillRect(0, 0, __vw, __vh);

        // subtle purple/teal tint
        ctx.globalAlpha = 0.08;
        ctx.fillStyle = "rgba(88,28,135,1)";
        ctx.fillRect(0, 0, __vw, __vh);
        ctx.globalAlpha = 0.05;
        ctx.fillStyle = "rgba(14,116,144,1)";
        ctx.fillRect(0, 0, __vw, __vh);

        // vignette (keeps center readable, edges moody)
        const cxv = canvas.width / 2;
        const cyv = canvas.height / 2;
        const rv = Math.max(canvas.width, canvas.height) * 0.78;
        const vg = ctx.createRadialGradient(cxv, cyv, rv * 0.15, cxv, cyv, rv);
        vg.addColorStop(0, "rgba(0,0,0,0)");
        vg.addColorStop(0.62, "rgba(0,0,0,0.10)");
        vg.addColorStop(1, "rgba(0,0,0,0.55)");
        ctx.globalAlpha = 1;
        ctx.fillStyle = vg;
        ctx.fillRect(0, 0, __vw, __vh);
        ctx.restore();
      }

      // Rift visual overlay
      drawRiftOverlay();
// wave start flash overlay
      if (waveFlashAlpha > 0) {
        ctx.save();
        ctx.globalAlpha = waveFlashAlpha;
        const cx = canvas.width / 2;
        const cy = canvas.height / 2;
        const grad = ctx.createRadialGradient(
          cx, cy, 0,
          cx, cy, Math.max(canvas.width, canvas.height)
        );
        grad.addColorStop(0, "rgba(250,204,21,0.35)");
        grad.addColorStop(1, "rgba(0,0,0,0)");

        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, __vw, __vh);
        ctx.restore();
      }

      // VOID warp overlay (entering next wave)
      if (waveWarpActive) {
        ctx.save();
        const a = Math.min(1, Math.max(0, waveWarpT));
        ctx.globalAlpha = 0.85 * a;
        ctx.fillStyle = "rgba(0,0,0,1)";
        ctx.fillRect(0, 0, __vw, __vh);
        // center glow
        const cxw = canvas.width / 2;
        const cyw = canvas.height / 2;
        const gr = ctx.createRadialGradient(cxw, cyw, 0, cxw, cyw, Math.max(canvas.width, canvas.height) * 0.55);
        gr.addColorStop(0, "rgba(168,85,247,0.55)");
        gr.addColorStop(0.35, "rgba(34,211,238,0.22)");
        gr.addColorStop(1, "rgba(0,0,0,0)");
        ctx.globalAlpha = 0.95 * a;
        ctx.fillStyle = gr;
        ctx.fillRect(0, 0, __vw, __vh);
        ctx.restore();
      }

      // ===== BOSS VIGNETTE PULSE =====
      if (bossAlive && bossPulseAlpha > 0) {
        ctx.save();
        const a = Math.max(0, Math.min(1, bossPulseAlpha));
        ctx.globalAlpha = 0.55 * a;
        const cx2 = canvas.width / 2;
        const cy2 = canvas.height / 2;
        const g2 = ctx.createRadialGradient(cx2, cy2, 0, cx2, cy2, Math.max(canvas.width, canvas.height) * 0.72);
        g2.addColorStop(0, "rgba(0,0,0,0)");
        g2.addColorStop(0.55, "rgba(0,0,0,0.12)");
        g2.addColorStop(1, "rgba(236,72,153,0.35)");
        ctx.fillStyle = g2;
        ctx.fillRect(0, 0, __vw, __vh);
        ctx.restore();
        bossPulseAlpha = Math.max(0, bossPulseAlpha - 0.02);
	      }

	      // end of shaken draw layer
	      ctx.restore();
	    
  // FarmHub vibe trigger
  try { maybeTriggerArcPulse(); } catch(_) {}

  // ARC pulse screen bloom
  try { drawArcPulseOverlay(); } catch(_) {}

  // end of camera zoom layer
  ctx.restore();
}


    // ===== TOP ARC PILL (lifetime total) =====
    const totalArcPill = document.getElementById("total-arc-pill");
    function updateTotalArcPill() {
      if (!totalArcPill) return;
      const val = (typeof totalArc === "number" && isFinite(totalArc)) ? Math.floor(totalArc) : 0;
      totalArcPill.textContent = "TOTAL ARC: " + (Number.isFinite(val) ? val : 0).toLocaleString();
      // Hide during intro / menus so it doesn't overlap the cutscene UI.
      const inIntroOrMenu = (gameState === "intro" || gameState === "menu" || gameState === "postIntroMenu");
      totalArcPill.classList.toggle("hidden", inIntroOrMenu);

      // Shop should only be accessible/visible in the Farm Hub.
      const shopBtn = document.getElementById("shop-btn");
      const voidBtn = document.getElementById("void-shop-btn");
      if (shopBtn) shopBtn.style.display = (gameState === "farmHub") ? "block" : "none";
      if (voidBtn) voidBtn.style.display = (gameState === "farmHub") ? "block" : "none";

      const walletWrap = document.getElementById("wallet-connect-wrapper");
      if (walletWrap) walletWrap.style.display = (gameState === "farmHub") ? "block" : "none";

      const lbBtn = document.getElementById("leaderboard-open-btn");
      // FarmHub leaderboard should be a left rail list, not a button.
      if (lbBtn) lbBtn.style.display = "none";
      const hubLB = document.getElementById("hub-leaderboard");
      if (hubLB) hubLB.classList.toggle("hidden", gameState !== "farmHub");
    }

    // ===== MAIN LOOP =====
    function loop(now) {
      const dt = Math.min(2.5, (now - lastTime) / 16.67);
      lastTime = now;

      // Hub NPCs are rendered via a DOM layer (animated GIFs).
      // They must ONLY appear in the Farm Hub *when not in combat*.
      // Some flows keep the player on the farm map while waves are active,
      // so we also gate on the wave counter.
      try {
        const inCombat = (typeof wave === 'number' && wave >= 1);
        if (gameState !== 'farmHub' || inCombat) hideHubNpcDom();
      } catch(_) {}

      update(dt, now);
      updateTotalArcPill();
      draw();
      requestAnimationFrame(loop);
    }

    // init
    initSky();
    initWind();
    initLeaves();
    // Apply saved character selection (Pink / Owlet / Dude) on boot so the
    // player never spawns as the base body unless explicitly chosen.
    try {
      loadSelectedLoadout();
      const cfg = (typeof CHARACTER_CONFIGS !== 'undefined' && Array.isArray(CHARACTER_CONFIGS))
        ? CHARACTER_CONFIGS.find(c => c && c.id === selectedCharacterId)
        : null;
      if (cfg) applyCharacterConfig(cfg);
    } catch(_) {}
    resetPlayer();

    // Start the player in the Farm Hub (centered), then let them enter waves via the portal.
    // This prevents the "spawn in top-left" + camera clamp + black overlay issue.
    try { enterFarmHub(); } catch(e) {
      // Fallback: center in the current world.
      try {
        player.x = WORLD_WIDTH / 2;
        player.y = WORLD_HEIGHT / 2;
        centerCameraOnPlayer(true);
      } catch(_) {}
    }
    requestAnimationFrame(loop);

    // +ARC popup + magnet orbs
function spawnArcPopup(amount, x, y) {
  const numericAmount = Math.round(amount);

  // popup text (value stays numeric, text is the pretty string)
  damagePopups.push({
    x,
    y: y - 20,
    value: numericAmount,
    text: "+" + numericAmount.toLocaleString() + " ARC",
    ttl: 900,
    baseTtl: 900,
    vy: 0.08,
    isArc: true
  });

  // visual ARC orbs (points are already applied elsewhere)
  const orbCount = Math.max(1, Math.min(7, Math.round(numericAmount / 12)));
  for (let i = 0; i < orbCount; i++) {
    const angle = Math.random() * Math.PI * 2;
    const spread = 10 + Math.random() * 28;
    const ox = x + Math.cos(angle) * spread;
    const oy = y + Math.sin(angle) * spread;
    const life = 1600 + Math.random() * 600;

    arcOrbs.push({
      x: ox,
      y: oy,
      vx: (Math.random() - 0.5) * 0.6,
      vy: (Math.random() - 0.5) * 0.6,
      life,
      maxLife: life,
      size: 1 + Math.random() * 1.2
    });
  }
}

    function triggerShake(intensity = 10) {
      screenShake = intensity;
    }

        function spawnLightningBurst(x, y) {
      for (let i = 0; i < 20; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 3 + Math.random() * 5;
        particles.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          life: 25 + Math.random() * 20,
          color: ["#00ffea", "#ffaa00", "#ffff44", "#ff44ff"][Math.floor(Math.random() * 4)],
          size: 2 + Math.random() * 4,
          fadeType: "glow",
        });
      }
      triggerShake(15);
    }


        function spawnNova(x, y) {
      for (let i = 0; i < 50; i++) {
        const angle = (i / 50) * Math.PI * 2;
        const speed = 4 + Math.random() * 5;
        particles.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          life: 45,
          color: i % 3 === 0 ? "#00ffea" : (i % 3 === 1 ? "#ffaa00" : "#ff44ff"),
          size: 4 + Math.random() * 3,
        });
      }
            triggerShake(25);
    }

    // ==========================
    // LEADERBOARD UI WIRING
    // ==========================
    loadLeaderboard();
    renderLeaderboard();

    const leaderboardOverlay = document.getElementById("leaderboard-overlay");
    const leaderboardOpenBtn = document.getElementById("leaderboard-open-btn");
    const leaderboardCloseBtn = document.getElementById("leaderboard-close-btn");

    if (leaderboardOpenBtn && leaderboardOverlay) {
      leaderboardOpenBtn.addEventListener("click", () => {
        leaderboardOverlay.style.display = "flex";
        renderLeaderboard();
      });
    }

    if (leaderboardCloseBtn && leaderboardOverlay) {
      leaderboardCloseBtn.addEventListener("click", () => {
        leaderboardOverlay.style.display = "none";
      });
    }

    // Click outside the inner panel closes too
    if (leaderboardOverlay) {
      leaderboardOverlay.addEventListener('click', (ev) => {
        if (ev.target === leaderboardOverlay) leaderboardOverlay.style.display = 'none';
      });
    }

});


// === PATCH: Robust main menu wiring ===
// Some environments reported the PLAY / SETTINGS buttons not working
// even though the menu renders. To make the menu bulletproof, we
// re-bind the handlers here based purely on DOM attributes and
// minimal assumptions, independent of earlier initialization.

(function () {
  function safeStartCharacterSelect() {
    try {
      if (typeof startCharacterSelect === "function") {
        startCharacterSelect();
        return true;
      }
    } catch (e) {
      console.error("Error starting character select:", e);
    }
    return false;
  }

  function hideMainMenu() {
    try {
      var mm = document.getElementById("main-menu");
      if (mm) {
        mm.style.display = "none";
      }
    } catch (e) {
      console.error("Error hiding main menu:", e);
    }
  }

  function wireMenuButtons() {
    try {
      var playBtn = document.querySelector('[data-action="play"], .menu-btn-left');
      var settingsBtn = document.querySelector('[data-action="settings"], .menu-btn-right');

      if (playBtn) {
        playBtn.addEventListener("click", function () {
          console.log("[PATCH] PLAY clicked");
          // Use existing global handler if present
          if (window.__onMainMenuPlay) {
            try {
              window.__onMainMenuPlay();
              return;
            } catch (e) {
              console.error("Error in existing PLAY handler:", e);
            }
          }
          // Fallback behaviour
          hideMainMenu();
          if (!safeStartCharacterSelect()) {
            console.warn("[PATCH] startCharacterSelect not available yet.");
          }
        }, { once: false });
      }

      if (settingsBtn) {
        settingsBtn.addEventListener("click", function () {
          console.log("[PATCH] SETTINGS clicked");
          if (window.__onMainMenuSettings) {
            try {
              window.__onMainMenuSettings();
              return;
            } catch (e) {
              console.error("Error in existing SETTINGS handler:", e);
            }
          }
          // Fallback: try to trigger any pause/settings button in HUD
          var pauseBtn = document.querySelector('[data-pause-action="settings"], #settings-btn');
          if (pauseBtn) pauseBtn.click();
        }, { once: false });
      }
    } catch (e) {
      console.error("Error wiring patched menu buttons:", e);
    }
  }

  if (document.readyState === "complete" || document.readyState === "interactive") {
    wireMenuButtons();
  } else {
    window.addEventListener("DOMContentLoaded", wireMenuButtons);
  }
})();


// === ULTRA-BASIC MENU WIRING FALLBACK ===
// This is intentionally very simple: it only wires the visible PLAY / SETTINGS
// buttons on the pixel TV menu. Even if other code has issues, this should
// still fire and either call the main handlers or at least show an alert.
(function() {
  function basicWireMenu() {
    try {
      var playBtn = document.querySelector('.menu-btn-pixel.menu-btn-left,[data-action="play"]');
      var settingsBtn = document.querySelector('.menu-btn-pixel.menu-btn-right,[data-action="settings"]');

      if (playBtn && !playBtn.__arcBasicWired) {
        playBtn.__arcBasicWired = true;
        playBtn.addEventListener('click', function() {
          console.log('[BASIC] PLAY clicked');
          if (window.__onMainMenuPlay) {
            window.__onMainMenuPlay();
          } else {
            alert('PLAY clicked (basic fallback handler)');
          }
        });
      }

      if (settingsBtn && !settingsBtn.__arcBasicWired) {
        settingsBtn.__arcBasicWired = true;
        settingsBtn.addEventListener('click', function() {
          console.log('[BASIC] SETTINGS clicked');
          if (window.__onMainMenuSettings) {
            window.__onMainMenuSettings();
          } else {
            alert('SETTINGS clicked (basic fallback handler)');
          }
        });
      }
    } catch (e) {
      console.error('Basic main menu wiring failed:', e);
    }
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    basicWireMenu();
  } else {
    document.addEventListener('DOMContentLoaded', basicWireMenu);
  }
})();
// === SUPER-IMMEDIATE FIRST-CLICK STARTER ===
// First click anywhere on the page: start audio + main intro instantly.
(function () {
  function handleFirstPageClick() {
    try {
      // Make sure audio context is created/resumed
      if (typeof initAudio === 'function') {
        initAudio();
      }

      // If the game hasn't started yet, trigger the PLAY handler
      if (!window.__ARC_GAME_STARTED && typeof window.__onMainMenuPlay === 'function') {
        console.log('[FIRST-CLICK] Forcing __onMainMenuPlay from first page click');
        window.__onMainMenuPlay();
      }
    } catch (e) {
      console.error('[FIRST-CLICK] Error handling first page click', e);
    } finally {
      // Only do this once
      window.removeEventListener('click', handleFirstPageClick);
    }
  }

  // First click ANYWHERE in the window
  window.addEventListener('click', handleFirstPageClick, { once: true });
})();


// Very late fallback: if the game still hasn't started after 8 seconds but
// the main menu is visible and the handler exists, trigger the intro once.
// This is mainly to avoid the "stuck menu" state in edge environments.
setTimeout(function () {
  try {
    var mm = document.getElementById('main-menu');
    if (!window.__ARC_GAME_STARTED && mm && mm.style.display !== 'none' && window.__onMainMenuPlay) {
      console.log('[FALLBACK AUTO] Forcing intro start after timeout');
      window.__onMainMenuPlay();
    }
  } catch (e) {
    console.error('[FALLBACK AUTO] Error trying to auto-start intro', e);
  }
}, 3000);


/**
 * Make the main menu TV/computer clickable to start the intro.
 * PLAY / SETTINGS buttons are hidden; clicking the TV now triggers the same
 * zoom + intro sequence as __onMainMenuPlay.
 */
(function wireTvClickAsPlay() {
  function setupTvClick() {
    try {
      var tvWrapper = document.querySelector('.menu-tv-wrapper');
      if (!tvWrapper) return;

      // Make it obvious it's clickable
      tvWrapper.style.cursor = 'pointer';

      // Avoid double-wiring
      if (tvWrapper.__tvClickWired) return;
      tvWrapper.__tvClickWired = true;

      tvWrapper.addEventListener('click', function (ev) {
        // If the intro has already started, ignore extra clicks
        if (window.__ARC_GAME_STARTED) {
          return;
        }
        if (typeof window.__onMainMenuPlay === 'function') {
          console.log('[TV] Main menu TV clicked â starting intro');
          window.__onMainMenuPlay();
        } else {
          console.warn('[TV] __onMainMenuPlay is not defined yet');
        }
      });
    } catch (e) {
      console.error('[TV] Error wiring TV click for main menu:', e);
    }
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setupTvClick();
  } else {
    document.addEventListener('DOMContentLoaded', setupTvClick);
  }
})();
// =======================
// ARC HUD UPDATE FUNCTION
// =======================
async function updateArcHUD() {
  try {
    const userId = localStorage.getItem("arc_user_id");
    if (!userId) return;

    // If no backend is running, don't spam the console or stall any flow.
    // We'll try once; on failure we disable further polling.
    if (window.__arcHudDisabled) return;

    const res = await fetch(
      `${ARC_API}/status?user_id=${encodeURIComponent(userId)}`,
      { cache: "no-store" }
    );
    if (!res.ok) throw new Error(`ARC HUD HTTP ${res.status}`);
    const data = await res.json();

    const pendingEl = document.getElementById("arc-pending");
    const todayEl = document.getElementById("arc-today");
    const walletEl = document.getElementById("arc-wallet");

    if (pendingEl) pendingEl.textContent = String(data.pending_arc ?? 0);
    if (todayEl)
      todayEl.textContent = `${data.earned_today ?? 0} / ${data.daily_cap ?? 0}`;

    if (walletEl) {
      walletEl.textContent = data.wallet
        ? `Wallet: ${data.wallet.slice(0, 4)}…${data.wallet.slice(-4)}`
        : "Wallet: not linked";
    }
  } catch (e) {
    // Disable further polling on connection failure (common when running frontend only).
    window.__arcHudDisabled = true;
    try { if (window.__arcHudTimer) clearInterval(window.__arcHudTimer); } catch (_) {}
    console.warn("ARC HUD backend not reachable; disabling HUD polling.", e);
  }
}


// ARC HUD polling is OFF by default when running frontend-only.
// Set localStorage.arc_enable_backend = "1" to enable backend polling.
(function(){
  let enableBackend = false;
  try { enableBackend = localStorage.getItem("arc_enable_backend") === "1"; } catch(_) {}
  // If API points at localhost, assume no backend unless explicitly enabled.
  try {
    if (!enableBackend && typeof ARC_API === "string" && ARC_API.includes("localhost")) {
      window.__arcHudDisabled = true;
    }
  } catch(_) {}
  if (window.__arcHudDisabled || !enableBackend) {
    // Do not even attempt a fetch (avoids ERR_CONNECTION_REFUSED spam).
    return;
  }
  try { updateArcHUD(); } catch(_) {}
  try { window.__arcHudTimer = setInterval(updateArcHUD, 3000); } catch(_) {}
})();
// === UI_POLISH_V2: Fullscreen + FX toggle (safe, cosmetic) ===
(function uiPolishV2(){
  function setFxEnabled(enabled){
    try{
      document.body.classList.toggle('fx-off', !enabled);
      localStorage.setItem('fxEnabled', enabled ? '1' : '0');
    }catch(e){}
  }

  async function toggleFullscreen(){
    try{
      if (!document.fullscreenElement) {
        // Fullscreen MUST include the HUD + menus. Request on the document root.
        // Requesting fullscreen on the canvas hides DOM HUD on many browsers.
        const target = document.documentElement || document.body;
        await (target.requestFullscreen
          ? target.requestFullscreen({ navigationUI: 'hide' })
          : document.documentElement.requestFullscreen());
      } else {
        await document.exitFullscreen();
      }
      // Nudge layout so the canvas snaps to the new size
      setTimeout(() => { try { window.dispatchEvent(new Event('resize')); } catch(e) {} }, 60);
    }catch(e){
      console.warn('Fullscreen toggle failed', e);
    }
  }

  // Fullscreen UX: NEVER lock Escape (it traps the player).
  // Instead, keep the button label in sync and let ESC always exit.
  document.addEventListener('fullscreenchange', () => {
    try{
      const fsBtn = document.getElementById('fullscreen-btn');
      if (fsBtn) fsBtn.textContent = document.fullscreenElement ? 'EXIT FULLSCREEN' : 'FULLSCREEN';
    }catch(e){}
  });

  function wire(){
    try{
      // FX setting (scanlines/vignette overlay)
      let fxEnabled = true;
      try{
        const v = localStorage.getItem('fxEnabled');
        if (v === '0') fxEnabled = false;
      }catch(e){}
      setFxEnabled(fxEnabled);

      // Fullscreen button
      const fsBtn = document.getElementById('fullscreen-btn');
      if (fsBtn && !fsBtn.__wired) {
        fsBtn.__wired = true;
        fsBtn.addEventListener('click', (e) => { e.preventDefault(); toggleFullscreen(); });
      }

      // Keyboard shortcuts:
      // G = fullscreen, V = toggle FX overlay (F is reserved for hub door / interactions)
      window.addEventListener('keydown', (ev) => {
        if (ev.repeat) return;
        const k = (ev.key || '').toLowerCase();
        if (k === 'g') {
          ev.preventDefault();
          toggleFullscreen();
          return;
        }
        if (k === 'v') {
          ev.preventDefault();
          const enabled = document.body.classList.contains('fx-off');
          setFxEnabled(enabled); // if it was off, turn on; if on, turn off
        }
      }, { passive: false });
    }catch(e){
      console.warn('uiPolishV2 wire failed', e);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', wire);
  } else {
    wire();
  }
})();


// === PAUSE SYSTEM (ESC only) ===
(function pauseSystem(){
  function ensurePauseOverlay(){
    // Prefer the authored pause overlay in index.html (has buttons/settings).
    // Only create the minimal overlay as a fallback.
    let ov = document.getElementById('pause-overlay');
    if (ov) return ov;

    ov = document.createElement('div');
    ov.id = 'arcPauseOverlay';
    Object.assign(ov.style, {
      position: 'fixed',
      inset: '0',
      display: 'none',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 99999,
      background: 'rgba(0,0,0,0.55)',
      backdropFilter: 'blur(2px)'
    });

    const card = document.createElement('div');
    Object.assign(card.style, {
      minWidth: '260px',
      padding: '18px 18px 14px',
      borderRadius: '14px',
      border: '1px solid rgba(255,255,255,0.12)',
      background: 'rgba(10,10,14,0.88)',
      color: '#fff',
      fontFamily: 'system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif',
      textAlign: 'center',
      boxShadow: '0 14px 40px rgba(0,0,0,0.4)'
    });

    const h = document.createElement('div');
    h.textContent = 'PAUSED';
    Object.assign(h.style, { fontSize: '18px', letterSpacing: '0.12em', marginBottom: '10px', opacity: 0.95 });

    const p = document.createElement('div');
    p.textContent = 'Press ESC to resume';
    Object.assign(p.style, { fontSize: '12px', opacity: 0.75, marginBottom: '12px' });

    const btn = document.createElement('button');
    btn.textContent = 'Resume';
    Object.assign(btn.style, {
      padding: '10px 14px',
      borderRadius: '10px',
      border: '1px solid rgba(255,255,255,0.18)',
      background: 'rgba(255,255,255,0.08)',
      color: '#fff',
      cursor: 'pointer'
    });
    btn.addEventListener('click', () => setPaused(false));

    card.appendChild(h);
    card.appendChild(p);
    card.appendChild(btn);
    ov.appendChild(card);
    document.body.appendChild(ov);
    return ov;
  }

  function setPaused(paused){
    // Only pause during active gameplay (waves)
    window.isPaused = !!paused;

    // If Settings is open, do not show the legacy pause overlay on top.
    // (It can eat clicks and make Settings appear broken.)
    const sp = document.getElementById('settings-panel');
    const settingsOpen = sp && (sp.style.display === 'flex' || sp.style.display === 'block');

    const ov = ensurePauseOverlay();
    ov.style.display = (paused && !settingsOpen) ? 'flex' : 'none';
    try { document.body.classList.toggle('ui-open', !!paused); } catch(e) {}

    // prevent stuck movement if player was holding keys
    if (!paused) return;
    try {
      if (window.__keysRef) {
        Object.keys(window.__keysRef).forEach(k => window.__keysRef[k] = false);
      }
    } catch(e){}
  }

  // Expose for UI hooks if needed
  window.setPaused = setPaused;

  // Capture ESC early and reserve it for pause only
  document.addEventListener('keydown', (ev) => {
    const k = (ev.key || '').toLowerCase();
    if (k !== 'escape') return;

    // If an overlay that expects ESC-to-close is open, close it first.
    // (Leaderboard is modal and freezes gameplay; ESC should never trap the player.)
    const lb = document.getElementById('leaderboard-overlay');
    if (lb && (lb.style.display === 'flex' || lb.style.display === 'block')) {
      ev.preventDefault();
      ev.stopPropagation();
      if (typeof ev.stopImmediatePropagation === 'function') ev.stopImmediatePropagation();
      lb.style.display = 'none';
      return;
    }

    // Settings panel should close before toggling pause
    const sp = document.getElementById('settings-panel');
    if (sp && (sp.style.display === 'flex' || sp.style.display === 'block')) {
      ev.preventDefault();
      ev.stopPropagation();
      if (typeof ev.stopImmediatePropagation === 'function') ev.stopImmediatePropagation();
      // Close settings properly (restores aim/shoot input by clearing ui-open when appropriate)
      try {
        if (typeof window.__closeSettingsPanel === 'function') window.__closeSettingsPanel({ resume: true });
        else sp.style.display = 'none';
      } catch(_) { sp.style.display = 'none'; }
      return;
    }

    // Reserve ESC exclusively for pause toggle
    ev.preventDefault();
    ev.stopPropagation();
    if (typeof ev.stopImmediatePropagation === 'function') ev.stopImmediatePropagation();

    // Toggle pause
    setPaused(!window.isPaused);
  }, { capture: true, passive: false });

  // ESC often exits pointer-lock/fullscreen without emitting a keydown event.
  // Pause reliably when we detect the lock/fullscreen being exited.
  (function wirePointerLockPause(){
    function mainMenuVisible(){
      try {
        const mm = document.getElementById('main-menu');
        if (!mm) return false;
        const st = getComputedStyle(mm);
        return st.display !== 'none' && st.visibility !== 'hidden' && st.opacity !== '0';
      } catch(e) { return false; }
    }
    function pauseIfInRun(){
      try {
        if (window.isPaused) return;
        if (mainMenuVisible()) return;
        setPaused(true);
      } catch(e) {}
    }
    let wasLocked = false;
    function isLocked(){
      const el = document.pointerLockElement;
      if (!el) return false;
      return el === document.getElementById('game');
    }
    // Initialize state
    try { wasLocked = isLocked(); } catch(e) {}
    document.addEventListener('pointerlockchange', () => {
      try {
        const locked = isLocked();
        if (wasLocked && !locked) pauseIfInRun();
        wasLocked = locked;
      } catch(e) {}
    }, true);
    document.addEventListener('fullscreenchange', () => {
      try {
        if (!document.fullscreenElement) pauseIfInRun();
      } catch(e) {}
    }, true);
  })();
})();




// Boot Mutation HUD refs
window.addEventListener('load', () => {
  try { initMutationsHUD(); renderMutationsHUD(); } catch(e) {}
});


// Help overlay (H)
(function wireHelpOverlay(){
  function toggleHelp(){
    const el = document.getElementById('help-overlay');
    if (!el) return;
    el.style.display = (el.style.display === 'flex') ? 'none' : 'flex';
  }
  window.addEventListener('keydown', (ev) => {
    if (ev.repeat) return;
    const k = (ev.key || '').toLowerCase();
    if (k === 'h') {
      ev.preventDefault();
      toggleHelp();
    }
  }, true);
})();


// =========================
// SHOP (Full-screen UI overlay)
// Spend TOTAL ARC on relic packs, upgrades, cosmetics, and consumables.
// =========================
(function wireShopOverlay(){
  const SHOP_SAVE_KEY = 'arc_shop_v1';

  const RARITIES = ['COMMON','RARE','SUPER RARE','EPIC','LEGENDARY'];

  window.rarityClass = function rarityClass(r){
    switch(r){
      case 'COMMON': return 'rar-common';
      case 'RARE': return 'rar-rare';
      case 'SUPER RARE': return 'rar-super';
      case 'EPIC': return 'rar-epic';
      case 'LEGENDARY': return 'rar-legendary';
      default: return '';
    }
  }

  const PACKS = [
    {
      id: 'starter',
      name: 'Starter Relic Pack',
      cost: 2000,
      odds: { 'COMMON': 0.78, 'RARE': 0.18, 'SUPER RARE': 0.035, 'EPIC': 0.0045, 'LEGENDARY': 0.0005 }
    },
    {
      id: 'rising',
      name: 'Rising Relic Pack',
      cost: 6000,
      odds: { 'COMMON': 0.60, 'RARE': 0.28, 'SUPER RARE': 0.09, 'EPIC': 0.025, 'LEGENDARY': 0.005 }
    },
    {
      id: 'epic',
      name: 'Epic Relic Pack',
      cost: 20000,
      odds: { 'COMMON': 0.30, 'RARE': 0.35, 'SUPER RARE': 0.22, 'EPIC': 0.11, 'LEGENDARY': 0.02 }
    },
    {
      id: 'legend',
      name: 'Legend Relic Pack',
      cost: 60000,
      odds: { 'COMMON': 0.10, 'RARE': 0.25, 'SUPER RARE': 0.30, 'EPIC': 0.25, 'LEGENDARY': 0.10 }
    }
  ];

  const RELIC_POOLS = {
    'COMMON': ['Rusty Charm','Farm Token','Old Coin','Lucky Seed','Copper Sigil'],
    'RARE': ['Arc Prism','Wind Rune','Harvest Crest','Silver Sigil','Star Map'],
    'SUPER RARE': ['Void Lens','Chrono Sprout','Royal Emblem','Aether Coil','Sol Bloom'],
    'EPIC': ['Rift Heart','Golden Circuit','Eclipse Band','Astral Totem','Neon Relic'],
    'LEGENDARY': ['Genesis Relic','Dragon Warrant','Infinity Crest','World Key','Solana Crown']
  };

  // --- Save state ---
  const state = {
    relics: {}, // name -> { name, rarity, qty }
    consumables: { xp_boost_1run: 0 },
    upgrades: { maxHp: 0, damage: 0, speed: 0 },
    cosmetics: { aura_gold: false },
    ownedCosmetics: {
      aura: { none: true, cyan: true, purple: false, green: false, gold: false },
      trail: { none: true, purple: true, cyan: false, green: false, gold: false },
    }
  };

  function safeParse(raw){ try { return JSON.parse(raw); } catch(e){ return null; } }
  function loadShop(){
    const raw = localStorage.getItem(SHOP_SAVE_KEY);
    if (!raw) return;
    const obj = safeParse(raw);
    if (!obj || typeof obj !== 'object') return;
    if (obj.relics && typeof obj.relics === 'object') state.relics = obj.relics;
    if (obj.consumables && typeof obj.consumables === 'object') state.consumables = Object.assign(state.consumables, obj.consumables);
    if (obj.upgrades && typeof obj.upgrades === 'object') state.upgrades = Object.assign(state.upgrades, obj.upgrades);
    if (obj.cosmetics && typeof obj.cosmetics === 'object') state.cosmetics = Object.assign(state.cosmetics, obj.cosmetics);
    if (obj.ownedCosmetics && typeof obj.ownedCosmetics === 'object') {
      state.ownedCosmetics = state.ownedCosmetics || { aura:{}, trail:{} };
      if (obj.ownedCosmetics.aura && typeof obj.ownedCosmetics.aura === 'object') state.ownedCosmetics.aura = Object.assign(state.ownedCosmetics.aura, obj.ownedCosmetics.aura);
      if (obj.ownedCosmetics.trail && typeof obj.ownedCosmetics.trail === 'object') state.ownedCosmetics.trail = Object.assign(state.ownedCosmetics.trail, obj.ownedCosmetics.trail);
    }
  }
  function saveShop(){
    try {
      localStorage.setItem(SHOP_SAVE_KEY, JSON.stringify(state));
    } catch(e){}
  }
  loadShop();

  // --- Helpers ---
  function getArc(){
    try {
      if (typeof window !== 'undefined' && typeof window.getLifetimeArc === 'function') {
        const v = Math.max(0, Math.floor(window.getLifetimeArc() || 0));
        if (v > 0) return v;
      }
    } catch(e) {}
    // Fallbacks (avoid "TOTAL ARC: 0" regressions)
    try {
      if (typeof window !== 'undefined' && typeof window.totalArc === 'number' && isFinite(window.totalArc)) {
        return Math.max(0, Math.floor(window.totalArc));
      }
      const pill = document.getElementById('total-arc-pill');
      if (pill) {
        const n = parseInt(String(pill.textContent||'').replace(/[^0-9]/g,''), 10);
        if (isFinite(n) && n > 0) return n;
      }
    } catch(e) {}
    return 0;
  }
  function canAfford(cost){ return getArc() >= cost; }
  function spendArc(cost){
    if (typeof spendLifetimeArc === 'function') {
      spendLifetimeArc(cost);
    } else {
      totalArc = Math.max(0, getArc() - cost);
    }
    // sync header + pill immediately
    try {
      const pill = document.getElementById('total-arc-pill');
      if (pill) pill.textContent = 'TOTAL ARC: ' + Math.floor(getArc()).toLocaleString();
    } catch(e) {}
    try { renderArc(); } catch(e) {}
  }
  function playRaritySfx(rarity){
    try{
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      const ctx = playRaritySfx._ctx || (playRaritySfx._ctx = new AC());
      if (ctx.state === 'suspended') ctx.resume().catch(()=>{});
      const now = ctx.currentTime;

      const preset = {
        'COMMON':    { freqs:[220, 330], dur:0.18, gain:0.12 },
        'RARE':      { freqs:[262, 392], dur:0.22, gain:0.14 },
        'SUPER RARE':{ freqs:[294, 440], dur:0.26, gain:0.16 },
        'EPIC':      { freqs:[330, 494], dur:0.30, gain:0.18 },
        'LEGENDARY': { freqs:[392, 587], dur:0.36, gain:0.22 },
      }[rarity] || { freqs:[220], dur:0.18, gain:0.12 };

      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, now);
      g.gain.exponentialRampToValueAtTime(preset.gain, now + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, now + preset.dur);
      g.connect(ctx.destination);

      preset.freqs.forEach((f,i)=>{
        const o = ctx.createOscillator();
        o.type = i===0 ? 'triangle' : 'sine';
        o.frequency.setValueAtTime(f, now);
        o.connect(g);
        o.start(now);
        o.stop(now + preset.dur);
      });
    }catch(e){}
  }


  function rollRarity(odds){
    const r = Math.random();
    let acc = 0;
    for (const key of RARITIES){
      acc += (odds[key] || 0);
      if (r <= acc) return key;
    }
    return 'COMMON';
  }
  function randomFrom(arr){ return arr[Math.floor(Math.random()*arr.length)]; }
  function awardRelic(rarity){
    const name = randomFrom(RELIC_POOLS[rarity] || RELIC_POOLS['COMMON']);
    if (!state.relics[name]) state.relics[name] = { name, rarity, qty: 0 };
    state.relics[name].qty += 1;
    state.relics[name].rarity = rarity;
    saveShop();
    return state.relics[name];
  }

  // --- UI ---
  let overlay = null;
  let packAnim = null;
  let packAnimTitle = null;
  let packAnimReveal = null;
  let packAnimShine = null;
  let packAnimHint = null;
  let packAnimTimers = [];
  let lastOpenLog = [];
  let openedWhilePlaying = false;

  function ensureStyles(){
    if (document.getElementById('shop-overlay-styles')) return;
    const s = document.createElement('style');
    s.id = 'shop-overlay-styles';
    s.textContent = `
      .shop-overlay{
        position:fixed;inset:0;z-index:1000;display:none;align-items:center;justify-content:center;
        background:
          radial-gradient(1200px 700px at 20% 25%, rgba(250,204,21,0.10), transparent 55%),
          radial-gradient(900px 520px at 80% 20%, rgba(244,114,182,0.08), transparent 60%),
          radial-gradient(1200px 760px at 50% 110%, rgba(34,197,94,0.06), transparent 65%),
          rgba(2,6,23,0.70);
        backdrop-filter: blur(8px);
      }

      /* Cozy stall shell */
      .shop-shell{
        position:relative;display:flex;flex-direction:column;
        width:min(1160px,92vw);height:min(720px,88vh);
        border-radius:28px;
        border:1px solid rgba(253,230,138,0.20);
        background:
          radial-gradient(1200px 520px at 15% 0%, rgba(250,204,21,0.12), transparent 60%),
          radial-gradient(900px 520px at 85% 15%, rgba(251,146,60,0.09), transparent 62%),
          linear-gradient(180deg, rgba(34,20,10,0.96), rgba(10,7,6,0.96));
        box-shadow:
          0 34px 140px rgba(0,0,0,0.68),
          0 0 0 1px rgba(253,230,138,0.08) inset,
          0 0 28px rgba(250,204,21,0.06);
        overflow:hidden;
        font-family:'Press Start 2P', monospace;
      }

      /* Lantern glow + cozy vignette */
      .shop-shell:before{
        content:"";
        position:absolute;inset:-20%;
        background:
          radial-gradient(380px 260px at 12% 10%, rgba(250,204,21,0.22), transparent 62%),
          radial-gradient(520px 320px at 18% 12%, rgba(251,146,60,0.10), transparent 70%),
          radial-gradient(900px 620px at 50% 115%, rgba(0,0,0,0.65), transparent 55%);
        pointer-events:none;
        filter: blur(0.2px);
        opacity:0.95;
      }

      /* Dust motes */
      .shop-shell:after{
        content:"";
        position:absolute;inset:0;
        background-image:
          radial-gradient(circle, rgba(255,255,255,0.08) 0 1px, transparent 2px),
          radial-gradient(circle, rgba(255,255,255,0.05) 0 1px, transparent 2px);
        background-size: 180px 180px, 260px 260px;
        background-position: 0 0, 120px 80px;
        mix-blend-mode: screen;
        opacity:0.30;
        pointer-events:none;
        animation: shopDustDrift 12s linear infinite;
      }
      @keyframes shopDustDrift{
        0%{ transform: translate3d(0,0,0); }
        50%{ transform: translate3d(-18px, 10px, 0); }
        100%{ transform: translate3d(0,0,0); }
      }

      .shop-top{
        position:sticky;top:0;z-index:3;
        display:flex;align-items:center;gap:14px;
        padding:16px 18px;
        border-bottom:1px solid rgba(253,230,138,0.12);
        background:
          linear-gradient(180deg, rgba(60,36,18,0.82), rgba(20,12,8,0.35));
        backdrop-filter: blur(10px);
      }

      .shop-lefthead{display:flex;align-items:center;gap:14px;min-width:260px;}
      .shop-title{
        font-size:18px;
        letter-spacing:0.18em;
        color:#fde68a;
        text-shadow: 0 0 18px rgba(250,204,21,0.16);
        text-transform:uppercase;
      }

      .shop-nav{display:flex;gap:10px;align-items:center;flex:1;justify-content:center;flex-wrap:wrap;}

      /* Cozy “pill” tabs */
      .shop-nav .tab{
        font-size:11px;
        padding:10px 12px;
        border-radius:999px;
        border:1px solid rgba(253,230,138,0.18);
        background:
          linear-gradient(180deg, rgba(253,230,138,0.12), rgba(251,146,60,0.04));
        color:#fff7ed;
        cursor:pointer;
        box-shadow: 0 10px 26px rgba(0,0,0,0.35);
      }
      .shop-nav .tab:hover{
        border-color: rgba(253,230,138,0.30);
        filter: brightness(1.05);
        transform: translateY(-1px);
        transition: transform 120ms ease, filter 120ms ease;
      }
      .shop-nav .tab.active{
        border-color: rgba(250,204,21,0.38);
        background: linear-gradient(180deg, rgba(250,204,21,0.18), rgba(251,146,60,0.08));
        color:#fde68a;
      }

      .shop-righthead{display:flex;align-items:center;gap:12px;min-width:260px;justify-content:flex-end;}
      .shop-arc{font-size:12px;color:#e2e8f0;opacity:0.92;}
      .shop-arc.arc-pulse{animation:arcpulse 420ms ease-out;}
      @keyframes arcpulse{0%{transform:scale(1);filter:brightness(1);}40%{transform:scale(1.08);filter:brightness(1.25);}100%{transform:scale(1);filter:brightness(1);}}

      .daily-deal{
        border:1px solid rgba(34,211,238,0.18);
        background:
          radial-gradient(520px 180px at 0% 0%, rgba(34,211,238,0.10), transparent 60%),
          radial-gradient(520px 180px at 100% 0%, rgba(250,204,21,0.10), transparent 60%),
          rgba(2,6,23,0.10);
        border-radius:18px;
        padding:12px;
        margin-bottom:12px;
        box-shadow:0 16px 50px rgba(0,0,0,0.28);
      }
      .daily-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:8px;}
      .daily-badge{font-size:10px;letter-spacing:0.18em;padding:6px 8px;border-radius:999px;border:1px solid rgba(34,211,238,0.22);background:rgba(2,6,23,0.35);color:rgba(226,232,240,0.9);}
      .daily-timer{font-size:10px;color:rgba(226,232,240,0.7);}
      .daily-row{display:flex;align-items:center;justify-content:space-between;gap:10px;}
      .daily-name{font-size:11px;color:#fff7ed;line-height:1.5;}
      .daily-save{font-size:10px;color:#22c55e;opacity:0.9;}

      .shop-close{
        font-size:11px;
        border:1px solid rgba(253,230,138,0.18);
        background: rgba(15,23,42,0.18);
        color:#fff;
        border-radius:14px;
        padding:9px 12px;
        cursor:pointer;
      }
      .shop-close:hover{ background: rgba(15,23,42,0.28); }

      .shop-main{
        flex:1;display:grid;
        grid-template-columns: 410px 1fr;
        gap:16px;
        padding:16px;
        min-height:0;
      }

      /* Table-like cards */
      .shop-card{
        border:1px solid rgba(253,230,138,0.14);
        background:
          radial-gradient(900px 420px at 50% 0%, rgba(250,204,21,0.08), transparent 55%),
          linear-gradient(180deg, rgba(30,18,10,0.55), rgba(10,7,6,0.35));
        border-radius:22px;
        overflow:hidden;
        box-shadow: 0 18px 60px rgba(0,0,0,0.40);
        min-height:0;
      }

      .shop-card-h{
        padding:14px 14px;
        border-bottom:1px solid rgba(253,230,138,0.10);
        font-size:12px;
        letter-spacing:0.18em;
        background: linear-gradient(90deg, rgba(250,204,21,0.10), rgba(251,146,60,0.06));
      }
      .shop-card-h span{
        color:#fde68a;
        text-shadow: 0 0 14px rgba(250,204,21,0.10);
      }

      .shop-packs{
        padding:12px;
        display:flex;
        flex-direction:column;
        gap:12px;
        overflow:auto;
        max-height:100%;
      }

      /* Item “cards” on the table */
      .pack{
        padding:14px 14px 12px;
        border-radius:18px;
        border:1px solid rgba(253,230,138,0.14);
        background:
          linear-gradient(180deg, rgba(2,6,23,0.12), rgba(2,6,23,0.06)),
          radial-gradient(420px 220px at 20% 10%, rgba(250,204,21,0.08), transparent 60%);
        display:flex;
        flex-direction:row;
        gap:12px;
        align-items:flex-start;
        transition: transform 140ms ease, border-color 160ms ease, filter 160ms ease, box-shadow 160ms ease;
        box-shadow: 0 10px 30px rgba(0,0,0,0.28);
      }
      .pack:hover{
        transform: translateY(-2px);
        border-color: rgba(250,204,21,0.28);
        filter: brightness(1.06);
        box-shadow: 0 16px 42px rgba(0,0,0,0.34);
      }

      .pack-icon{
        width:46px;height:46px;border-radius:14px;
        border:1px solid rgba(253,230,138,0.18);
        background:
          radial-gradient(circle at 30% 30%, rgba(250,204,21,0.18), transparent 55%),
          rgba(255,255,255,0.03);
        flex:0 0 auto;
        display:flex;align-items:center;justify-content:center;
        font-size:14px;opacity:0.95;
        box-shadow: 0 10px 24px rgba(0,0,0,0.25);
      }

      .pack-body{flex:1;display:flex;flex-direction:column;gap:6px;}
      .pack-actions{display:flex;flex-direction:column;gap:8px;align-items:flex-end;min-width:120px;}
      .pack-name{font-size:12px;color:#fff7ed;line-height:1.45;}
      .pack-desc{font-size:10px;color:rgba(255,247,237,0.70);line-height:1.65;}
      .pack-row{display:flex;align-items:center;justify-content:space-between;gap:10px;}
      .pack-cost{font-size:11px;color:#a3e635;white-space:nowrap;}

      .pack-btn{
        font-size:11px;
        padding:10px 12px;
        border-radius:14px;
        border:1px solid rgba(250,204,21,0.34);
        background: linear-gradient(180deg, rgba(250,204,21,0.18), rgba(251,146,60,0.08));
        color:#fde68a;
        cursor:pointer;
        box-shadow: 0 14px 34px rgba(0,0,0,0.38);
      }
      .pack-btn:hover{ filter: brightness(1.06); transform: translateY(-1px); transition: transform 120ms ease, filter 120ms ease; }
      .pack-btn[disabled]{opacity:0.45;cursor:not-allowed;filter:saturate(0.8);transform:none;}

      .odds{font-size:10px;color:rgba(255,247,237,0.62);line-height:1.55;}
      .odds span{white-space:nowrap;}
      .odds .sep{color:rgba(255,247,237,0.28);}

      .stash-wrap{display:flex;flex-direction:column;height:100%;}
      .stash-mid{flex:1;display:grid;grid-template-columns: 1.1fr 0.9fr;gap:14px;padding:12px;min-height:0;}

      .stash-box{
        border:1px solid rgba(253,230,138,0.12);
        background: rgba(2,6,23,0.10);
        border-radius:16px;
        padding:12px;
        overflow:auto;
        box-shadow: 0 12px 34px rgba(0,0,0,0.25) inset;
      }
      .stash-title{font-size:12px;color:#fff7ed;margin-bottom:10px;letter-spacing:0.12em;}
      .stash-item{display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px dashed rgba(253,230,138,0.12);font-size:10px;color:#fff7ed;}
      .stash-item:last-child{border-bottom:0;}

      .log{font-size:10px;color:#fff7ed;line-height:1.65;}

      .shop-bottom{display:none;}

      .store{display:flex;gap:10px;overflow:auto;padding-bottom:4px;}
      .store-item{
        min-width:300px;border-radius:16px;
        border:1px solid rgba(253,230,138,0.14);
        background: rgba(2,6,23,0.10);
        padding:12px;
        display:flex;flex-direction:column;gap:10px;
        box-shadow: 0 14px 40px rgba(0,0,0,0.26);
      }
      .si-title{font-size:11px;color:#fff7ed;line-height:1.45;}
      .si-desc{font-size:10px;color:rgba(255,247,237,0.70);line-height:1.65;}
      .si-row{display:flex;align-items:center;justify-content:space-between;gap:10px;}

      .si-buy{
        font-size:11px;padding:10px 12px;border-radius:12px;
        border:1px solid rgba(250,204,21,0.28);
        background: rgba(250,204,21,0.10);
        color:#fde68a;
        cursor:pointer;
      }
      .si-buy:hover{ filter: brightness(1.06); }
      .si-buy[disabled]{opacity:0.45;cursor:not-allowed;}

      .rar-common{color:#d1d5db;}
      .rar-rare{color:#86efac;}
      .rar-super{color:#7dd3fc;}
      .rar-epic{color:#c4b5fd;}
      .rar-legendary{color:#fde68a;text-shadow:0 0 12px rgba(250,204,21,0.20);}

      /* Scrollbar polish */
      .shop-shell,.shop-packs,.stash-box,.store{
        scrollbar-width:thin;
        scrollbar-color:rgba(253,230,138,0.35) rgba(2,6,23,0.25);
      }
      .shop-shell::-webkit-scrollbar,.shop-packs::-webkit-scrollbar,.stash-box::-webkit-scrollbar,.store::-webkit-scrollbar{width:10px;height:10px;}
      .shop-shell::-webkit-scrollbar-track,.shop-packs::-webkit-scrollbar-track,.stash-box::-webkit-scrollbar-track,.store::-webkit-scrollbar-track{background:rgba(2,6,23,0.25);border-radius:999px;}
      .shop-shell::-webkit-scrollbar-thumb,.shop-packs::-webkit-scrollbar-thumb,.stash-box::-webkit-scrollbar-thumb,.store::-webkit-scrollbar-thumb{
        background:linear-gradient(180deg,rgba(253,230,138,0.40),rgba(251,146,60,0.20));
        border:2px solid rgba(2,6,23,0.35);
        border-radius:999px;
      }
      .shop-shell::-webkit-scrollbar-thumb:hover,.shop-packs::-webkit-scrollbar-thumb:hover,.stash-box::-webkit-scrollbar-thumb:hover,.store::-webkit-scrollbar-thumb:hover{
        background:linear-gradient(180deg,rgba(253,230,138,0.55),rgba(251,146,60,0.30));
      }

      /* Pack opening overlay kept (already polished) */
      .pack-open-overlay{position:absolute;inset:0;display:none;align-items:center;justify-content:center;background:radial-gradient(ellipse at center, rgba(2,6,23,0.15) 0%, rgba(2,6,23,0.78) 60%, rgba(2,6,23,0.92) 100%);backdrop-filter: blur(8px);z-index:5;}
      .pack-open-overlay.show{display:flex;}
      .pack-open-card{position:relative;width:min(560px,92vw);border-radius:22px;padding:22px 18px 18px;border:1px solid rgba(148,163,184,0.22);background:linear-gradient(180deg, rgba(15,23,42,0.82), rgba(15,23,42,0.55));box-shadow:0 28px 80px rgba(0,0,0,0.55);overflow:auto;text-align:center;}
      .pack-open-title{font-size:14px;letter-spacing:0.22em;color:#e2e8f0;opacity:0.95;margin-bottom:14px;text-transform:uppercase;}
      .pack-open-reveal{display:flex;flex-direction:column;gap:10px;align-items:center;justify-content:center;padding:6px 10px;}
      .pack-open-reveal .rar{font-size:22px;letter-spacing:0.16em;text-transform:uppercase;text-shadow:0 0 18px rgba(255,255,255,0.10);}
      .pack-open-reveal .relic-name{font-size:20px;color:#fff;letter-spacing:0.06em;}
      .pack-open-reveal .relic-sub{font-size:12px;color:rgba(226,232,240,0.75);letter-spacing:0.08em;}
      .pack-open-hint{margin-top:14px;font-size:11px;color:rgba(226,232,240,0.6);}
      .pack-open-shine{position:absolute;inset:-40%;background:linear-gradient(120deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.10) 30%, rgba(255,255,255,0.0) 60%);transform:translateX(-60%) rotate(12deg);opacity:0;pointer-events:none;}
      .pack-open-shine.pulse{animation:packshine 0.55s ease-out;}
      @keyframes packshine{0%{opacity:0;transform:translateX(-70%) rotate(12deg);}25%{opacity:0.25;}100%{opacity:0;transform:translateX(70%) rotate(12deg);}}
      .shop-card{display:flex;flex-direction:column;}
      .shop-packs{flex:1;min-height:0;}
`;
    document.head.appendChild(s);
  }

  function ensureOverlay(){
    if (overlay) return overlay;
    ensureStyles();

    overlay = document.createElement('div');
    overlay.className = 'shop-overlay';
    overlay.id = 'shop-overlay';

    const shell = document.createElement('div');
    shell.className = 'shop-shell';

    // Pack opening animation layer (above shop UI)
    packAnim = document.createElement('div');
    packAnim.className = 'pack-open-overlay';
    const poc = document.createElement('div');
    poc.className = 'pack-open-card';
    packAnimTitle = document.createElement('div');
    packAnimTitle.className = 'pack-open-title';
    packAnimReveal = document.createElement('div');
    packAnimReveal.className = 'pack-open-reveal';
    packAnimShine = document.createElement('div');
    packAnimShine.className = 'pack-open-shine';
    packAnimHint = document.createElement('div');
    packAnimHint.className = 'pack-open-hint';
    packAnimHint.textContent = 'Click to skip';
    poc.appendChild(packAnimTitle);
    poc.appendChild(packAnimShine);
    poc.appendChild(packAnimReveal);
    poc.appendChild(packAnimHint);
    packAnim.appendChild(poc);
    packAnim.addEventListener('click', () => hidePackAnim(true));

    const top = document.createElement('div');
    top.className = 'shop-top';

    const leftHead = document.createElement('div');
    leftHead.className = 'shop-lefthead';
    const title = document.createElement('div');
    title.className = 'shop-title';
    title.textContent = "WANDERER'S STALL";
    leftHead.appendChild(title);

    const nav = document.createElement('div');
    nav.className = 'shop-nav';
    nav.id = 'shop-nav';

    const rightHead = document.createElement('div');
    rightHead.className = 'shop-righthead';
    const arc = document.createElement('div');
    arc.className = 'shop-arc';
    arc.id = 'shop-arc';
    const close = document.createElement('button');
    close.className = 'shop-close';
    close.type = 'button';
    close.textContent = '✕ Close';
    close.addEventListener('click', () => closeShop());
    rightHead.appendChild(arc);
    rightHead.appendChild(close);

    top.appendChild(leftHead);
    top.appendChild(nav);
    top.appendChild(rightHead);

    const main = document.createElement('div');
    main.className = 'shop-main';

    // Left: packs
    const left = document.createElement('div');
    left.className = 'shop-card';
    const lh = document.createElement('div');
    lh.className = 'shop-card-h';
    lh.innerHTML = '<span id="shop-left-title">RELIC PACKS</span>';
    const packs = document.createElement('div');
    packs.className = 'shop-packs';
    packs.id = 'shop-packs';
    left.appendChild(lh);
    left.appendChild(packs);

    // Right: stash + log
    const right = document.createElement('div');
    right.className = 'shop-card stash-wrap';
    const rh = document.createElement('div');
    rh.className = 'shop-card-h';
    rh.innerHTML = '<span>STASH</span>';
    const stashMid = document.createElement('div');
    stashMid.className = 'stash-mid';

    const stashBox = document.createElement('div');
    stashBox.className = 'stash-box';
    stashBox.id = 'shop-stash';
    const logBox = document.createElement('div');
    logBox.className = 'stash-box';
    logBox.id = 'shop-log';
    stashMid.appendChild(stashBox);
    stashMid.appendChild(logBox);
    right.appendChild(rh);
    right.appendChild(stashMid);

    main.appendChild(left);
    main.appendChild(right);

    // Bottom: tabs store
    const bottom = document.createElement('div');
    bottom.className = 'shop-bottom';
    bottom.style.display = 'none'; // store is rendered in the left panel now
    const store = document.createElement('div');
    store.className = 'store';
    store.id = 'shop-store';

    const tabDefs = [
      { id: 'upgrades', label: 'UPGRADES' },
      { id: 'cosmetics', label: 'COSMETICS' },
      { id: 'consumables', label: 'CONSUMABLES' }
    ];
    tabDefs.forEach((t, idx) => {
      const b = document.createElement('button');
      b.className = 'tab' + (idx===0 ? ' active' : '');
      b.textContent = t.label;
      b.type = 'button';
      b.dataset.tab = t.id;
      b.addEventListener('click', () => setTab(t.id));
      nav.appendChild(b);
    });
    bottom.appendChild(store);

    shell.appendChild(top);
    shell.appendChild(main);
    shell.appendChild(bottom);
    shell.appendChild(packAnim);
    overlay.appendChild(shell);
    document.body.appendChild(overlay);

    renderAll();
    setTab('upgrades');
    return overlay;
  }

  function clearPackAnimTimers(){
    while (packAnimTimers.length) {
      const t = packAnimTimers.pop();
      clearTimeout(t);
    }
  }

  function hidePackAnim(immediate){
    if (!packAnim) return;
    clearPackAnimTimers();
    packAnim.classList.remove('show');
    if (immediate) {
      packAnim.style.display = 'none';
      return;
    }
    // allow a tiny fade-out feel
    packAnimTimers.push(setTimeout(() => {
      if (packAnim) packAnim.style.display = 'none';
    }, 120));
  }

  function fmtOdds(o){
    return RARITIES.map(r => {
      const pct = (100*(o[r]||0)).toFixed(r==='LEGENDARY'?2:1);
      const cls = rarityClass(r);
      return `<span class="${cls}">${r}</span>: ${pct}%`;
    }).join(' • ');
  }
  function showPackAnim(pack, rarity, relic){
    ensureOverlay();
    if (!packAnim) return;
    clearPackAnimTimers();

    // Micro-animations via WAAPI (keeps it smooth without huge CSS changes)
    function animatePop(el){
      try{
        if (!el || !el.animate) return;
        el.animate([
          { transform: 'translateY(8px) scale(0.96)', opacity: 0 },
          { transform: 'translateY(0px) scale(1)', opacity: 1 }
        ], { duration: 320, easing: 'cubic-bezier(.2,.9,.2,1)', fill: 'forwards' });
      }catch(e){}
    }

    function playCheer(){
      try{
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        const ctx = playCheer._ctx || (playCheer._ctx = new AC());
        if (ctx.state === 'suspended') ctx.resume().catch(()=>{});
        const now = ctx.currentTime;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.0001, now);
        g.gain.exponentialRampToValueAtTime(0.18 * (window.arcSfxVolume ?? 1), now + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, now + 0.55);
        g.connect(ctx.destination);

        const notes = [523.25, 659.25, 783.99, 1046.5]; // C5 E5 G5 C6
        notes.forEach((f,i)=>{
          const o = ctx.createOscillator();
          o.type = 'triangle';
          o.frequency.setValueAtTime(f, now + i*0.03);
          o.connect(g);
          o.start(now + i*0.03);
          o.stop(now + 0.55);
        });
      }catch(e){}
    }

    // Reset visuals
    packAnim.classList.remove('rar-common','rar-rare','rar-super','rar-epic','rar-legendary');
    packAnimTitle.textContent = 'OPENING PACK';
    packAnimReveal.innerHTML = `<div class="reveal-top">Please confirm your pull…</div>`;
    packAnim.style.display = 'flex';
    requestAnimationFrame(() => packAnim.classList.add('show'));

    // little "shake & glow" while opening
    try{ animatePop(packAnimReveal); }catch(e){}

    const t1 = setTimeout(() => {
      // Reveal
      const cls = rarityClass(rarity);
      packAnimTitle.textContent = 'YOU PULLED';
      packAnimReveal.innerHTML = `
        <div class="rar ${cls}">${rarity}</div>
        <div class="relic-name">${relic.name}</div>
        <div class="relic-sub">${pack.name}</div>
      `;
      try { playRaritySfx(rarity); } catch(e){}
      try { playCheer(); } catch(e){}
      try { animatePop(packAnimReveal); } catch(e){}
      // Shine pulse
      packAnimShine.classList.add('pulse');
      setTimeout(()=>packAnimShine.classList.remove('pulse'), 520);
    }, 520);

    const t2 = setTimeout(() => hidePackAnim(false), 2200);
    packAnimTimers.push(t1, t2);
  }

  function renderArc(){
    const el = document.getElementById('shop-arc');
    if (!el) return;
    el.textContent = `TOTAL ARC: ${getArc().toLocaleString()}`;
  }


  function renderLeftPanel(){
    // Left panel is context-sensitive:
    // Upgrades -> relic packs, Cosmetics/Consumables -> vertical store list (so tabs feel real).
    if (activeTab === 'upgrades') {
      renderPacks();
      return;
    }

    const el = document.getElementById('shop-packs');
    if (!el) return;
    el.innerHTML = '';

    const items = STORE_ITEMS[activeTab] || [];
    if (!items.length) {
      const empty = document.createElement('div');
      empty.className = 'pack-desc';
      empty.style.padding = '10px';
      empty.textContent = 'Nothing here yet.';
      el.appendChild(empty);
      return;
    }

    // Daily Deal card (one discounted item per day)
    try {
      const deal = getDailyDeal();
      if (deal && !deal.bought && deal.tab === activeTab) {
        const dealItem = (STORE_ITEMS[deal.tab] || []).find(x => x.id === deal.id);
        if (dealItem) {
          const card = document.createElement('div');
          card.className = 'daily-deal';
          const head = document.createElement('div');
          head.className = 'daily-head';
          const badge = document.createElement('div');
          badge.className = 'daily-badge';
          badge.textContent = 'DAILY DEAL';
          const timer = document.createElement('div');
          timer.className = 'daily-timer';
          timer.textContent = `refresh ${fmtCountdown(msToMidnight())}`;
          head.appendChild(badge);
          head.appendChild(timer);
          const row = document.createElement('div');
          row.className = 'daily-row';
          const left = document.createElement('div');
          left.className = 'daily-name';
          left.textContent = dealItem.title;
          const save = document.createElement('div');
          save.className = 'daily-save';
          const newCost = Math.max(1, Math.round(dealItem.cost * (1 - deal.discount)));
          save.textContent = `-${Math.round(deal.discount*100)}% (${newCost} ARC)`;
          row.appendChild(left);
          row.appendChild(save);
          card.appendChild(head);
          card.appendChild(row);

          // Click to buy with discount
          card.style.cursor = canAfford(newCost) ? 'pointer' : 'not-allowed';
          card.style.opacity = canAfford(newCost) ? '1' : '0.55';
          card.addEventListener('click', () => {
            if (!canAfford(newCost)) return;
            buyItem(dealItem, newCost);
            try { showToast && showToast('DAILY DEAL CLAIMED'); } catch(e) {}
          });
          el.appendChild(card);
        }
      }
    } catch(e) {}

    items.forEach(it => {
      const box = document.createElement('div');
      box.className = 'pack';

      const icon = document.createElement('div');
      icon.className = 'pack-icon';
      icon.textContent = (activeTab === 'cosmetics') ? '✧' : '✚';

      const body = document.createElement('div');
      body.className = 'pack-body';

      const actions = document.createElement('div');
      actions.className = 'pack-actions';

      const name = document.createElement('div');
      name.className = 'pack-name';
      name.textContent = it.title;

      const desc = document.createElement('div');
      desc.className = 'pack-desc';
      desc.textContent = it.desc;

      const cost = document.createElement('div');
      cost.className = 'pack-cost';
      cost.textContent = `${it.cost.toLocaleString()} ARC`;

      const btn = document.createElement('button');
      btn.className = 'pack-btn';
      btn.type = 'button';
      const owned = isOwned(it);
      btn.textContent = owned ? 'OWNED' : 'BUY';
      btn.disabled = owned || !canAfford(it.cost);
      btn.addEventListener('click', () => buyItem(it));

      actions.appendChild(cost);
      actions.appendChild(btn);

      body.appendChild(name);
      body.appendChild(desc);

      box.appendChild(icon);
      box.appendChild(body);
      box.appendChild(actions);
      el.appendChild(box);
    });
  }

  function renderPacks(){
    const el = document.getElementById('shop-packs');
    if (!el) return;
    el.innerHTML = '';
    PACKS.forEach(p => {
      const box = document.createElement('div');
      box.className = 'pack';
      const icon = document.createElement('div');
      icon.className = 'pack-icon';
      icon.textContent = '✦';
      const body = document.createElement('div');
      body.className = 'pack-body';
      const actions = document.createElement('div');
      actions.className = 'pack-actions';
      const name = document.createElement('div');
      name.className = 'pack-name';
      name.textContent = p.name;
      const desc = document.createElement('div');
      desc.className = 'pack-desc';
      desc.textContent = (p.id==='starter') ? 'Common-heavy pack. Start your stash.' : (p.id==='rising') ? 'Balanced odds. Better Rare+.' : (p.id==='epic') ? 'High-tier pulls. Epic-ready odds.' : 'Premium pack. Best Legendary chance.';
      const row = document.createElement('div');
      row.className = 'pack-row';
      const cost = document.createElement('div');
      cost.className = 'pack-cost';
      cost.textContent = `${p.cost.toLocaleString()} ARC`;
      const btn = document.createElement('button');
      btn.className = 'pack-btn';
      btn.type = 'button';
      btn.textContent = 'OPEN';
      btn.disabled = !canAfford(p.cost);
      btn.addEventListener('click', () => openPack(p));
      actions.appendChild(cost);
      actions.appendChild(btn);
      const odds = document.createElement('div');
      odds.className = 'odds';
      odds.innerHTML = fmtOdds(p.odds);
      body.appendChild(name);
      body.appendChild(desc);
      body.appendChild(odds);
      box.appendChild(icon);
      box.appendChild(body);
      box.appendChild(actions);
      el.appendChild(box);
    });
  }

  function renderStash(){
    const stashEl = document.getElementById('shop-stash');
    const logEl = document.getElementById('shop-log');
    if (!stashEl || !logEl) return;

    // Build rarity counts
    const counts = { 'COMMON':0,'RARE':0,'SUPER RARE':0,'EPIC':0,'LEGENDARY':0 };
    const relicList = Object.values(state.relics || {});
    relicList.forEach(r => { if (counts[r.rarity] != null) counts[r.rarity] += (r.qty||0); });
    const totalRelics = relicList.reduce((a,r)=>a+(r.qty||0),0);

    stashEl.innerHTML = '';
    const h = document.createElement('div');
    h.className = 'stash-title';
    h.textContent = `STASH • ${totalRelics} RELICS`;
    stashEl.appendChild(h);

    // Rarity summary
    RARITIES.forEach(r => {
      const row = document.createElement('div');
      row.className = 'stash-item';
      row.innerHTML = `<span class="rarity ${rarityClass(r)}">${r}</span><span>${(counts[r]||0)}</span>`;
      stashEl.appendChild(row);
    });

    // Consumables
    const cTitle = document.createElement('div');
    cTitle.className = 'stash-title';
    cTitle.style.marginTop = '14px';
    cTitle.textContent = 'CONSUMABLES';
    stashEl.appendChild(cTitle);
    const cRow = document.createElement('div');
    cRow.className = 'stash-item';
    cRow.innerHTML = `<span class="rarity shop-muted">XP BOOST (1 RUN)</span><span>${state.consumables.xp_boost_1run||0}</span>`;
    stashEl.appendChild(cRow);

    // Log
    function formatLogLine(x){
      // expects 'Pack: RARITY • RelicName'
      const m = x.match(/:\s*(COMMON|RARE|SUPER RARE|EPIC|LEGENDARY)\s*[•·\-‧․]*\s*(.*)$/);
      if (!m) return x;
      const r = m[1];
      const cls = rarityClass(r);
      return x.replace(r, `<span class="${cls}">${r}</span>`);
    }

    logEl.innerHTML = '';
    const lh = document.createElement('div');
    lh.className = 'stash-title';
    lh.textContent = 'OPENING LOG';
    logEl.appendChild(lh);
    const log = document.createElement('div');
    log.className = 'log';
    log.innerHTML = (lastOpenLog.length ? lastOpenLog : ['Open a pack to get your first relic.']).map(x => `• ${formatLogLine(x)}`).join('<br/>');
    logEl.appendChild(log);
  }

  function renderAll(){
    renderArc();
    renderLeftPanel();
    renderStash();
    /* removed auto-scroll */
  }

  let activeTab = 'upgrades';
  function setTab(id){
    activeTab = id;
    try{
      const lt=document.getElementById('shop-left-title');
      if(lt){
        if(id==='upgrades') lt.textContent='RELIC PACKS';
        else if(id==='cosmetics') lt.textContent='COSMETICS STORE';
        else if(id==='consumables') lt.textContent='CONSUMABLES STORE';
      }
    }catch(e){}
    document.querySelectorAll('.shop-nav .tab').forEach(t => {
      t.classList.toggle('active', t.dataset.tab === id);
    });
    renderLeftPanel();
    renderStash();
  }

  const STORE_ITEMS = {
    upgrades: [
      { id:'maxHp', title:'Max HP +5', desc:'Permanent. Increases your max HP by +5 each time you buy it.', cost: 500 },
      { id:'damage', title:'Damage +3%', desc:'Permanent. Small damage multiplier upgrade.', cost: 650 },
      { id:'speed', title:'Move Speed +2%', desc:'Permanent. Small speed multiplier upgrade.', cost: 650 },
    ],
    cosmetics: [
      // IMPORTANT: cosId must match inventory cosmetic IDs (gold/cyan/purple/green)
      { id:'aura_gold', kind:'aura', cosId:'gold', title:'Golden Aura', desc:'Cosmetic. Premium gold glow aura.', cost: 1200 },
      { id:'trail_gold', kind:'trail', cosId:'gold', title:'Gold Trail', desc:'Cosmetic. Dash/ARC trail in gold.', cost: 1500 },
      { id:'aura_cyan', kind:'aura', cosId:'cyan', title:'Cyan Glow Aura', desc:'Cosmetic. Clean neon cyan aura.', cost: 900 },
    ],
    consumables: [
      { id:'xp_boost_1run', title:'XP Booster (1 Run)', desc:'Consumable. Start your next run with DOUBLE XP for 20s.', cost: 400 }
    ]
  };

  function renderStore(){
    const el = document.getElementById('shop-store');
    if (!el) return;
    el.innerHTML = '';
    const st = document.getElementById('shop-store-title');
    if (st) st.textContent = (activeTab || 'upgrades').toUpperCase();
    const items = STORE_ITEMS[activeTab] || [];
    items.forEach(it => {
      const card = document.createElement('div');
      card.className = 'store-item';
      const t = document.createElement('div');
      t.className = 'si-title';
      t.textContent = it.title;
      const d = document.createElement('div');
      d.className = 'si-desc';
      d.textContent = it.desc;
      const row = document.createElement('div');
      row.className = 'si-row';
      const cost = document.createElement('div');
      cost.className = 'pack-cost';
      cost.textContent = `${it.cost.toLocaleString()} ARC`;
      const buy = document.createElement('button');
      buy.className = 'si-buy';
      buy.type = 'button';
      buy.textContent = 'BUY';
      buy.disabled = !canAfford(it.cost) || isOwned(it);
      if (isOwned(it)) buy.textContent = 'OWNED';
      buy.addEventListener('click', () => buyItem(it));
      row.appendChild(cost);
      row.appendChild(buy);
      card.appendChild(t);
      card.appendChild(d);
      card.appendChild(row);
      el.appendChild(card);
    });
  }

  function isOwned(it){
    if (activeTab === 'cosmetics') {
      if (!state.ownedCosmetics) return false;
      if (it.kind === 'aura') return !!state.ownedCosmetics.aura?.[it.cosId];
      if (it.kind === 'trail') return !!state.ownedCosmetics.trail?.[it.cosId];
      return !!state.cosmetics[it.id];
    }
    if (activeTab === 'consumables') return false;
    return false;
  }

  // --- Daily deal (one discounted item per day to make the shop feel "alive")
  function todayKey(){
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  }
  function hashStr(s){
    let h = 2166136261;
    for (let i=0;i<s.length;i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return (h>>>0);
  }
  function getDailyDeal(){
    state.dailyDeal = state.dailyDeal || null;
    const tk = todayKey();
    if (state.dailyDeal && state.dailyDeal.day === tk) return state.dailyDeal;
    const pool = [];
    (STORE_ITEMS.cosmetics||[]).forEach(x => pool.push({tab:'cosmetics', it:x}));
    (STORE_ITEMS.consumables||[]).forEach(x => pool.push({tab:'consumables', it:x}));
    if (!pool.length) return null;
    const seed = hashStr(tk + '|arc_shop');
    const pick = pool[seed % pool.length];
    state.dailyDeal = {
      day: tk,
      tab: pick.tab,
      id: pick.it.id,
      discount: 0.22,
      bought: false
    };
    saveShop();
    return state.dailyDeal;
  }
  function msToMidnight(){
    const d = new Date();
    const n = new Date(d);
    n.setHours(24,0,0,0);
    return Math.max(0, n.getTime() - d.getTime());
  }
  function fmtCountdown(ms){
    const s = Math.floor(ms/1000);
    const hh = String(Math.floor(s/3600)).padStart(2,'0');
    const mm = String(Math.floor((s%3600)/60)).padStart(2,'0');
    const ss = String(s%60).padStart(2,'0');
    return `${hh}:${mm}:${ss}`;
  }

  function buyItem(it, costOverride){
    const deal = getDailyDeal();
    let finalCost = (typeof costOverride === 'number') ? costOverride : it.cost;
    // Apply daily deal discount if it matches this item and not already claimed.
    if (deal && !deal.bought && deal.day === todayKey() && deal.id === it.id) {
      finalCost = Math.max(1, Math.round(it.cost * (1 - deal.discount)));
      deal.bought = true;
      state.dailyDeal = deal;
    }
    if (!canAfford(finalCost)) return;
    spendArc(finalCost);

    if (activeTab === 'upgrades') {
      state.upgrades[it.id] = (state.upgrades[it.id]||0) + 1;
    } else if (activeTab === 'cosmetics') {
      // unlock cosmetics into ownedCosmetics
      state.ownedCosmetics = state.ownedCosmetics || { aura:{}, trail:{} };
      if (it.kind === 'aura') state.ownedCosmetics.aura[it.cosId] = true;
      if (it.kind === 'trail') state.ownedCosmetics.trail[it.cosId] = true;
      state.cosmetics[it.id] = true;
      // If user just bought a cosmetic they currently have equipped as locked, keep equipped.
      try { if (typeof saveCosmetics === 'function') saveCosmetics(); } catch(e) {}
    } else if (activeTab === 'consumables') {
      if (it.id === 'xp_boost_1run') state.consumables.xp_boost_1run = (state.consumables.xp_boost_1run||0) + 1;
    }
    saveShop();
    renderAll();
    try { if (typeof inventoryOpen !== 'undefined' && inventoryOpen && typeof renderInventoryUI === 'function') renderInventoryUI(); } catch(e) {}
    try { playRewardChime && playRewardChime(); } catch(e) {}
    try {
      const arcEl = document.getElementById('shop-arc');
      if (arcEl) { arcEl.classList.remove('arc-pulse'); void arcEl.offsetWidth; arcEl.classList.add('arc-pulse'); }
    } catch(e) {}
  }

  function openPack(pack, confirmed){
    if (!confirmed) {
      const ok = window.confirm(`Open ${pack.name} for ${pack.cost} ARC?`);
      if (!ok) return;
      return openPack(pack, true);
    }
    if (!canAfford(pack.cost)) return;
    spendArc(pack.cost);
    const rarity = rollRarity(pack.odds);
    const relic = awardRelic(rarity);
    // Animation (doesn't block logic)
    try { showPackAnim(pack, rarity, relic); } catch(e) {}
    lastOpenLog.unshift(`${pack.name}: ${rarity} • ${relic.name}`);
    lastOpenLog = lastOpenLog.slice(0, 10);
    renderAll();
  }

  window.ARC_SHOP_STATE = state;

  function openShop(){
    ensureOverlay();
    openedWhilePlaying = (gameState === 'playing');
    if (openedWhilePlaying && typeof window.setPaused === 'function') window.setPaused(true);
    overlay.style.display = 'flex';
    renderAll();
  }
  function closeShop(){
    if (!overlay) return;
    overlay.style.display = 'none';
    if (openedWhilePlaying && typeof window.setPaused === 'function') window.setPaused(false);
    openedWhilePlaying = false;
  }

  // Hook button
  window.addEventListener('load', () => {
    const btn = document.getElementById('shop-btn');
    if (!btn) return;
    btn.addEventListener('click', () => {
      openShop();
    });
  });

  // Expose minimal hooks for future PNG skinning
  function openShopWithTab(tabId){ openShop(); try{ const b = document.querySelector('.shop-nav button[data-tab="'+tabId+'"]'); if (b) b.click(); }catch(e){} }
  window.__shop = { openShop, closeShop, openShopWithTab, state, saveShop, renderAll };
})();

// =========================
// BLACKSMITH FORGE (ARC weapon upgrades) — opens in FarmHub with E
// =========================
(function blacksmithForge(){
  const SAVE_KEY = 'arc_blacksmith_forge_v1';

  // tiers feel "RPG" and unlock higher caps
  const TIERS = [
    { id: 1, name: 'TIER I',  cap: 5,  mult: 1.00 },
    { id: 2, name: 'TIER II', cap: 10, mult: 1.35 },
    { id: 3, name: 'TIER III',cap: 15, mult: 1.80 },
    { id: 4, name: 'TIER IV', cap: 20, mult: 2.40 },
  ];

  const baseCosts = {
    dmg: 120,
    firerate: 140,
    bulletspeed: 110,
    pierce: 180,
    tier: 900,
  };

  const state = {
    tier: 1,
    dmg: 0,
    firerate: 0,
    bulletspeed: 0,
    pierce: 0
  };

  function load(){
    try{
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      const s = JSON.parse(raw);
      if (s && typeof s === 'object'){
        if (Number.isFinite(s.tier)) state.tier = Math.max(1, Math.min(4, Math.floor(s.tier)));
        ['dmg','firerate','bulletspeed','pierce'].forEach(k=>{
          if (Number.isFinite(s[k])) state[k] = Math.max(0, Math.floor(s[k]));
        });
      }
    }catch(e){}
  }
  function save(){
    try{ localStorage.setItem(SAVE_KEY, JSON.stringify(state)); }catch(e){}
  }
  load();

  function tierInfo(){ return TIERS.find(t=>t.id===state.tier) || TIERS[0]; }

  function getTotalArc(){
    return (typeof totalArc === 'number' && isFinite(totalArc)) ? Math.floor(totalArc) : 0;
  }
  function setTotalArc(v){
    try{
      totalArc = Math.max(0, Math.floor(v||0));
      // persist lifetime stats immediately so ARC doesn't desync between UIs
      if (typeof __saveLifetimeStatsNow === 'function') __saveLifetimeStatsNow();
      // update pill if visible
      const pill = document.getElementById('total-arc-pill');
      if (pill) pill.textContent = 'TOTAL ARC: ' + totalArc.toLocaleString();
    }catch(e){}
  }

  function costFor(stat){
    const t = tierInfo();
    const lvl = state[stat] || 0;
    const base = baseCosts[stat] || 200;
    // spicy scaling: early cheap, later expensive
    const scale = 1 + (lvl * 0.28) + (t.mult - 1) * 0.55;
    return Math.max(1, Math.round(base * scale));
  }

  function canBuy(stat){
    const t = tierInfo();
    if (stat === 'tier') return state.tier < 4;
    return (state[stat] || 0) < t.cap;
  }

  function spendArc(n){
    const cur = getTotalArc();
    if (cur < n) return false;
    setTotalArc(cur - n);
    return true;
  }

  // ---- Apply to player stats (called when starting a run / resetting player) ----
  function applyToPlayer(){
    try{
      if (!player) return;
      // clone weapon so we don't mutate the pool
      const w0 = player.weapon || getDefaultWeapon();
      const w = Object.assign({}, w0);

      // Damage: multiplicative for that "feel it" scaling
      const dmgMult = 1 + (state.dmg * 0.045);
      player.damage = Math.round(player.damage * dmgMult);
      player.bodyDamage = player.damage;

      // Fire rate: lower is faster (ms between shots)
      player.fireRate = Math.max(70, Math.round(player.fireRate * (1 - state.firerate * 0.022)));

      // Bullet speed: affects feel a ton
      player.bulletSpeed = (player.bulletSpeed || 8) + state.bulletspeed * 0.55;

      // Pierce: add to weapon
      w.pierce = (w.pierce || 0) + state.pierce;

      player.weapon = w;
    }catch(e){}
  }
  window.__applyBlacksmithToPlayer = applyToPlayer;

  // ---- UI ----
  let overlay=null, card=null, open=false;

  function ensureStyles(){
    if (document.getElementById('forge-ui-styles')) return;
    const s = document.createElement('style');
    s.id='forge-ui-styles';
    s.textContent = `
      .forge-overlay{position:fixed;inset:0;z-index:10050;display:none;align-items:center;justify-content:center;
        background:radial-gradient(900px 520px at 50% 40%, rgba(168,85,247,0.20), rgba(2,6,23,0.88));
        backdrop-filter: blur(8px);}
      .forge-card{width:min(980px,92vw);height:min(680px,90vh);border-radius:28px;overflow:hidden;
        background:linear-gradient(135deg, rgba(15,23,42,0.96), rgba(2,6,23,0.92));
        border:1px solid rgba(168,85,247,0.26);
        box-shadow: 0 40px 120px rgba(0,0,0,0.75), 0 0 0 1px rgba(34,211,238,0.12), 0 0 90px rgba(168,85,247,0.22);
        position:relative;}
      .forge-glow{position:absolute;inset:-120px;pointer-events:none;
        background:radial-gradient(circle at 30% 20%, rgba(34,211,238,0.18), transparent 55%),
                   radial-gradient(circle at 80% 10%, rgba(250,204,21,0.12), transparent 60%),
                   radial-gradient(circle at 50% 70%, rgba(168,85,247,0.22), transparent 62%);
        filter: blur(10px); opacity:0.9;}
      .forge-top{display:flex;align-items:center;justify-content:space-between;padding:18px 18px 12px;position:relative;z-index:2;}
      .forge-title{font-family:'Press Start 2P',system-ui,sans-serif;font-size:18px;letter-spacing:0.08em;color:#facc15;
        text-shadow:0 0 18px rgba(250,204,21,0.25), 0 2px 0 rgba(0,0,0,0.35);}
      .forge-sub{margin-top:6px;font-size:12px;color:rgba(226,232,240,0.85);letter-spacing:0.06em;text-transform:uppercase}
      .forge-pill{display:flex;gap:10px;align-items:center}
      .forge-arc{padding:10px 12px;border-radius:14px;border:1px solid rgba(34,211,238,0.28);background:rgba(2,6,23,0.55);
        color:rgba(226,232,240,0.96);font-family:'Press Start 2P';font-size:10px;letter-spacing:0.06em}
      .forge-close{padding:10px 12px;border-radius:14px;border:1px solid rgba(148,163,184,0.25);background:rgba(148,163,184,0.08);
        color:#e5e7eb;font-family:'Press Start 2P';font-size:10px;cursor:pointer}
      .forge-close:hover{filter:brightness(1.1)}
      .forge-body{display:grid;grid-template-columns: 1.12fr 0.88fr;gap:16px;padding:16px 18px 18px;position:relative;z-index:2;height:calc(100% - 68px);box-sizing:border-box}
      .forge-panel{border-radius:22px;border:1px solid rgba(148,163,184,0.16);background:rgba(2,6,23,0.35);padding:16px;overflow:auto}
      .forge-tierRow{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:14px}
      .forge-tierBadge{padding:10px 12px;border-radius:16px;border:1px solid rgba(250,204,21,0.28);
        background:linear-gradient(180deg, rgba(250,204,21,0.16), rgba(2,6,23,0.10));color:#facc15;font-family:'Press Start 2P';font-size:10px}
      .forge-tierBtn{padding:10px 12px;border-radius:16px;border:1px solid rgba(168,85,247,0.35);
        background:linear-gradient(180deg, rgba(168,85,247,0.22), rgba(2,6,23,0.12));color:#e9d5ff;font-family:'Press Start 2P';font-size:10px;cursor:pointer}
      .forge-tierBtn:disabled{opacity:0.45;cursor:not-allowed}
      .forge-stat{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 12px;border-radius:18px;
        border:1px solid rgba(34,211,238,0.14);background:rgba(2,6,23,0.28);margin-bottom:10px}
      .forge-stat h4{margin:0;font-family:'Press Start 2P';font-size:10px;letter-spacing:0.06em;color:#e5e7eb}
      .forge-stat p{margin:6px 0 0;font-size:11px;color:rgba(226,232,240,0.78)}
      .forge-right{display:flex;align-items:center;gap:10px}
      .forge-cost{font-family:'Press Start 2P';font-size:10px;color:rgba(250,204,21,0.95)}
      .forge-buy{padding:10px 12px;border-radius:14px;border:1px solid rgba(34,211,238,0.32);
        background:linear-gradient(180deg, rgba(34,211,238,0.16), rgba(2,6,23,0.12));color:#67e8f9;font-family:'Press Start 2P';font-size:10px;cursor:pointer}
      .forge-buy:disabled{opacity:0.45;cursor:not-allowed}
      .forge-bar{height:10px;border-radius:999px;background:rgba(148,163,184,0.14);overflow:hidden;margin-top:10px}
      .forge-bar > i{display:block;height:100%;width:0%;background:linear-gradient(90deg, rgba(34,211,238,0.95), rgba(168,85,247,0.95), rgba(250,204,21,0.95));
        box-shadow:0 0 20px rgba(168,85,247,0.18)}
      .forge-mini{font-family:'Press Start 2P';font-size:9px;color:rgba(226,232,240,0.7);letter-spacing:0.08em;line-height:1.5}
      .forge-mini b{color:rgba(250,204,21,0.95)}
    `;
    document.head.appendChild(s);
  }

  function ensureUI(){
    if (overlay) return overlay;
    ensureStyles();
    overlay = document.createElement('div');
    overlay.className = 'forge-overlay';
    overlay.addEventListener('click', (ev)=>{
      if (ev.target === overlay) close();
    });

    card = document.createElement('div');
    card.className = 'forge-card';
    card.innerHTML = `
      <div class="forge-glow"></div>
      <div class="forge-top">
        <div>
          <div class="forge-title">BLACKSMITH FORGE</div>
          <div class="forge-sub">SPEND ARC • HARDEN YOUR WEAPON</div>
        </div>
        <div class="forge-pill">
          <div id="forge-arc" class="forge-arc">ARC: 0</div>
          <button id="forge-close" class="forge-close">CLOSE (E)</button>
        </div>
      </div>
      <div class="forge-body">
        <div class="forge-panel" id="forge-left"></div>
        <div class="forge-panel" id="forge-right">
          <div class="forge-mini">
            <div style="margin-bottom:10px"><b>FORGE TIP:</b> upgrades are GLOBAL and apply to every run.</div>
            <div style="margin-bottom:10px">• DMG makes every bullet hit harder</div>
            <div style="margin-bottom:10px">• FIRE RATE melts waves faster</div>
            <div style="margin-bottom:10px">• BULLET SPEED makes shots feel snappy</div>
            <div style="margin-bottom:10px">• PIERCE punches through mobs</div>
            <div style="opacity:0.85;margin-top:18px">Press <b>E</b> to close anytime.</div>
          </div>
        </div>
      </div>
    `;
    overlay.appendChild(card);
    document.body.appendChild(overlay);

    card.querySelector('#forge-close').addEventListener('click', close);

    // capture-phase hotkey so it works even when body.ui-open blocks other listeners
    document.addEventListener('keydown', (ev)=>{
      if (!open) return;
      const k = (ev.key || '').toLowerCase();
      if (k === 'e' || k === 'escape') {
        ev.preventDefault();
        ev.stopImmediatePropagation();
        close();
      }
    }, true);

    return overlay;
  }

  function statRow(id, title, desc){
    const t = tierInfo();
    const lvl = state[id] || 0;
    const cap = t.cap;
    const pct = Math.max(0, Math.min(100, (lvl / cap) * 100));
    const cost = costFor(id);
    const can = canBuy(id);
    const afford = getTotalArc() >= cost;
    return `
      <div class="forge-stat">
        <div style="flex:1;min-width:0">
          <h4>${title} <span style="opacity:0.65">LV ${lvl}/${cap}</span></h4>
          <p>${desc}</p>
          <div class="forge-bar"><i style="width:${pct}%"></i></div>
        </div>
        <div class="forge-right">
          <div class="forge-cost">${cost.toLocaleString()} ARC</div>
          <button class="forge-buy" data-buy="${id}" ${(!can || !afford) ? 'disabled' : ''}>FORGE</button>
        </div>
      </div>
    `;
  }

  function render(){
    if (!overlay) return;
    const left = overlay.querySelector('#forge-left');
    const arcEl = overlay.querySelector('#forge-arc');
    if (arcEl) arcEl.textContent = 'ARC: ' + getTotalArc().toLocaleString();

    const t = tierInfo();
    const tierCost = Math.round(baseCosts.tier * (1 + (state.tier - 1) * 0.85));
    const tierCan = canBuy('tier');
    const tierAfford = getTotalArc() >= tierCost;

    left.innerHTML = `
      <div class="forge-tierRow">
        <div class="forge-tierBadge">${t.name} • CAP ${t.cap}</div>
        <button class="forge-tierBtn" id="forge-tier-up" ${(!tierCan || !tierAfford) ? 'disabled' : ''}>
          UPGRADE TIER (${tierCost.toLocaleString()} ARC)
        </button>
      </div>
      ${statRow('dmg','DAMAGE','+4.5% damage per level (global).')}
      ${statRow('firerate','FIRE RATE','Faster firing. Lowers time between shots.')}
      ${statRow('bulletspeed','BULLET SPEED','Snappier shots + better hit feel.')}
      ${statRow('pierce','PIERCE','Bullets go through enemies.')}
      <div class="forge-mini" style="margin-top:10px;opacity:0.8">Upgrades save automatically.</div>
    `;

    const tierBtn = left.querySelector('#forge-tier-up');
    if (tierBtn){
      tierBtn.addEventListener('click', ()=>{
        if (!canBuy('tier')) return;
        if (!spendArc(tierCost)) { try{ toastCenter('NOT ENOUGH ARC'); }catch(e){} return; }
        state.tier = Math.min(4, state.tier + 1);
        save();
        render();
        try{ showToast('TIER UP!'); }catch(e){}
      });
    }

    left.querySelectorAll('button[data-buy]').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const stat = btn.getAttribute('data-buy');
        if (!stat) return;
        if (!canBuy(stat)) return;
        const c = costFor(stat);
        if (!spendArc(c)) { try{ toastCenter('NOT ENOUGH ARC'); }catch(e){} return; }
        state[stat] = (state[stat]||0) + 1;
        save();
        render();
        try{ showToast('FORGED: ' + stat.toUpperCase()); }catch(e){}
      });
    });
  }

  function openUI(){
    if (typeof gameState !== 'undefined' && gameState !== 'farmHub'){
      try{ toastCenter('BLACKSMITH: OPEN IN FARM HUB'); }catch(e){}
      return;
    }
    ensureUI();
    open = true;
    overlay.style.display='flex';
    try{ document.body.classList.add('ui-open'); }catch(e){}
    render();
  }

  function close(){
    if (!overlay) return;
    open = false;
    overlay.style.display='none';
    try{ document.body.classList.remove('ui-open'); }catch(e){}
    // prevent stuck movement when closing
    try{ if (window.__keysRef) Object.keys(window.__keysRef).forEach(k=>window.__keysRef[k]=false); }catch(e){}
  }

  window.__forge = { open: openUI, close, state, applyToPlayer };
})();

// =========================
// VOID POINTS (Wave 30 currency) + VOID SHOP overlay
// =========================
(function wireVoidPointsShop(){
  const VOID_SAVE_KEY = 'arc_void_points_v1';
  let voidPoints = 0;
  let awardedThisRun = false;

  function loadVoid(){
    try {
      const raw = localStorage.getItem(VOID_SAVE_KEY);
      if (raw) voidPoints = Math.max(0, parseInt(raw,10) || 0);
    } catch(e){}
  }
  function saveVoid(){
    try { localStorage.setItem(VOID_SAVE_KEY, String(voidPoints)); } catch(e){}
  }
  loadVoid();

  function addVoid(n){
    voidPoints = Math.max(0, voidPoints + (n||0));
    saveVoid();
  }
  function spendVoid(n){
    if (voidPoints < n) return false;
    voidPoints -= n;
    saveVoid();
    return true;
  }

  // Award 1 Void Point when you clear wave 30 (once per run)
  window.awardVoidPointForWave30 = function(w){
    if (awardedThisRun) return;
    if (w === 30) {
      awardedThisRun = true;
      addVoid(1);
      try { showToast("VOID POINT +1"); } catch(e) {}
    }
  };
  window.resetVoidPointRunFlag = function(){ awardedThisRun = false; };
  window.getVoidPoints = function(){ return voidPoints; };

  // UI
  let overlay = null;

  function ensureVoidStyles(){
    if (document.getElementById('void-shop-styles')) return;
    const s = document.createElement('style');
    s.id = 'void-shop-styles';
    s.textContent = `
      .void-overlay{position:fixed;inset:0;z-index:1000;display:none;align-items:center;justify-content:center;background:rgba(2,6,23,0.82);backdrop-filter: blur(8px);}
      .void-shell{width:min(1060px,92vw);height:min(690px,88vh);display:flex;flex-direction:column;border-radius:26px;border:1px solid rgba(168,85,247,0.22);background:
        radial-gradient(900px 420px at 0% 0%, rgba(168,85,247,0.12), transparent 60%),
        radial-gradient(900px 420px at 100% 0%, rgba(20,184,166,0.10), transparent 60%),
        radial-gradient(900px 520px at 50% 100%, rgba(56,189,248,0.08), transparent 65%),
        linear-gradient(180deg,rgba(15,23,42,0.92),rgba(2,6,23,0.94));
        box-shadow:0 36px 140px rgba(0,0,0,0.62);overflow:hidden;font-family:'Press Start 2P', monospace;}
      .void-top{display:flex;align-items:center;justify-content:space-between;padding:18px 20px;border-bottom:1px solid rgba(148,163,184,0.14);backdrop-filter: blur(10px);background:rgba(2,6,23,0.35);}
      .void-title{font-size:22px;letter-spacing:0.14em;background:linear-gradient(90deg,#a855f7,#14b8a6,#facc15);-webkit-background-clip:text;background-clip:text;color:transparent;}
      .void-points{font-size:13px;color:#e2e8f0;}
      .void-close{font-size:12px;border:1px solid rgba(148,163,184,0.25);background:rgba(255,255,255,0.06);color:#fff;border-radius:14px;padding:10px 14px;cursor:pointer;}
      .void-main{flex:1;display:flex;gap:14px;padding:16px;min-height:0;}
      .void-card{flex:1;border:1px solid rgba(148,163,184,0.16);background:rgba(15,23,42,0.55);border-radius:18px;padding:14px;overflow:auto;}
      .void-item{border:1px solid rgba(148,163,184,0.16);background:rgba(2,6,23,0.30);border-radius:16px;padding:12px;margin-bottom:10px;display:flex;flex-direction:row;gap:12px;align-items:flex-start;}
      .void-icon{width:46px;height:46px;border-radius:14px;border:1px solid rgba(168,85,247,0.28);background:rgba(168,85,247,0.10);flex:0 0 auto;display:flex;align-items:center;justify-content:center;font-size:14px;opacity:0.95;}
      .void-body{flex:1;display:flex;flex-direction:column;gap:6px;}
      .void-actions{display:flex;flex-direction:column;gap:8px;align-items:flex-end;min-width:120px;}
      .void-cost{font-size:12px;color:#c4b5fd;background:rgba(168,85,247,0.12);border:1px solid rgba(168,85,247,0.22);padding:6px 8px;border-radius:999px;}
      .void-item:last-child{margin-bottom:0;}
      .void-item .t{font-size:12px;color:#f8fafc;line-height:1.4;}
      .void-item .d{font-size:10px;color:rgba(226,232,240,0.65);line-height:1.6;}
      .void-row{display:flex;align-items:center;justify-content:space-between;gap:10px;}
      .void-cost{font-size:12px;color:#c4b5fd;padding:6px 10px;border-radius:999px;border:1px solid rgba(168,85,247,0.32);background:rgba(168,85,247,0.10);}
      .void-buy{font-size:12px;padding:10px 12px;border-radius:12px;border:1px solid rgba(168,85,247,0.35);background:rgba(168,85,247,0.14);color:#e9d5ff;cursor:pointer;}
      .void-buy[disabled]{opacity:0.4;cursor:not-allowed;}
    
      /* Scrollbar polish */
      .void-shell,.void-left,.void-right{scrollbar-width:thin;scrollbar-color:rgba(148,163,184,0.55) rgba(2,6,23,0.35);}
      .void-shell::-webkit-scrollbar,.void-left::-webkit-scrollbar,.void-right::-webkit-scrollbar{width:10px;height:10px;}
      .void-shell::-webkit-scrollbar-track,.void-left::-webkit-scrollbar-track,.void-right::-webkit-scrollbar-track{background:rgba(2,6,23,0.35);border-radius:999px;}
      .void-shell::-webkit-scrollbar-thumb,.void-left::-webkit-scrollbar-thumb,.void-right::-webkit-scrollbar-thumb{background:linear-gradient(180deg,rgba(148,163,184,0.65),rgba(30,41,59,0.75));border:2px solid rgba(2,6,23,0.45);border-radius:999px;}
      .void-shell::-webkit-scrollbar-thumb:hover,.void-left::-webkit-scrollbar-thumb:hover,.void-right::-webkit-scrollbar-thumb:hover{background:linear-gradient(180deg,rgba(226,232,240,0.8),rgba(168,85,247,0.55));}

      .void-card{scrollbar-color: rgba(168,85,247,0.65) rgba(2,6,23,0.35);}
      .void-card::-webkit-scrollbar{width:10px}
      .void-card::-webkit-scrollbar-track{background:rgba(2,6,23,0.35);border-radius:999px}
      .void-card::-webkit-scrollbar-thumb{background:linear-gradient(180deg,rgba(250,204,21,0.65),rgba(168,85,247,0.65));border-radius:999px;border:2px solid rgba(2,6,23,0.35)}
      .void-grid{display:grid;grid-template-columns:1fr;gap:12px}
      .void-item{position:relative;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 14px;border-radius:18px;
        border:1px solid rgba(148,163,184,0.16);
        background:
          radial-gradient(420px 180px at 0% 0%, rgba(168,85,247,0.12), transparent 60%),
          radial-gradient(420px 180px at 100% 0%, rgba(250,204,21,0.10), transparent 60%),
          rgba(2,6,23,0.30);
      }
      .void-left{display:flex;gap:12px;align-items:center;min-width:0}
      .void-icon{width:44px;height:44px;border-radius:14px;display:flex;align-items:center;justify-content:center;
        border:1px solid rgba(250,204,21,0.30);
        background: linear-gradient(180deg, rgba(250,204,21,0.10), rgba(168,85,247,0.10));
        box-shadow:0 18px 60px rgba(0,0,0,0.35);
        font-size:20px;
      }
      .void-info{display:flex;flex-direction:column;gap:6px;min-width:0}
      .void-item-title{font-size:14px;letter-spacing:0.08em;color:#e5e7eb;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .void-item-desc{font-size:12px;line-height:1.4;color:rgba(226,232,240,0.75);max-width: 560px}
      .void-right{display:flex;gap:10px;align-items:center}
      .void-cost{font-size:11px;padding:8px 10px;border-radius:999px;border:1px solid rgba(168,85,247,0.24);
        background:rgba(2,6,23,0.35);color:#e2e8f0}
      .void-buy{font-size:11px;border:1px solid rgba(250,204,21,0.55);background:rgba(250,204,21,0.15);color:#fff;border-radius:14px;padding:10px 12px;cursor:pointer}
      .void-buy:disabled{opacity:0.55;cursor:not-allowed}
      .void-owned-badge{position:absolute;top:10px;left:10px;font-size:10px;letter-spacing:0.12em;
        padding:6px 8px;border-radius:999px;border:1px solid rgba(34,211,238,0.25);background:rgba(2,6,23,0.45);color:rgba(226,232,240,0.85)}
      @media (max-width: 720px){
        .void-right{flex-direction:column;align-items:flex-end}
        .void-item-desc{max-width: 48vw}
      }


      /* --- VOID SHOP REWORK (spicier, stickier) --- */
      .void-shell{box-shadow:0 25px 90px rgba(0,0,0,.6), 0 0 0 1px rgba(168,85,247,.22) inset;}
      .void-top{position:sticky;top:0;z-index:3;background:linear-gradient(180deg,rgba(2,6,23,.95),rgba(2,6,23,.55));backdrop-filter: blur(10px);}
      .void-title{letter-spacing:0.22em;text-shadow:0 0 18px rgba(168,85,247,.28),0 0 32px rgba(56,189,248,.18);}
      .void-points{box-shadow:0 8px 28px rgba(168,85,247,.18);border:1px solid rgba(168,85,247,.25);}
      .void-tabs button{transition:transform .12s ease, filter .12s ease, background .12s ease;}
      .void-tabs button:hover{transform:translateY(-1px);filter:brightness(1.08);}
      .void-tabs button.active{box-shadow:0 0 0 1px rgba(56,189,248,.25) inset, 0 10px 30px rgba(56,189,248,.12);}
      .void-grid{gap:14px;}
      .void-card{transition:transform .14s ease, box-shadow .14s ease, border-color .14s ease;}
      .void-card:hover{transform:translateY(-2px);border-color:rgba(56,189,248,.28);box-shadow:0 16px 48px rgba(0,0,0,.5);}
      .void-buy{position:relative;overflow:hidden;}
      .void-buy::after{content:"";position:absolute;inset:-60px;transform:translateX(-120%) rotate(18deg);background:linear-gradient(90deg,transparent,rgba(255,255,255,.18),transparent);transition:transform .55s ease;}
      .void-buy:hover::after{transform:translateX(140%) rotate(18deg);}
      .void-buy:active{transform:translateY(1px) scale(.99);}
      .void-overlay::before{content:"";position:absolute;inset:0;background:
        radial-gradient(900px 500px at 15% 15%, rgba(168,85,247,.10), transparent 60%),
        radial-gradient(900px 520px at 85% 25%, rgba(56,189,248,.08), transparent 60%),
        radial-gradient(900px 520px at 50% 90%, rgba(20,184,166,.07), transparent 62%);
        pointer-events:none;opacity:.95;animation:voidPulse 4.5s ease-in-out infinite;}
      @keyframes voidPulse{0%,100%{filter:saturate(1) brightness(1);}50%{filter:saturate(1.12) brightness(1.05);}}
`;
    document.head.appendChild(s);
  }

  const VOID_ITEMS = [
    { id:'vp_dmg', title:'Void Damage +5%', desc:'Permanent. Slight damage boost.', cost:1 },
    { id:'vp_hp', title:'Void HP +10', desc:'Permanent. Slight max HP boost.', cost:1 },
    { id:'vp_cos', title:'Void Aura (Cosmetic)', desc:'Unlock a special void aura (cosmetic hook).', cost:2 },
    { id:'vp_relic', title:'Void Relic Pack', desc:'A special relic pack bought with Void Points (future pool).', cost:5 },
    { id:'vp_key', title:'Rift Key', desc:'Powerful carry item (future).', cost:7 },
  ];
  const owned = {};
  function loadOwned(){
    try{
      const raw = localStorage.getItem('arc_void_shop_owned_v1');
      if (raw) Object.assign(owned, JSON.parse(raw));
    }catch(e){}
  }
  function saveOwned(){
    try{ localStorage.setItem('arc_void_shop_owned_v1', JSON.stringify(owned)); }catch(e){}
  }
  loadOwned();

  function ensureOverlay(){
    if (overlay) return overlay;
    ensureVoidStyles();
    overlay = document.createElement('div');
    overlay.className = 'void-overlay';
    overlay.id = 'void-overlay';

    const shell = document.createElement('div');
    shell.className = 'void-shell';

    const top = document.createElement('div');
    top.className = 'void-top';

    const title = document.createElement('div');
    title.className = 'void-title';
    title.textContent = 'VOID POINTS';

    const pts = document.createElement('div');
    pts.className = 'void-points';
    pts.id = 'void-points';

    const close = document.createElement('button');
    close.className = 'void-close';
    close.type = 'button';
    close.textContent = '✕ Close';
    close.addEventListener('click', () => closeVoidShop());

    top.appendChild(title);
    top.appendChild(pts);
    top.appendChild(close);

    const main = document.createElement('div');
    main.className = 'void-main';

    const card = document.createElement('div');
    card.className = 'void-card';
    card.id = 'void-items';

    main.appendChild(card);

    shell.appendChild(top);
    shell.appendChild(main);
    overlay.appendChild(shell);
    document.body.appendChild(overlay);

    return overlay;
  }

  function renderVoid(){
    const pts = document.getElementById('void-points');
    if (pts) pts.textContent = `VOID POINTS: ${voidPoints}`;

    const el = document.getElementById('void-items');
    if (!el) return;

    el.innerHTML = '';
    const grid = document.createElement('div');
    grid.className = 'void-grid';

    const iconMap = {
      vp_skin: '✦',
      vp_trail: '➷',
      vp_emote: '☺',
      vp_relic: '◎',
      vp_key: '⟡',
    };

    VOID_ITEMS.forEach(it=>{
      const card = document.createElement('div');
      card.className = `void-item void-${it.id}`;

      const left = document.createElement('div');
      left.className = 'void-left';

      const icon = document.createElement('div');
      icon.className = 'void-icon';
      icon.textContent = iconMap[it.id] || '◎';

      const info = document.createElement('div');
      info.className = 'void-info';

      const t = document.createElement('div');
      t.className='void-item-title';
      t.textContent = it.title;

      const d = document.createElement('div');
      d.className='void-item-desc';
      d.textContent = it.desc;

      info.appendChild(t);
      info.appendChild(d);

      left.appendChild(icon);
      left.appendChild(info);

      const right = document.createElement('div');
      right.className = 'void-right';

      const cost = document.createElement('div');
      cost.className='void-cost';
      cost.textContent = `${it.cost} VOID`;

      const btn = document.createElement('button');
      btn.className='void-buy';
      btn.type='button';

      const isO = !!owned[it.id];
      btn.textContent = isO ? 'OWNED' : 'BUY';
      btn.disabled = isO || voidPoints < it.cost;

      if (isO){
        const badge = document.createElement('div');
        badge.className = 'void-owned-badge';
        badge.textContent = 'OWNED';
        card.appendChild(badge);
      }

      btn.addEventListener('click', ()=>{
        if (owned[it.id]) return;
        if (!spendVoid(it.cost)) return;
        owned[it.id]=true;
        saveOwned();
        try { showToast(`BOUGHT: ${it.title}`); } catch(e){}
        renderVoid();
      });

      right.appendChild(cost);
      right.appendChild(btn);

      card.appendChild(left);
      card.appendChild(right);

      grid.appendChild(card);
    });

    el.appendChild(grid);
  }

  function openVoidShop(){
    if (typeof gameState !== 'undefined' && gameState !== 'farmHub') {
      try { toastCenter("VOID SHOP: OPEN IT IN FARM HUB"); } catch(e){}
      return;
    }
    const ov = ensureOverlay();
    ov.style.display='flex';
    renderVoid();
  }
  function closeVoidShop(){
    if (!overlay) return;
    overlay.style.display='none';
  }

  // Wire button
  window.addEventListener('load', ()=>{
    const btn = document.getElementById('void-shop-btn');
    if (btn) {
      btn.addEventListener('click', (e)=>{ e.preventDefault(); openVoidShop(); });
    }
  });
})();

// Align HUD buttons in a clean vertical stack (FarmHub only)
(function alignTopRightButtons(){
  window.addEventListener('load', ()=>{
    const wrap = document.getElementById('wallet-connect-wrapper');
    const lb = document.getElementById('leaderboard-open-btn');
    const fs = document.getElementById('fullscreen-btn');
    if (wrap && lb) {
      try {
        lb.style.position = 'static';
        lb.style.right = '';
        lb.style.top = '';
        lb.style.margin = '0';
        lb.style.width = '100%';
        lb.style.padding = '10px 16px';
        lb.style.borderRadius = '16px';
        lb.style.fontFamily = "'Press Start 2P'";
        lb.style.fontSize = '12px';
        lb.style.cursor = 'pointer';
        lb.style.border = '1px solid rgba(250,204,21,0.35)';
        lb.style.background = 'rgba(250,204,21,0.10)';
        lb.style.color = '#facc15';
        // Put leaderboard right under wallet button
        if (!wrap.contains(lb)) {
          wrap.insertBefore(lb, document.getElementById('shop-btn') || fs || null);
        }
      } catch(e){}
    }
    if (wrap && fs) {
      fs.style.width = '100%';
      fs.style.marginTop = '0';
      fs.style.borderRadius = '16px';
      fs.style.padding = '10px 16px';
      fs.style.fontSize = '11px';
    }
    const inv = document.getElementById('inventory-btn');
    if (wrap && inv) {
      inv.style.width = '100%';
      inv.style.marginTop = '0';
      inv.style.borderRadius = '16px';
      inv.style.padding = '10px 16px';
    }
  });
})();


// =============================================================
// CHARACTER CUSTOMIZATION MODULE MOVED TO customization.js
// =============================================================

// =============================================================
// BASE_BODY_DIR_CACHE_V1 (4-direction player rendering)
// =============================================================
const baseIdleImgs = { south: new Image(), north: new Image(), east: new Image(), west: new Image() };
const baseWalkImgs = { south: new Image(), north: new Image(), east: new Image(), west: new Image() };

function ensureBaseBodyImages(){
  const set = window.__baseBodySheets;
  if (!set) return;

  // assign only if changed (avoid spamming)
  if (baseIdleImgs.south.__src !== set.idle.south) {
    baseIdleImgs.south.src = set.idle.south; baseIdleImgs.south.__src = set.idle.south;
    baseIdleImgs.north.src = set.idle.north; baseIdleImgs.north.__src = set.idle.north;
    baseIdleImgs.east.src  = set.idle.east;  baseIdleImgs.east.__src  = set.idle.east;
    baseIdleImgs.west.src  = set.idle.west;  baseIdleImgs.west.__src  = set.idle.west;

    baseWalkImgs.south.src = set.walk.south; baseWalkImgs.south.__src = set.walk.south;
    baseWalkImgs.north.src = set.walk.north; baseWalkImgs.north.__src = set.walk.north;
    baseWalkImgs.east.src  = set.walk.east;  baseWalkImgs.east.__src  = set.walk.east;
    baseWalkImgs.west.src  = set.walk.west;  baseWalkImgs.west.__src  = set.walk.west;
  }

  const level5Ready =
    (typeof LEVEL5_IMG !== "undefined") &&
    LEVEL5_IMG &&
    LEVEL5_IMG.complete &&
    LEVEL5_IMG.naturalWidth > 0;
}