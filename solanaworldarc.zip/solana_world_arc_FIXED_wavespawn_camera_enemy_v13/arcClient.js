// arcClient.js (non-module version for plain <script> usage)

async function connectWallet() {
  if (!window.solana) throw new Error("Phantom not found");
  const res = await window.solana.connect();
  return res.publicKey.toString();
}

async function linkWallet(api, userId, wallet) {
  await fetch(api + "/link-wallet", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ user_id: userId, wallet })
  });
}

async function earnARC(api, userId, amount) {
  const r = await fetch(api + "/earn", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ user_id: userId, amount })
  });
  return r.json();
}

async function claimARC(api, userId) {
  const r = await fetch(api + "/claim", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ user_id: userId })
  });
  return r.json();
}

// expose to game.js
window.arc = { connectWallet, linkWallet, earnARC, claimARC };
