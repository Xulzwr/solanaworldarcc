// /js/world/realms.js
// Data-only: add/edit realms here, game picks one when entering a Rift.
// Keep it simple so you can expand it later without touching core logic.

(function () {
  const REALMS = [
    {
      id: "solana-realm",
      name: "SOLANA REALM",
      subtitle: "Neon blockspace haze",
      // Overlay tint (rgba string without alpha – alpha handled elsewhere)
      overlay: { center: "rgba(76,29,149,0.70)", edge: "rgba(0,0,0,0)" },
      portal: { inner: "#22d3ee", mid: "#a855f7", outer: "rgba(0,0,0,0)", rune: "#fefce8" },
      motes:  { a: "#22d3ee", b: "#a855f7" },
      feature: "Neon surge (extra loot milestones)",

      reward: { arcBonusBase: 50, arcBonusPerDepth: 25, xpBase: 20, xpPerDepth: 5 }
    },
    {
      id: "desert-vault",
      name: "DESERT VAULT",
      subtitle: "Heat shimmer + sandcode",
      overlay: { center: "rgba(180,83,9,0.60)", edge: "rgba(0,0,0,0)" },
      portal: { inner: "#fb7185", mid: "#f59e0b", outer: "rgba(0,0,0,0)", rune: "#fff7ed" },
      motes:  { a: "#f59e0b", b: "#fb7185" },
      feature: "Heat haze (stronger vignette)",

      reward: { arcBonusBase: 60, arcBonusPerDepth: 28, xpBase: 22, xpPerDepth: 6 }
    },
    {
      id: "dark-castle",
      name: "DARK CASTLE",
      subtitle: "Validator catacombs",
      overlay: { center: "rgba(30,41,59,0.75)", edge: "rgba(0,0,0,0)" },
      portal: { inner: "#38bdf8", mid: "#94a3b8", outer: "rgba(0,0,0,0)", rune: "#e2e8f0" },
      motes:  { a: "#94a3b8", b: "#38bdf8" },
      feature: "Catacombs (darker fog, higher ARC)",

      reward: { arcBonusBase: 70, arcBonusPerDepth: 30, xpBase: 24, xpPerDepth: 6 }
    },
    {
      id: "farmhub-backrooms",
      name: "FARMHUB BACKROOMS",
      subtitle: "Glitched tiles + stale light",
      overlay: { center: "rgba(21,128,61,0.55)", edge: "rgba(0,0,0,0)" },
      portal: { inner: "#34d399", mid: "#86efac", outer: "rgba(0,0,0,0)", rune: "#fefce8" },
      motes:  { a: "#34d399", b: "#86efac" },
      feature: "Backrooms (glitch motes)",

      reward: { arcBonusBase: 55, arcBonusPerDepth: 26, xpBase: 21, xpPerDepth: 5 }
    },
    {
      id: "sky-temple",
      name: "SKY TEMPLE",
      subtitle: "Air nodes and ancient fees",
      overlay: { center: "rgba(14,165,233,0.55)", edge: "rgba(0,0,0,0)" },
      portal: { inner: "#93c5fd", mid: "#22d3ee", outer: "rgba(0,0,0,0)", rune: "#f8fafc" },
      motes:  { a: "#93c5fd", b: "#22d3ee" },
      feature: "Temple wind (brighter portal)",

      reward: { arcBonusBase: 65, arcBonusPerDepth: 29, xpBase: 23, xpPerDepth: 6 }
    },
    {
      id: "mushroom-grotto",
      name: "MUSHROOM GROTTO",
      subtitle: "Spore fog and crit blooms",
      overlay: { center: "rgba(190,24,93,0.55)", edge: "rgba(0,0,0,0)" },
      portal: { inner: "#f472b6", mid: "#a855f7", outer: "rgba(0,0,0,0)", rune: "#fff1f2" },
      motes:  { a: "#f472b6", b: "#a855f7" },
      feature: "Spore bloom (more motes)",

      reward: { arcBonusBase: 58, arcBonusPerDepth: 27, xpBase: 22, xpPerDepth: 5 }
    }
  ];

  // Expose globally (non-module, plain browser)
  window.ARC_REALMS = REALMS;

  // Simple picker (you can swap to weighted / biome-based later)
  window.pickArcRealm = function pickArcRealm(depth) {
    if (!REALMS.length) return null;
    const idx = Math.abs((depth * 9301 + 49297) % 233280) % REALMS.length;
    return REALMS[idx];
  };
})();
