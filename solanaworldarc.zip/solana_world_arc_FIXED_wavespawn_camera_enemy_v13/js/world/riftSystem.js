// js/world/riftSystem.js
// Minimal, syntax-safe Rift System. Optional usage.
// Call window.createRiftSystem(deps) to get an object with {openPortal, enter, exit, update, drawOverlay, drawPortal}.

(function () {
  window.createRiftSystem = function createRiftSystem(deps) {
    const S = (deps && deps.state) || {};
    const W = (deps && deps.world) || {};
    const C = (deps && deps.collections) || {};
    const A = (deps && deps.api) || {};

    function openPortal() {
      if (S.riftPortalActive || S.inRift) return;
      S.riftPortalActive = true;

      const ww = (W.WORLD_WIDTH != null) ? W.WORLD_WIDTH : (window.WORLD_WIDTH || 2000);
      const wh = (W.WORLD_HEIGHT != null) ? W.WORLD_HEIGHT : (window.WORLD_HEIGHT || 2000);

      S.riftPortalX = ww / 2;
      S.riftPortalY = wh / 2;

      if (typeof A.showToast === "function") A.showToast("A Rift has opened!");
      if (typeof A.showPortalHint === "function") A.showPortalHint();
    }

    function enter() {
      if (!S.riftPortalActive || S.inRift || S.gameOver) return;
      S.inRift = true;
      S.riftPortalActive = false;

      if (typeof A.hidePortalHint === "function") A.hidePortalHint();

      // Clear active combat arrays if present
      if (Array.isArray(C.enemies)) C.enemies.length = 0;
      if (Array.isArray(C.bullets)) C.bullets.length = 0;
      if (Array.isArray(C.enemyBullets)) C.enemyBullets.length = 0;
      if (Array.isArray(C.powerups)) C.powerups.length = 0;
      if (Array.isArray(C.damagePopups)) C.damagePopups.length = 0;

      if (typeof A.triggerShake === "function") A.triggerShake(10);
      if (typeof A.playRiftEnterSound === "function") A.playRiftEnterSound();
      if (typeof A.showSolanaRealmToast === "function") A.showSolanaRealmToast();
      else if (typeof A.showToast === "function") A.showToast("Entered the Rift");
    }

    function exit() {
      if (!S.inRift) return;
      S.inRift = false;
      if (typeof A.showToast === "function") A.showToast("Rift cleared!");
    }

    function update() {
      // Optional: portal motes while open
      if (S.riftPortalActive && !S.inRift && !S.gameOver) {
        const sp = window.spawnRiftParticle;
        if (typeof sp === "function") sp(S.riftPortalX, S.riftPortalY, "#22d3ee", "#a855f7", 1);
      }
    }

    function drawOverlay() {}
    function drawPortal() {}

    return { openPortal, enter, exit, update, drawOverlay, drawPortal };
  };

  window.RiftSystem = window.RiftSystem || {};
})();
