// systems/pauseSettings.js
// Pause menu, settings panel, and persistent settings.

(function () {
  const STORAGE_KEY = "arc_settings_v1";

  // --------- DEFAULT SETTINGS ----------
  function getDefaultArcSettings() {
    return {
      masterVolume: 0.8,
      sfxVolume: 1.0,
      mouseSensitivity: 1.0,
      graphicsQuality: "high", // "low" | "medium" | "high"
      weatherEnabled: true,
      shakeEnabled: true
    };
  }

  function loadArcSettings() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return getDefaultArcSettings();
      const parsed = JSON.parse(raw);
      return { ...getDefaultArcSettings(), ...parsed };
    } catch (e) {
      console.warn("Failed to load settings, using defaults:", e);
      return getDefaultArcSettings();
    }
  }

  function saveArcSettings() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(window.arcSettings));
    } catch (e) {
      console.warn("Failed to save settings:", e);
    }
  }

  function applyArcSettingsToGame() {
    const s = window.arcSettings || getDefaultArcSettings();
    window.arcMasterVolume = s.masterVolume;
    window.arcSfxVolume = s.sfxVolume;
    window.arcMouseSensitivity = s.mouseSensitivity;
    window.arcWeatherEnabled = !!s.weatherEnabled;
    window.arcShakeEnabled = !!s.shakeEnabled;
    window.arcGraphicsQuality = s.graphicsQuality;
  }

  // Expose global settings object
  window.arcSettings = loadArcSettings();
  applyArcSettingsToGame();

  // --------- PAUSE STATE ----------
  window.isPaused = false;

  function setPaused(paused) {
    window.isPaused = !!paused;

    // Clear "stuck" inputs when toggling pause.
    try {
      if (window.__keys) {
        Object.keys(window.__keys).forEach((k) => (window.__keys[k] = false));
      }
      if (typeof window.__setMouseDown === "function") window.__setMouseDown(false);
    } catch {}

    const overlay = document.getElementById("pause-overlay");
    if (overlay) {
      overlay.style.display = window.isPaused ? "flex" : "none";
    }
    document.body.classList.toggle("arc-paused", window.isPaused);
  }

  window.togglePause = function togglePause(force) {
    if (typeof force === "boolean") {
      setPaused(force);
    } else {
      setPaused(!window.isPaused);
    }
  };

  function openSettingsPanel() {
    const p = document.getElementById("pause-overlay");
    const s = document.getElementById("settings-panel");
    if (p) p.style.display = "none";
    if (s) s.style.display = "flex";
  }

  function closeSettingsPanel() {
    const s = document.getElementById("settings-panel");
    const p = document.getElementById("pause-overlay");
    if (s) s.style.display = "none";
    if (p && window.isPaused) p.style.display = "flex";
  }

  // --------- DOM WIRING ----------
  window.addEventListener("DOMContentLoaded", () => {
    const pauseOverlay = document.getElementById("pause-overlay");
    const settingsPanel = document.getElementById("settings-panel");

    // PAUSE MENU BUTTONS
    if (pauseOverlay) {
      pauseOverlay.querySelectorAll("[data-pause-action]").forEach((btn) => {
        const action = btn.getAttribute("data-pause-action");
        btn.addEventListener("click", () => {
          if (action === "resume") {
            window.togglePause(false);
          } else if (action === "settings") {
            openSettingsPanel();
          } else if (action === "restart") {
            window.togglePause(false);
            if (typeof window.restartGame === "function") {
              window.restartGame();
            } else {
              window.location.reload();
            }
          } else if (action === "quit") {
            window.togglePause(false);
            // go back to main menu
            if (typeof window.gameState !== "undefined") {
              window.gameState = "menu";
            }
            const mm = document.getElementById("main-menu");
            if (mm) mm.style.display = "flex";
          } else if (action === "save-settings") {
            // Explicit SAVE: persist + apply, then close and resume.
            applyArcSettingsToGame();
            saveArcSettings();
            closeSettingsPanel();
            window.togglePause(false);
          } else if (action === "close-settings") {
            // Back to run should always resume gameplay immediately.
            closeSettingsPanel();
            window.togglePause(false);
          }
        });
      });
    }

    // SETTINGS INPUTS
    const s = window.arcSettings || getDefaultArcSettings();

    const masterVol = document.getElementById("setting-master-volume");
    const sfxVol = document.getElementById("setting-sfx-volume");
    const sens = document.getElementById("setting-mouse-sensitivity");
    const graphics = document.getElementById("setting-graphics-quality");
    const weather = document.getElementById("setting-weather");
    const shake = document.getElementById("setting-shake");

    if (masterVol) {
      masterVol.value = s.masterVolume;
      masterVol.addEventListener("input", () => {
        window.arcSettings.masterVolume = parseFloat(masterVol.value);
        applyArcSettingsToGame();
        saveArcSettings();
      });
    }

    if (sfxVol) {
      sfxVol.value = s.sfxVolume;
      sfxVol.addEventListener("input", () => {
        window.arcSettings.sfxVolume = parseFloat(sfxVol.value);
        applyArcSettingsToGame();
        saveArcSettings();
      });
    }

    if (sens) {
      sens.value = s.mouseSensitivity;
      sens.addEventListener("input", () => {
        window.arcSettings.mouseSensitivity = parseFloat(sens.value);
        applyArcSettingsToGame();
        saveArcSettings();
      });
    }

    if (graphics) {
      graphics.value = s.graphicsQuality;
      graphics.addEventListener("change", () => {
        window.arcSettings.graphicsQuality = graphics.value;
        applyArcSettingsToGame();
        saveArcSettings();
      });
    }

    if (weather) {
      weather.checked = !!s.weatherEnabled;
      weather.addEventListener("change", () => {
        window.arcSettings.weatherEnabled = weather.checked;
        applyArcSettingsToGame();
        saveArcSettings();
      });
    }

    if (shake) {
      shake.checked = !!s.shakeEnabled;
      shake.addEventListener("change", () => {
        window.arcSettings.shakeEnabled = shake.checked;
        applyArcSettingsToGame();
        saveArcSettings();
      });
    }

    // DEV/QoL: jump to wave (for testing). Does not affect the run leaderboard.
    const jumpInp = document.getElementById("dev-jump-wave-input");
    const jumpBtn = document.getElementById("dev-jump-wave-btn");
    if (jumpBtn && !jumpBtn.__wired) {
      jumpBtn.__wired = true;
      jumpBtn.addEventListener("click", () => {
        const n = Math.max(1, Math.min(200, parseInt((jumpInp && jumpInp.value) || "1", 10) || 1));
        try {
          if (typeof window.__devJumpToWave === "function") window.__devJumpToWave(n);
        } catch (e) {
          console.warn("Jump-to-wave failed", e);
        }
        closeSettingsPanel();
        window.togglePause(false);
      });
    }

    // MENU KEY HANDLER (GLOBAL)
// Use capture so we can prevent other ESC handlers (inventory/leaderboard) from fighting us.
    document.addEventListener(
      "keydown",
      (e) => {
        const key = ((e.key || "").toLowerCase());
        if (key !== "m" && key !== "escape") return;

        // If settings open -> close settings first
        if (settingsPanel && settingsPanel.style.display === "flex") {
          if (key === "escape") { /* fallthrough to close */ }

          e.preventDefault();
          e.stopImmediatePropagation();
          closeSettingsPanel();
          return;
        }

        // Don't pause while you're on menus / intro / character select / upgrades
        const st = window.gameState;
        if (
          st === "menu" ||
          st === "intro" ||
          st === "characterSelect" ||
          st === "weaponSelect" ||
          st === "upgrade" ||
          st === "postIntroMenu" ||
          st === "farmHub"
        ) {
          return;
        }

        // Toggle pause for gameplay
        e.preventDefault();
        e.stopImmediatePropagation();
        window.togglePause();
      },
      true
    );
  });
})();
