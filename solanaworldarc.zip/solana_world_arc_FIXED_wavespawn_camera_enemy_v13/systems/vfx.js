// systems/vfx.js
// Centralised visual FX: hit sparks, enemy death bursts, explosions,
// muzzle flashes, dust/smoke impacts, step dust.

(function () {
  const vfxParticles = [];
  let lastStepDustTime = 0;

  function randRange(a, b) {
    return a + Math.random() * (b - a);
  }

  // === SPAWN HELPERS ===


// portal / rift ambient motes
function spawnRiftParticle(x, y, colorA = "#22d3ee", colorB = "#a855f7", intensity = 1) {
  const count = 2 + Math.floor(Math.random() * 2 * intensity);
  for (let i = 0; i < count; i++) {
    const ang = Math.random() * Math.PI * 2;
    const speed = randRange(0.3, 1.1) * (0.8 + intensity * 0.6);
    const rad = randRange(8, 22);
    vfxParticles.push({
      kind: "rift",
      x: x + Math.cos(ang) * rad,
      y: y + Math.sin(ang) * rad,
      vx: Math.cos(ang) * speed,
      vy: Math.sin(ang) * speed,
      life: randRange(26, 44),
      maxLife: 40,
      size: randRange(6, 14),
      colorA,
      colorB,
      spin: randRange(-0.12, 0.12)
    });
  }
}

  // small directional sparks when bullets hit
  function spawnHitSpark(x, y, dirX, dirY, intensity = 1) {
    const baseAngle = Math.atan2(dirY || 0, dirX || 1) + Math.PI; // mostly backwards
    const count = 6 + Math.floor(4 * intensity);

    for (let i = 0; i < count; i++) {
      const spread = randRange(-0.6, 0.6);
      const ang = baseAngle + spread;
      const speed = randRange(4, 8) * (0.7 + intensity * 0.5);

      vfxParticles.push({
        kind: "spark",
        x,
        y,
        vx: Math.cos(ang) * speed,
        vy: Math.sin(ang) * speed,
        life: randRange(14, 22),
        maxLife: 18,
        size: randRange(1.2, 1.9),
        color: Math.random() < 0.5 ? "#fefce8" : "#facc15"
      });
    }
  }

  // radial burst when enemies die
  function spawnEnemyDeathBurst(x, y, type) {
    const isBoss = type === "boss";
    const sparks = isBoss ? 28 : 14;
    const smoke = isBoss ? 12 : 6;

    // bright sparks
    for (let i = 0; i < sparks; i++) {
      const ang = Math.random() * Math.PI * 2;
      const speed = randRange(3, 7) * (isBoss ? 1.3 : 1);
      vfxParticles.push({
        kind: "spark",
        x,
        y,
        vx: Math.cos(ang) * speed,
        vy: Math.sin(ang) * speed,
        life: randRange(22, 32),
        maxLife: 28,
        size: randRange(1.4, 2.2),
        color: isBoss ? "#f97316" : "#a855f7"
      });
    }

    // smoky puffs
    for (let i = 0; i < smoke; i++) {
      const ang = Math.random() * Math.PI * 2;
      const speed = randRange(1.2, 2.5);
      vfxParticles.push({
        kind: "smoke",
        x,
        y,
        vx: Math.cos(ang) * speed,
        vy: Math.sin(ang) * speed,
        life: randRange(32, 46),
        maxLife: 40,
        size: randRange(isBoss ? 12 : 7, isBoss ? 20 : 11),
        color: "rgba(15,23,42,0.9)"
      });
    }
  }

  // big explosion FX (used for bosses / future grenades)
  function spawnExplosionFx(x, y, radius = 70) {
    vfxParticles.push({
      kind: "explosionCore",
      x,
      y,
      vx: 0,
      vy: 0,
      life: 26,
      maxLife: 26,
      size: radius,
      color: "#f97316"
    });

    for (let i = 0; i < 10; i++) {
      const ang = Math.random() * Math.PI * 2;
      const speed = randRange(2.5, 4.5);
      vfxParticles.push({
        kind: "smoke",
        x,
        y,
        vx: Math.cos(ang) * speed,
        vy: Math.sin(ang) * speed,
        life: randRange(32, 52),
        maxLife: 46,
        size: randRange(radius * 0.35, radius * 0.6),
        color: "rgba(15,23,42,0.95)"
      });
    }
  }

  // muzzle flash at weapon origin
  function spawnMuzzleFlash(x, y, angle, weaponId) {
    const lenBase = 18;
    const wide = weaponId === "shotgun" || weaponId === "ak47" || weaponId === "smg";
    const size = wide ? lenBase * 1.2 : lenBase;

    vfxParticles.push({
      kind: "muzzle",
      x,
      y,
      vx: 0,
      vy: 0,
      life: 12,
      maxLife: 12,
      angle: angle || 0,
      size,
      color: "#facc15"
    });
  }

  // dust / smoke at impact points (bullets hitting walls / max range)
  function spawnImpactDust(x, y, dirX, dirY) {
    const baseAngle = Math.atan2(dirY || 0, dirX || 1) + Math.PI;
    const count = 5 + Math.floor(Math.random() * 4);

    for (let i = 0; i < count; i++) {
      const ang = baseAngle + randRange(-0.5, 0.5);
      const speed = randRange(1.5, 3.5);

      vfxParticles.push({
        kind: "smoke",
        x,
        y,
        vx: Math.cos(ang) * speed,
        vy: Math.sin(ang) * speed * 0.6,
        life: randRange(26, 40),
        maxLife: 36,
        size: randRange(7, 11),
        color: "rgba(15,23,42,0.9)"
      });

      vfxParticles.push({
        kind: "dust",
        x,
        y,
        vx: Math.cos(ang) * speed * 0.6,
        vy: Math.sin(ang) * speed * 0.3,
        life: randRange(18, 26),
        maxLife: 22,
        size: randRange(3.5, 6),
        color: "#e5e7eb"
      });
    }
  }

  // shorter dust bursts while the player is running
  function spawnStepDust(x, y, moveX, moveY) {
    const now = performance.now();
    if (now < lastStepDustTime + 70) return; // throttle
    lastStepDustTime = now;

    const len = Math.hypot(moveX || 0, moveY || 0) || 1;
    const dirX = -moveX / len; // behind player
    const dirY = -moveY / len;

    spawnImpactDust(x, y, dirX, dirY);
  }

  // === UPDATE & DRAW ===

  function updateVfx(dt) {
  // In this game dt is already "per frame", so treat life as frames.
  const lifeStep = dt; // usually around 1

  for (let i = vfxParticles.length - 1; i >= 0; i--) {
    const p = vfxParticles[i];

    // decrease lifetime
    p.life -= lifeStep;
    if (p.life <= 0) {
      vfxParticles.splice(i, 1);
      continue;
    }

    // move particle
    const moveStep = dt; // tweakable if you want faster/slower motion
    p.x += (p.vx || 0) * moveStep;
    p.y += (p.vy || 0) * moveStep;
  }
}

  function drawVfx(ctx, camera) {
    if (!ctx || !camera) return;
    ctx.save();

    for (let i = 0; i < vfxParticles.length; i++) {
      const p = vfxParticles[i];
      const sx = p.x - camera.x;
      const sy = p.y - camera.y;

      if (sx < -60 || sy < -60 || sx > ctx.canvas.width + 60 || sy > ctx.canvas.height + 60) {
        continue;
      }

      const lifeRatio = Math.max(0, Math.min(1, p.life / p.maxLife));
      ctx.save();

      if (p.kind === "rift") {
  // additive, soft motes
  const alpha = 0.15 + 0.55 * lifeRatio;
  const radius = p.size * (0.6 + (1 - lifeRatio) * 0.8);

  ctx.globalCompositeOperation = "lighter";
  ctx.globalAlpha = alpha;

  const grd = ctx.createRadialGradient(sx, sy, 0, sx, sy, radius);
  const a = p.colorA || "#22d3ee";
  const b = p.colorB || "#a855f7";
  grd.addColorStop(0, a);
  grd.addColorStop(0.55, b);
  grd.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = grd;

  ctx.beginPath();
  ctx.arc(sx, sy, radius, 0, Math.PI * 2);
  ctx.fill();

  // tiny rotating crosshair sparkle
  ctx.globalAlpha = alpha * 0.35;
  ctx.translate(sx, sy);
  ctx.rotate((p.spin || 0) * (p.maxLife - p.life));
  ctx.fillStyle = "#fefce8";
  ctx.fillRect(-1, -radius * 0.65, 2, radius * 0.25);
  ctx.fillRect(-radius * 0.65, -1, radius * 0.25, 2);
} else if (p.kind === "spark") {
        ctx.translate(sx, sy);
        const len = p.size * (1.2 + (1 - lifeRatio) * 1.4);
        const alpha = 0.3 + 0.7 * lifeRatio;
        ctx.globalAlpha = alpha;
        ctx.rotate(Math.atan2(p.vy || 0.01, p.vx || 1));
        ctx.fillStyle = p.color || "#facc15";
        ctx.fillRect(0, -0.8, len, 1.6);
      } else if (p.kind === "smoke") {
        const radius = p.size * (1.1 + (1 - lifeRatio) * 0.9);
        ctx.globalAlpha = 0.45 * lifeRatio;
        ctx.fillStyle = p.color || "rgba(15,23,42,0.9)";
        ctx.beginPath();
        ctx.arc(sx, sy, radius, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.kind === "dust") {
        const radius = p.size * (0.8 + lifeRatio * 0.6);
        ctx.globalAlpha = 0.15 + 0.55 * lifeRatio;
        ctx.fillStyle = p.color || "#e5e7eb";
        ctx.beginPath();
        ctx.arc(sx, sy, radius, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.kind === "muzzle") {
        ctx.translate(sx, sy);
        ctx.rotate(p.angle || 0);
        const len = p.size;
        const wide = len * 0.6;
        const alpha = lifeRatio; // fades very fast
        ctx.globalAlpha = alpha;
        ctx.beginPath();
        ctx.moveTo(0, -wide * 0.25);
        ctx.lineTo(len, 0);
        ctx.lineTo(0, wide * 0.25);
        ctx.closePath();
        ctx.fillStyle = "#facc15";
        ctx.fill();
      } else if (p.kind === "explosionCore") {
        const radius = p.size * (0.6 + (1 - lifeRatio) * 0.7);
        ctx.globalAlpha = 0.4 + 0.6 * lifeRatio;
        const grd = ctx.createRadialGradient(sx, sy, 0, sx, sy, radius);
        grd.addColorStop(0, "rgba(254,249,195,1)");
        grd.addColorStop(0.4, "rgba(250,204,21,0.95)");
        grd.addColorStop(1, "rgba(248,113,113,0)");
        ctx.fillStyle = grd;
        ctx.beginPath();
        ctx.arc(sx, sy, radius, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    }

    ctx.restore();
  }

  // expose globally so game.js can call these
  window.spawnHitSpark = spawnHitSpark;
  window.spawnEnemyDeathBurst = spawnEnemyDeathBurst;
  window.spawnExplosionFx = spawnExplosionFx;
  window.spawnMuzzleFlash = spawnMuzzleFlash;
  window.spawnImpactDust = spawnImpactDust;
  window.spawnRiftParticle = spawnRiftParticle;
  window.spawnStepDust = spawnStepDust;
  window.updateVfx = updateVfx;
  window.drawVfx = drawVfx;
})();
